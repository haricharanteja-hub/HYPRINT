// HYPRINT upload indicator — Arduino Uno
// Blinks the LED on digital pin 13 once every time the kiosk PC sends 'U'
// (sent by led_notifier.py whenever a student's file upload succeeds).
//
// Wiring: the Uno's built-in "L" LED is already on pin 13. For an external LED:
//   pin 13 -> 220 ohm resistor -> LED long leg (+) ; LED short leg (-) -> GND

const int LED_PIN = 13;
const unsigned long BLINK_MS = 300;

void setup() {
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  Serial.begin(9600);
}

void loop() {
  while (Serial.available() > 0) {
    char c = Serial.read();
    if (c == 'U') {
      digitalWrite(LED_PIN, HIGH);
      delay(BLINK_MS);
      digitalWrite(LED_PIN, LOW);
      delay(150);  // gap so back-to-back uploads show as separate blinks
    }
  }
}
