@echo off
title HYPRINT Print Server & Kiosk
cd /d "C:\Users\Student\.gemini\antigravity-ide\scratch\HYPRINT"

:: Self-elevate to Administrator for Windows Print Spooler management
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Elevating to Administrator permissions for spooler watchdog...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo ========================================================
echo             HYPRINT ENTERPRISE KIOSK SERVER
echo ========================================================
echo.
echo Checking port 8000...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8000') do (
    echo Terminating stale process PID %%a...
    taskkill /F /PID %%a >nul 2>&1
)

echo Starting HYPRINT Server on http://127.0.0.1:8000/kiosk.html ...
echo.
:: Kiosk UI opens automatically in browser
.\.venv\Scripts\python.exe -m uvicorn main:app --port 8000 --host 0.0.0.0
pause
