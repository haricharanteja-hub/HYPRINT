import re

with open('main.py', 'r', encoding='utf-8') as f:
    code = f.read()

# 1. Add /api/status
status_code = """
@app.get("/api/status")
async def get_hardware_status():
    try:
        fault = cups_manager.blocking_fault(cups_manager.printer_state_reasons())
        if fault:
            return {"status": "OFFLINE", "reason": fault}
        return {"status": "ONLINE"}
    except Exception as e:
        return {"status": "OFFLINE", "reason": str(e)}

@app.get("/api/stats/today")
async def get_stats_today():
    with get_session() as s:
        # Get count of successful prints today
        today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        from sqlalchemy import func
        count = s.query(func.count(PrintJob.id)).filter(
            PrintJob.status == JobStatus.COMPLETED,
            PrintJob.created_at >= today
        ).scalar()
        return {"prints_today": count or 0}
"""
code = code.replace('@app.get("/api/preflight")', status_code + '\n@app.get("/api/preflight")')

# 2. Modify payment_webhook
webhook_old = """    pin = f"{random.randint(0, 9999):04d}"

    try:
        with get_write_session() as s:
            moved = atomic_transition(
                s, job_id, {JobStatus.PENDING_PAYMENT}, JobStatus.AWAITING_RELEASE,
                payment_ref=payment_ref,
                paid_at=datetime.now(timezone.utc),
                release_pin=pin,
            )
            s.commit()"""
webhook_new = """
    try:
        with get_write_session() as s:
            moved = atomic_transition(
                s, job_id, {JobStatus.PENDING_PAYMENT}, JobStatus.PAID,
                payment_ref=payment_ref,
                paid_at=datetime.now(timezone.utc),
            )
            s.commit()"""
code = code.replace(webhook_old, webhook_new)

# Add run_print_job call to webhook
webhook_finish_old = """    # NOTE: we do NOT print here. The job waits for the student to key their
    # PIN into the kiosk (POST /api/release), so pages never emerge onto an
    # unattended tray.
    await broadcast_job(job_id, "Payment received. Enter your code at the kiosk to print.")
    return {"ok": True, "awaiting_release": True}"""
webhook_finish_new = """    await broadcast_job(job_id, "Payment received. Job is spooling...")
    asyncio.create_task(run_print_job(job_id))
    return {"ok": True, "paid": True}"""
code = code.replace(webhook_finish_old, webhook_finish_new)

# 3. Modify simulate payment
sim_old = """    pin = f"{random.randint(0, 9999):04d}"
    with get_write_session() as s:
        moved = atomic_transition(
            s, job_id, {JobStatus.PENDING_PAYMENT}, JobStatus.AWAITING_RELEASE,
            payment_ref=f"sim_{uuid.uuid4().hex[:12]}",
            paid_at=datetime.now(timezone.utc), release_pin=pin,
        )
        s.commit()"""
sim_new = """    with get_write_session() as s:
        moved = atomic_transition(
            s, job_id, {JobStatus.PENDING_PAYMENT}, JobStatus.PAID,
            payment_ref=f"sim_{uuid.uuid4().hex[:12]}",
            paid_at=datetime.now(timezone.utc),
        )
        s.commit()"""
code = code.replace(sim_old, sim_new)

sim_finish_old = """    await broadcast_job(job_id, "Simulated payment successful. Enter your code at the kiosk.")
    return {"ok": True, "simulated": True, "pin": pin}"""
sim_finish_new = """    await broadcast_job(job_id, "Simulated payment successful. Job is spooling...")
    asyncio.create_task(run_print_job(job_id))
    return {"ok": True, "simulated": True}"""
code = code.replace(sim_finish_old, sim_finish_new)

# 4. Remove /api/release, /api/release/approve, /api/release/cancel
code = re.sub(r'# ===========================================================================\n# Release \(the bridge between the public website and this physical kiosk\)\n# ===========================================================================.*?@app\.get\("/api/kiosk/job/{job_id}/pdf"\)', '@app.get("/api/kiosk/job/{job_id}/pdf")', code, flags=re.DOTALL)


with open('main.py', 'w', encoding='utf-8') as f:
    f.write(code)

print("Patched main.py")
