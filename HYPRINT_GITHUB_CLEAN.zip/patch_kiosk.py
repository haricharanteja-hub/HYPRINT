import re

with open('kiosk.html', 'r', encoding='utf-8') as f:
    code = f.read()

qr_html = """
    <section class="keypad-panel" id="idle-panel" style="display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center;">
      <h2 style="font-size:28px; font-weight:800; color:white; margin-bottom:12px;">Scan to Print</h2>
      <p style="color:var(--text-muted); font-size:14px; margin-bottom:24px;">Upload PDFs directly from your phone.</p>
      <div style="background:white; padding:16px; border-radius:16px; margin-bottom:16px;">
        <img src="/kiosk_qr.png" alt="QR Code" style="width:200px; height:200px; object-fit:contain;" />
      </div>
      <p style="color:var(--green); font-weight:600; font-size:16px;">No PINs required.</p>
    </section>
    
    <section class="keypad-panel" id="executing-panel" style="display:none; flex-direction:column; align-items:center; justify-content:center; text-align:center;">
      <svg style="width:64px;height:64px;color:var(--green);margin-bottom:24px;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path></svg>
      <h2 style="font-size:32px; font-weight:800; color:white; margin-bottom:12px;">Printing Document</h2>
      <p style="color:var(--text-muted); font-size:18px;">For <span id="executing-user" style="color:var(--green);font-weight:700;">Student</span></p>
    </section>
"""

# Replace the keypad panel with QR panel + Executing panel
code = re.sub(r'<section class="keypad-panel">.*?</section>', qr_html, code, flags=re.DOTALL)

# Add polling script
polling_js = """
  async function pollCurrentJob() {
    try {
      const res = await fetch('/api/kiosk/current-job');
      const job = await res.json();
      
      const idle = document.getElementById('idle-panel');
      const exec = document.getElementById('executing-panel');
      
      if (job && (job.status === 'SPOOLING' || job.status === 'PRINTING')) {
        idle.style.display = 'none';
        exec.style.display = 'flex';
        document.getElementById('executing-user').innerText = job.user_name || 'Student';
      } else {
        idle.style.display = 'flex';
        exec.style.display = 'none';
      }
    } catch(e) {}
  }
  setInterval(pollCurrentJob, 2000);
"""
code = code.replace('// --- Start ---', '// --- Start ---\n' + polling_js)

# Delete the JS keypad logic to avoid errors
code = re.sub(r'/\* ---------- Keypad Logic ---------- \*/.*?(?=/\* ---------- View Transitions ---------- \*/)', '', code, flags=re.DOTALL)

with open('kiosk.html', 'w', encoding='utf-8') as f:
    f.write(code)

print("Patched kiosk.html")
