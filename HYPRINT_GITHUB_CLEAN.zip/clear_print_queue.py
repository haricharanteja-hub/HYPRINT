import win32print

def clear_all_jobs():
    printers = [p[2] for p in win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS)]
    print(f"Found {len(printers)} printers: {printers}")
    for printer_name in printers:
        try:
            try:
                h = win32print.OpenPrinter(printer_name, {"DesiredAccess": win32print.PRINTER_ACCESS_ADMINISTER | win32print.PRINTER_ACCESS_USE})
            except Exception:
                h = win32print.OpenPrinter(printer_name)
            
            jobs = win32print.EnumJobs(h, 0, 100, 1)
            if jobs:
                print(f"Found {len(jobs)} jobs on {printer_name}:")
                for job in jobs:
                    jid = job["JobId"]
                    doc = job.get("pDocument", "Unknown")
                    status = job.get("Status", 0)
                    print(f" - Job #{jid}: '{doc}', Status: {status}")
                    try:
                        # Purge or cancel
                        win32print.SetJob(h, jid, 0, None, win32print.JOB_CONTROL_DELETE)
                        print(f"   -> Deleted Job #{jid}")
                    except Exception as e:
                        print(f"   -> Failed to delete Job #{jid}: {e}")
                try:
                    # Also purge printer if possible
                    win32print.SetPrinter(h, 0, None, win32print.PRINTER_CONTROL_PURGE)
                    print(f"   -> Purged printer queue for {printer_name}")
                except Exception as e:
                    pass
            win32print.ClosePrinter(h)
        except Exception as err:
            print(f"Error accessing {printer_name}: {err}")

if __name__ == "__main__":
    clear_all_jobs()
