@echo off
title Publish HyPrint to Firebase
cd /d "C:\Users\Student\.gemini\antigravity-ide\scratch\HYPRINT"

echo ============================================================
echo             PUBLISHING HYPRINT TO FIREBASE
echo ============================================================
echo.
echo Step 1: Logging in to your Google Account...
echo (A browser window will open. Click your Google account and Allow.)
echo.
call firebase login
echo.
echo Step 2: Uploading website to Firebase Hosting...
call firebase deploy --only hosting --project hyprint-64865
echo.
echo ============================================================
echo   SUCCESS! YOUR HYPRINT KIOSK PORTAL IS LIVE AT:
echo   https://hyprint-64865.web.app
echo ============================================================
echo.
pause
