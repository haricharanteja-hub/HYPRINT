import hardware_monitor
import win32print

print("=" * 65)
print("EVIDENCE: RAW DATA DIRECTLY FROM THE PHYSICAL USB PRINTER")
print("=" * 65)

# 1. Physical Device Connection
h = win32print.OpenPrinter("HP LaserJet Pro P1100 plus series")
info = win32print.GetPrinter(h, 2)
print(f"\n1. PHYSICAL DEVICE ON DESK:")
print(f"   Target Device:  {info['pPrinterName']}")
print(f"   Physical Port:  {info['pPortName']} (Hardware USB Port)")
print(f"   Driver:         {info['pDriverName']}")
win32print.ClosePrinter(h)

# 2. Raw Signal from Hardware
raw_signal = hardware_monitor.get_hp_bidi_state("HP LaserJet Pro P1100 plus series")
print(f"\n2. RAW SIGNAL OVER USB (IBidiSpl COM Object):")
print(f"   Schema Queried: \\Printer.Status.Summary:StateReason")
print(f"   Raw Response:   '{raw_signal}'")

# 3. How the Backend Reads It Right Now
status = hardware_monitor.get_printer_status()
print(f"\n3. LIVE SYSTEM STATUS RIGHT NOW:")
print(f"   System State:   {status['status']}")
print(f"   Is Ready:       {status['is_ready']}")
print(f"   Message:        {status['message']}")
print(f"   Door Sensor:    {status['sensors']['door_open']}")
print(f"   Cartridge Flag: {status['sensors']['cartridge_missing']}")
print("=" * 65)
