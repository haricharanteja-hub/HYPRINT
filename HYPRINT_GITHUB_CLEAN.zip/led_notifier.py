"""
led_notifier.py — blinks an LED on an Arduino Uno (pin 13) each time a student's upload lands.

The Arduino runs arduino/hyprint_led/hyprint_led.ino and blinks once for every 'U' byte it
receives over USB serial.

Design rules:
  * Never slow down or break an upload: blink() only drops a byte into a queue; a single
    background thread owns the serial port.
  * The port is opened ONCE and kept open. Opening a Uno's serial port resets the board
    (DTR), so re-opening per blink would swallow the signal while it reboots.
  * If the Arduino is unplugged or COM9 is busy (e.g. Arduino IDE Serial Monitor open), the
    kiosk keeps working and the thread quietly retries every few seconds.
"""

import queue
import threading
import time

import config

_SIGNAL = b"U"
_BOOT_WAIT_SECONDS = 2.0      # Uno bootloader runs ~1.5 s after the port opens
_RETRY_SECONDS = 5.0

_q: "queue.Queue[bytes]" = queue.Queue(maxsize=50)
_started = False
_start_lock = threading.Lock()


def start():
    """Start the background serial worker (idempotent). No-op if no port is configured."""
    global _started
    if not config.LED_SERIAL_PORT:
        return
    with _start_lock:
        if _started:
            return
        _started = True
    threading.Thread(target=_worker, name="led-notifier", daemon=True).start()


def blink(count=3, gap=1.0):
    """Request blinks (defaults to 3 blinks with 1s gap). Never blocks and never raises."""
    if not config.LED_SERIAL_PORT:
        return
    start()
    try:
        _q.put_nowait((_SIGNAL, count, gap))
    except queue.Full:
        pass


def _open_port():
    import serial  # pyserial
    port = serial.serial_for_url(config.LED_SERIAL_PORT, baudrate=config.LED_SERIAL_BAUD, timeout=1, write_timeout=1)
    time.sleep(_BOOT_WAIT_SECONDS)
    port.reset_input_buffer()
    print(f"[led] Arduino connected on {config.LED_SERIAL_PORT}")
    return port


def _worker():
    port = None
    last_error = None
    # Connect immediately at backend start-up: opening the port resets the Uno and its
    # bootloader flickers the pin-13 LED. Doing that now (not on the first upload) means a
    # student's upload only ever produces the intended blinks.
    try:
        port = _open_port()
    except Exception as e:
        last_error = str(e)
        print(f"[led] Arduino on {config.LED_SERIAL_PORT} not available yet: {e}")
    while True:
        item = _q.get()
        if isinstance(item, tuple):
            signal, count, gap = item
        else:
            signal, count, gap = item, 3, 1.0

        for _attempt in range(2):
            try:
                if port is None:
                    port = _open_port()
                for _i in range(count):
                    port.write(signal)
                    port.flush()
                    if _i < count - 1:
                        time.sleep(gap)
                last_error = None
                break
            except Exception as e:
                if str(e) != last_error:
                    print(f"[led] Arduino on {config.LED_SERIAL_PORT} not available: {e}")
                    last_error = str(e)
                try:
                    if port is not None:
                        port.close()
                except Exception:
                    pass
                port = None
                time.sleep(_RETRY_SECONDS if _attempt else 0.2)
