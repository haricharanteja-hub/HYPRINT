import re

with open('main.py', 'r', encoding='utf-8') as f:
    code = f.read()

# 1. Clean broadcast_job
code = re.sub(r'    pin = job\.release_pin\n\n    payload\["message"\] = message\n\n    # Send the PIN securely to the user\'s phone only\n    phone_payload = {\*\*payload}\n    if pin:\n        phone_payload\["release_pin"\] = pin\n        \n    await manager\.to_job\(job_id, phone_payload\)', '    payload["message"] = message\n    await manager.to_job(job_id, payload)', code)

# 2. Clean upload submit_job (PAYMENT_DISABLED logic)
code = re.sub(r'            release_pin=f"\{random\.randint\(1000, 9999\):04d\}" if config\.PAYMENT_DISABLED else None,\n', '', code)

# 3. Clean upload return
code = re.sub(r'        if config\.PAYMENT_DISABLED and job\.release_pin:\n            result\["release_pin"\] = job\.release_pin\n', '', code)

# 4. Clean debug_simulate_payment
code = re.sub(r'return \{"ok": True, "release_pin": pin\}', 'return {"ok": True, "simulated": True}', code)

# 5. Clean kiosk/queue
code = re.sub(r'            # PIN is NEVER sent in queue responses - it stays server-side only\n            d\.pop\("release_pin", None\)\n', '', code)
code = re.sub(r'    Live queue for the kiosk display: jobs waiting on a PIN, plus anything\n    currently on the printer.', '    Live queue for the kiosk display.', code)
code = re.sub(r'    without real money\. Still routes through hold-for-release, so the PIN\n    step gets exercised too\. Localhost \+ SIMULATE only\.', '    without real money.', code)

# 6. Make sure /api/kiosk/current-job endpoint exists as requested
current_job = """
@app.get("/api/kiosk/current-job")
async def get_current_job():
    with get_session() as s:
        # Find any job that is actively spooling or printing
        job = s.query(PrintJob).filter(PrintJob.status.in_([JobStatus.SPOOLING, JobStatus.PRINTING, JobStatus.PAUSED_ERROR])).first()
        if job:
            return job.public()
        return None
"""
if "/api/kiosk/current-job" not in code:
    code = code.replace('@app.get("/api/kiosk/queue")', current_job + '\n@app.get("/api/kiosk/queue")')

with open('main.py', 'w', encoding='utf-8') as f:
    f.write(code)
print("Cleaned main.py")
