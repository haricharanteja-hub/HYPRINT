with open('admin.html', 'r', encoding='utf-8') as f:
    code = f.read()

code = code.replace("fetch('/api/preflight')", "fetch('/api/status')")
code = code.replace("p.printer_ok ? 'Online' : 'Fault'", "p.status === 'ONLINE' ? 'Online' : 'Fault'")
code = code.replace("p.printer_ok ? 'text-emerald-400' : 'text-red-400'", "p.status === 'ONLINE' ? 'text-emerald-400' : 'text-red-400'")
code = code.replace("p.printer_ok ? 'ready' : (p.blocking_reason||'').replace(/-/g,' ')", "p.status === 'ONLINE' ? 'ready' : (p.reason||'').replace(/-/g,' ')")
code = code.replace('<th class="px-4 py-3 text-left font-semibold">PIN</th>', '<th class="px-4 py-3 text-left font-semibold">User Name</th>')
code = code.replace('<td class="px-4 py-3 font-mono text-slate-400">${j.release_pin||\'—\'}</td>', '<td class="px-4 py-3 font-semibold text-slate-300">${esc(j.user_name)||\'Student\'}</td>')

with open('admin.html', 'w', encoding='utf-8') as f:
    f.write(code)

print("Patched admin.html")
