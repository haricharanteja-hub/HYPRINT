import sqlite3
conn = sqlite3.connect("print_kiosk.db")
c = conn.cursor()
c.execute("UPDATE print_jobs SET status = 'PAID' WHERE status = 'AWAITING_RELEASE'")
conn.commit()
conn.close()
