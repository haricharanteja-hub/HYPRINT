import urllib.request
import json
import uuid
import io
import pypdf

tunnel_url = 'https://investments-mean-collected-cpu.trycloudflare.com'
print('1. Checking healthz...')
r = urllib.request.urlopen(f'{tunnel_url}/healthz', timeout=5)
print('Healthz:', r.read().decode())

def upload_files(url, fields, files_to_upload):
    boundary = uuid.uuid4().hex
    body = bytearray()
    for k, v in fields.items():
        body.extend(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode('utf-8'))
    for fname, fbytes in files_to_upload:
        body.extend(f'--{boundary}\r\nContent-Disposition: form-data; name="files"; filename="{fname}"\r\nContent-Type: application/pdf\r\n\r\n'.encode('utf-8'))
        body.extend(fbytes)
        body.extend(b'\r\n')
    body.extend(f'--{boundary}--\r\n'.encode('utf-8'))
    req = urllib.request.Request(url, data=body)
    req.add_header('Content-Type', f'multipart/form-data; boundary={boundary}')
    res = urllib.request.urlopen(req, timeout=15)
    return json.loads(res.read().decode('utf-8'))

print('2. Creating sample 10-page PDF...')
writer10 = pypdf.PdfWriter()
for i in range(10):
    writer10.add_blank_page(width=595, height=842)
buf10 = io.BytesIO()
writer10.write(buf10)
pdf10_bytes = buf10.getvalue()

print('3. Uploading first file (10 pages)...')
res1 = upload_files(f'{tunnel_url}/api/upload', {
    'user_name': 'StudentTest',
    'user_phone': '9876543210',
    'kiosk_id': '0004',
    'copies': '1',
    'duplex': 'false',
    'page_range': '',
    'pages_per_sheet': '1',
    'orientation': 'portrait'
}, [('doc10.pdf', pdf10_bytes)])

print('Res1:', res1.get('id'), 'pages:', res1.get('source_page_count'), 'files:', len(res1.get('files', [])))
job_id = res1['id']

print('4. Creating sample 2-page PDF...')
writer2 = pypdf.PdfWriter()
for i in range(2):
    writer2.add_blank_page(width=595, height=842)
buf2 = io.BytesIO()
writer2.write(buf2)
pdf2_bytes = buf2.getvalue()

print('5. Uploading second file (2 pages) to same job...')
res2 = upload_files(f'{tunnel_url}/api/upload', {
    'job_id': job_id,
    'user_name': 'StudentTest',
    'user_phone': '9876543210',
    'kiosk_id': '0004',
    'copies': '1',
    'duplex': 'false',
    'page_range': '',
    'pages_per_sheet': '1',
    'orientation': 'portrait'
}, [('doc2.pdf', pdf2_bytes)])

print('Res2:', res2.get('id'), 'pages:', res2.get('source_page_count'), 'files:', len(res2.get('files', [])))
for f in res2.get('files', []):
    print(' - file:', f['name'], 'pages:', f['pages'])
