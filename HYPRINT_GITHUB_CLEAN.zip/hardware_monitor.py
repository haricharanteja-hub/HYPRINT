"""
hardware_monitor.py — Accurate Hardware Telemetry for HP LaserJet Pro P1108 Plus.

Features:
  1. Condition A: Stuck Queue Detection (win32print.EnumJobs age > 10s or error bits).
  2. Condition B: Blacklist-Filtered Popup Detection (win32gui / user32 + psutil).
     Ignores browsers (Chrome, Edge, Firefox, Brave) and IDEs/terminals (Antigravity, Code, Python, CMD, PowerShell).
     Catches HP alerts from rundll32.exe, splwow64.exe, PrintIsolationHost.exe, HPLaserJetService.exe, etc.
  3. Condition C: True USB & PnP Offline Check (PRINTER_ATTRIBUTE_WORK_OFFLINE & WMI PnP).
  4. Spooler status bitmask inspection (status == 0 -> 100% ONLINE).
  5. Includes raw_telemetry debug object in every response.
"""

import time
import ctypes
from ctypes import wintypes
try:
    import psutil
except ImportError:
    psutil = None
import win32print
import win32service
import win32gui
import win32con
import win32process

user32 = ctypes.windll.user32
ole32 = ctypes.oledll.ole32
WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

# Blacklist ONLY browsers, editors, and dev tools to avoid self-triggering
BROWSER_AND_DEV_BLACKLIST = {
    'chrome.exe', 'msedge.exe', 'firefox.exe', 'brave.exe', 'opera.exe',
    'code.exe', 'cursor.exe', 'antigravity.exe', 'antigravity ide.exe',
    'electron.exe', 'node.exe', 'python.exe', 'pythonw.exe', 'cmd.exe',
    'powershell.exe', 'windowsterminal.exe', 'wt.exe', 'bash.exe',
    'explorer.exe', 'textinputhost.exe', 'taskhostw.exe', 'dwm.exe'
}

ALERT_KEYWORDS = [
    'cartridge', 'toner', 'door open', 'cover open', 'door is open',
    'top cover', 'top access', 'jam', 'out of paper', 'load paper',
    'paper empty', 'intervention', 'attention', 'printer error',
    'supply memory', 'install black cartridge', 'no cartridge'
]

# COM GUIDs for Windows IBidiSpl interface
class _GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", wintypes.DWORD),
        ("Data2", wintypes.WORD),
        ("Data3", wintypes.WORD),
        ("Data4", wintypes.BYTE * 8)
    ]

def _str_to_guid(s):
    g = _GUID()
    ole32.CLSIDFromString(ctypes.c_wchar_p(s), ctypes.byref(g))
    return g

_clsid_bidi_spl = _str_to_guid("{2A614240-A4C5-4C33-BD87-1BC709331639}")
_iid_bidi_spl = _str_to_guid("{D580DC0E-DE39-4649-BAA8-BF0B85A03A97}")
_clsid_bidi_req = _str_to_guid("{B9162A23-45F9-47CC-80F5-FE0FE9B9E1A2}")
_iid_bidi_req = _str_to_guid("{8F348BD7-4B47-4755-8A9D-0F422DF3DC89}")


def get_hp_bidi_state(printer_name: str = "HP LaserJet Pro P1100 plus series") -> str | None:
    """
    Directly queries the physical HP printer over USB via Windows IBidiSpl.
    Detects hardware states in real-time (e.g. 'door-open-error', 'media-empty-error',
    'media-jam-error', 'marker-supply-empty-error') even when print queue is empty!
    """
    try:
        ole32.CoInitialize(None)
        p_spl = ctypes.c_void_p()
        hr1 = ole32.CoCreateInstance(ctypes.byref(_clsid_bidi_spl), None, 1, ctypes.byref(_iid_bidi_spl), ctypes.byref(p_spl))
        p_req = ctypes.c_void_p()
        hr2 = ole32.CoCreateInstance(ctypes.byref(_clsid_bidi_req), None, 1, ctypes.byref(_iid_bidi_req), ctypes.byref(p_req))

        if hr1 != 0 or hr2 != 0 or not p_spl.value or not p_req.value:
            return None

        vt_spl = ctypes.POINTER(ctypes.c_void_p).from_address(p_spl.value)
        vt_req = ctypes.POINTER(ctypes.c_void_p).from_address(p_req.value)

        FN_Bind = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.c_wchar_p, wintypes.DWORD, wintypes.DWORD)(vt_spl[3])
        FN_Unbind = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p)(vt_spl[4])
        FN_SendRecv = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_void_p)(vt_spl[5])

        FN_SetSchema = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.c_wchar_p)(vt_req[3])
        FN_GetOutputData = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(ctypes.c_wchar_p), ctypes.POINTER(wintypes.DWORD), ctypes.POINTER(ctypes.POINTER(ctypes.c_ubyte)), ctypes.POINTER(wintypes.ULONG))(vt_req[6])

        hr_bind = FN_Bind(p_spl, printer_name, 1, 1)
        if hr_bind != 0:
            return None

        FN_SetSchema(p_req, "\\Printer.Status.Summary:StateReason")
        hr_send = FN_SendRecv(p_spl, "Get", p_req)

        val_str = ""
        if hr_send == 0:
            out_sch = ctypes.c_wchar_p()
            out_type = wintypes.DWORD()
            out_data = ctypes.POINTER(ctypes.c_ubyte)()
            out_size = wintypes.ULONG()
            hr_out = FN_GetOutputData(p_req, 0, ctypes.byref(out_sch), ctypes.byref(out_type), ctypes.byref(out_data), ctypes.byref(out_size))
            if hr_out == 0 and out_size.value > 0:
                raw = bytes(out_data[:out_size.value])
                val_str = raw.decode("utf-16le").rstrip("\x00").strip()

        FN_Unbind(p_spl)
        return val_str or None
    except Exception:
        return None

# In-memory tracking of when jobs entered the Windows print queue
_job_entry_times = {}

# 500ms cache to prevent spooler thrashing during sub-second UI polling
_cached_status = None
_cached_time = 0.0


def _is_hp_pnp_usb_connected() -> bool:
    """Checks via WMI whether an HP USB printing device (VID_03F0) is physically connected & active."""
    try:
        import win32com.client
        wmi = win32com.client.GetObject('winmgmts:')
        pnp = wmi.ExecQuery("SELECT DeviceID, Status FROM Win32_PnPEntity WHERE DeviceID LIKE '%VID_03F0%'")
        if len(pnp) > 0:
            return any(getattr(item, "Status", "OK") == "OK" for item in pnp)
        return True
    except Exception:
        return True


def _get_window_text_safe(hwnd) -> str:
    buf = ctypes.create_unicode_buffer(512)
    user32.GetWindowTextW(hwnd, buf, 512)
    return buf.value.strip()


def _check_blacklist_filtered_popups() -> dict | None:
    """
    Condition B: Scans visible alert windows on the interactive desktop (WinSta0\\default).
    Excludes all browsers and development environments.
    Inspects processes like rundll32.exe, splwow64.exe, PrintIsolationHost.exe, HPLaserJetService.exe, etc.
    """
    hwnds = []
    # 1. Query interactive user desktop
    try:
        hdesk = win32service.OpenDesktop('default', 0, True, win32con.GENERIC_ALL)
        for h in hdesk.EnumDesktopWindows():
            hwnds.append(int(h))
    except Exception:
        pass

    # 2. Also check top-level desktop window children
    try:
        top_h = win32gui.GetDesktopWindow()
        child = win32gui.GetWindow(top_h, win32con.GW_CHILD)
        while child:
            hwnds.append(child)
            child = win32gui.GetWindow(child, win32con.GW_HWNDNEXT)
    except Exception:
        pass

    seen = set()
    for hwnd in hwnds:
        if hwnd in seen:
            continue
        seen.add(hwnd)

        try:
            if not win32gui.IsWindowVisible(hwnd):
                continue

            # Strict size filter: HP alerts are small native popup dialogs (< 850x650)
            # Never scan full-screen apps or code editors
            rect = win32gui.GetWindowRect(hwnd)
            w = rect[2] - rect[0]
            h = rect[3] - rect[1]
            if w >= 850 or h >= 650 or w <= 60 or h <= 40:
                continue

            tid, pid = win32process.GetWindowThreadProcessId(hwnd)
            if not pid:
                continue

            pname = "unknown"
            if psutil:
                try:
                    pname = psutil.Process(pid).name().lower()
                except Exception:
                    pass

            if pname in BROWSER_AND_DEV_BLACKLIST or any(b in pname for b in ["electron", "chrome", "edge", "code", "cursor", "antigravity", "python", "terminal", "powershell"]):
                continue

            title = win32gui.GetWindowText(hwnd) or ""
            low_title = title.lower()

            # The window title or owning process MUST explicitly belong to the HP driver / printing subsystem
            is_hp_related = (
                any(k in pname for k in ["hp", "laserjet", "p110", "print", "spool"])
                or any(k in low_title for k in ["hp", "laserjet", "p1108", "p1100", "printing"])
            )
            if not is_hp_related:
                continue

            for kw in ALERT_KEYWORDS:
                if kw in low_title:
                    return {
                        "error_code": "PRINTER_BLOCKED",
                        "message": f"HP Alert: {title} ({pname})",
                        "matched_text": title,
                        "process": pname,
                    }

            # Scan child controls inside dialog
            child_text = []
            def child_cb(ch, _):
                ct = win32gui.GetWindowText(ch)
                if ct:
                    child_text.append(ct)
            try:
                win32gui.EnumChildWindows(hwnd, child_cb, None)
            except Exception:
                pass

            for ct in child_text:
                low_ct = ct.lower()
                for kw in ALERT_KEYWORDS:
                    if kw in low_ct:
                        return {
                            "error_code": "PRINTER_BLOCKED",
                            "message": f"HP Alert: {ct} ({pname})",
                            "matched_text": ct,
                            "process": pname,
                        }
        except Exception:
            continue

    return None


def auto_purge_stale_spooler_jobs(printer_name: str = None) -> int:
    """
    Purges stale/failed print jobs left over from previous tests in the Windows Print Queue
    when no job is actively executing.
    """
    if not printer_name:
        try:
            import cups_manager
            printer_name = cups_manager.get_active_printer_name()
        except Exception:
            printer_name = "HP LaserJet Pro P1100 plus series"

    # If actively printing right now, do not purge active jobs
    try:
        import cups_manager
        if getattr(cups_manager, "_active_printing_lock", False) or getattr(cups_manager, "is_busy", lambda: False)():
            return 0
    except Exception:
        pass

    purged = 0
    h = None
    try:
        h = win32print.OpenPrinter(printer_name, {"DesiredAccess": win32print.PRINTER_ALL_ACCESS})
    except Exception:
        try:
            h = win32print.OpenPrinter(printer_name)
        except Exception:
            return 0

    try:
        jobs = win32print.EnumJobs(h, 0, -1, 1) or []
        for j in jobs:
            jst = j.get("Status", 0) or 0
            jpst = (j.get("pStatus") or "").lower()
            is_bad = bool(jst & (
                win32print.JOB_STATUS_ERROR
                | win32print.JOB_STATUS_PAPEROUT
                | win32print.JOB_STATUS_USER_INTERVENTION
                | win32print.JOB_STATUS_BLOCKED_DEVQ
                | win32print.JOB_STATUS_OFFLINE
            )) or any(k in jpst for k in ["error", "jam", "door", "cover", "cartridge"])
            if is_bad:
                try:
                    win32print.SetJob(h, j["JobId"], 0, None, win32print.JOB_CONTROL_DELETE)
                    purged += 1
                except Exception:
                    pass
    finally:
        if h:
            try:
                win32print.ClosePrinter(h)
            except Exception:
                pass
    return purged


import threading

SERVER_START_TIME = time.time()

# ---------------------------------------------------------------------------
# PRINT QUIET MODE
# The HP LaserJet Pro P1108 is a host-based printer with ~2 pages of memory: the PC
# must stream every page to it in real time. Bidirectional USB status queries
# (IBidiSpl), WMI device scans and desktop-window scans every second compete with
# that stream and make the printer stop after every couple of pages. While a job
# is printing, cups_manager switches this module into quiet mode: only the cheap,
# local spooler state is read (it still reports jams / paper-out / door-open set by
# the HP driver), no USB traffic is generated, and no queued job is ever purged.
# ---------------------------------------------------------------------------
_print_active = threading.Event()
_last_popup_scan = 0.0
_last_popup_result = None


def set_print_active(active: bool):
    if active:
        _print_active.set()
    else:
        _print_active.clear()


def is_print_active() -> bool:
    return _print_active.is_set()
_hw_lock = threading.Lock()
CURRENT_HARDWARE_STATE = {
    "status": "BOOTING",
    "is_ready": False,
    "error_code": "BOOTING",
    "message": "Kiosk starting up... Initializing printer drivers",
    "printer_name": "HP LaserJet Pro P1100 plus series",
    "port": "USB001",
    "driver": "HP Smart Universal Printing (USB Group 2)",
    "raw_status_mask": 0,
    "raw_status_hex": "0x00000000",
    "spooler_jobs_count": 0,
    "sensors": {
        "paper_tray_empty": False,
        "paper_jam": False,
        "door_open": False,
        "toner_low": False,
        "toner_empty": False,
        "cartridge_missing": False,
        "offline": False,
        "busy": False,
        "hardware_error": False,
    },
    "raw_telemetry": {
        "printer_name": "HP LaserJet Pro P1100 plus series",
        "spooler_status_int": 0,
        "attributes_int": 0,
        "active_jobs_count": 0,
        "job_status_int": 0,
    },
    "timestamp": time.time(),
}

def _hardware_polling_worker():
    """Isolated background daemon polling thread. Runs every 1.0s to eliminate FastAPI request blocking."""
    global CURRENT_HARDWARE_STATE
    while True:
        try:
            raw = _fetch_raw_printer_status()
            now = time.time()
            if not raw.get("is_ready", True) and (now - SERVER_START_TIME < 3.0):
                # 3-second boot-up grace period: prevent false maintenance locks during initial driver poll
                raw = dict(raw)
                raw["status"] = "BOOTING"
                raw["is_ready"] = False
                raw["message"] = "Kiosk starting up... Initializing printer hardware"
            with _hw_lock:
                CURRENT_HARDWARE_STATE = raw
        except Exception as e:
            pass
        time.sleep(2.0 if _print_active.is_set() else 1.0)

_poll_thread = threading.Thread(target=_hardware_polling_worker, daemon=True, name="HardwareMonitorThread")
_poll_thread.start()


def get_printer_status() -> dict:
    """Instant O(1) thread-safe access to live hardware state without blocking FastAPI loop."""
    with _hw_lock:
        return dict(CURRENT_HARDWARE_STATE)


def _fetch_raw_printer_status() -> dict:
    """
    Inspects:
      1. Condition A: Stuck jobs in Windows Print Queue (win32print.EnumJobs age > 10s or error bits).
      2. Condition B: Blacklist-filtered HP driver popup alert windows.
      3. Condition C: USB & PnP connectivity.
      4. Spooler GetPrinter status bitmask.
    """
    global _cached_status, _cached_time, _job_entry_times, _last_popup_scan, _last_popup_result
    now = time.time()
    printing_now = _print_active.is_set()
    if _cached_status and (now - _cached_time) < 0.5:
        return dict(_cached_status)

    try:
        import cups_manager
        printer_name = cups_manager.get_active_printer_name()
    except Exception:
        printer_name = "HP LaserJet Pro P1100 plus series"

    handle = None
    try:
        handle = win32print.OpenPrinter(printer_name)
        info = win32print.GetPrinter(handle, 2)
        status = info.get("Status", 0) or 0
        attributes = info.get("Attributes", 0) or 0
        port_name = info.get("pPortName", "USB001")
        driver_name = info.get("pDriverName", "HP LaserJet Pro P1100 plus series")

        # Read active print queue jobs
        jobs = win32print.EnumJobs(handle, 0, -1, 1) or []
        
        # If any ghost jobs have error bits while idle, purge them immediately
        # (never while a student's job is printing — that used to delete live jobs)
        if jobs and not printing_now:
            try:
                import cups_manager
                is_idle = not (getattr(cups_manager, "_active_printing_lock", False) or getattr(cups_manager, "is_busy", lambda: False)())
                if is_idle:
                    purged_count = auto_purge_stale_spooler_jobs(printer_name)
                    if purged_count > 0:
                        jobs = win32print.EnumJobs(handle, 0, -1, 1) or []
            except Exception:
                pass

        active_jobs_count = len(jobs)
        first_job_status = jobs[0].get("Status", 0) if active_jobs_count > 0 else 0
        first_job_pstatus = (jobs[0].get("pStatus") or "") if active_jobs_count > 0 else ""

        raw_telemetry = {
            "printer_name": printer_name,
            "spooler_status_int": status,
            "attributes_int": attributes,
            "active_jobs_count": active_jobs_count,
            "job_status_int": first_job_status,
            "job_pstatus": first_job_pstatus,
            "raw_status_hex": f"0x{status:08X}",
            "port": port_name,
            "driver": driver_name,
            "timestamp": now,
        }

        # ---------------------------------------------------------------------
        # Condition 0: Real-time IBidiSpl Hardware Sensor Query (Missing Cartridge / Door Open / Out of Paper / Jam)
        # ---------------------------------------------------------------------
        bidi_raw = None if printing_now else get_hp_bidi_state(printer_name)
        bidi_low = (bidi_raw or "").lower()
        is_bidi_fatal = bool(bidi_raw and ("error" in bidi_low or any(k in bidi_low for k in ["door-open", "media-jam", "media-empty", "cover-open"])))
        is_toner_low_warning = bool(bidi_raw and "warning" in bidi_low and ("marker" in bidi_low or "supply" in bidi_low or "toner" in bidi_low))

        if is_bidi_fatal:
            code = "DOOR_OPEN" if ("door" in bidi_low or "cover" in bidi_low) else \
                   "TONER_EMPTY" if ("marker-supply-empty" in bidi_low or "toner-empty" in bidi_low) else \
                   "CARTRIDGE_MISSING" if ("cartridge" in bidi_low or "missing" in bidi_low) else \
                   "OUT_OF_PAPER" if ("empty" in bidi_low or "media-empty" in bidi_low or "paper" in bidi_low) else \
                   "PAPER_JAM" if "jam" in bidi_low else "PRINTER_BLOCKED"
            msg = "Top Access Cover Open or Toner Cartridge Missing" if code in ("DOOR_OPEN", "CARTRIDGE_MISSING") else \
                  "Toner Cartridge Completely Empty — Replace Toner" if code == "TONER_EMPTY" else \
                  "Paper Tray Empty — Load Paper to Continue" if code == "OUT_OF_PAPER" else \
                  "Paper Jam Detected" if code == "PAPER_JAM" else f"Hardware Error: {bidi_raw}"

            res = {
                "status": "MAINTENANCE",
                "is_ready": False,
                "error_code": code,
                "message": msg,
                "printer_name": printer_name,
                "port": port_name,
                "driver": driver_name,
                "raw_status_mask": status,
                "raw_status_hex": f"0x{status:08X}",
                "spooler_jobs_count": active_jobs_count,
                "sensors": {
                    "paper_tray_empty": code == "OUT_OF_PAPER",
                    "paper_jam": code == "PAPER_JAM",
                    "door_open": code in ("DOOR_OPEN", "CARTRIDGE_MISSING"),
                    "toner_low": is_toner_low_warning,
                    "toner_empty": code == "TONER_EMPTY",
                    "cartridge_missing": code in ("DOOR_OPEN", "CARTRIDGE_MISSING"),
                    "offline": False,
                    "busy": False,
                    "hardware_error": True,
                },
                "raw_telemetry": raw_telemetry,
                "timestamp": now,
            }
            _cached_status = res
            _cached_time = now
            return res

        # ---------------------------------------------------------------------
        # Condition C: USB & Spooler Offline Check
        # ---------------------------------------------------------------------
        is_work_offline = bool(attributes & win32print.PRINTER_ATTRIBUTE_WORK_OFFLINE)
        is_status_offline = bool(status & win32print.PRINTER_STATUS_OFFLINE)
        is_pnp_connected = True if printing_now else _is_hp_pnp_usb_connected()

        # Auto-recover: if Windows toggled "Work Offline" but USB is physically connected, clear it!
        if is_work_offline and is_pnp_connected:
            try:
                info_copy = dict(info)
                info_copy["Attributes"] = attributes & (~win32print.PRINTER_ATTRIBUTE_WORK_OFFLINE)
                win32print.SetPrinter(h, 2, info_copy, 0)
                info_fresh = win32print.GetPrinter(h, 2)
                attributes = info_fresh.get("Attributes", 0) or 0
                is_work_offline = bool(attributes & win32print.PRINTER_ATTRIBUTE_WORK_OFFLINE)
                raw_telemetry["attributes_int"] = attributes
            except Exception as auto_rec_err:
                pass

        if is_work_offline or is_status_offline or not is_pnp_connected:
            res = {
                "status": "MAINTENANCE",
                "is_ready": False,
                "error_code": "OFFLINE",
                "message": "Printer Offline / USB Disconnected",
                "printer_name": printer_name,
                "port": port_name,
                "driver": driver_name,
                "raw_status_mask": status,
                "raw_status_hex": f"0x{status:08X}",
                "spooler_jobs_count": active_jobs_count,
                "sensors": {
                    "paper_tray_empty": False,
                    "paper_jam": False,
                    "door_open": False,
                    "toner_low": False,
                    "toner_empty": False,
                    "cartridge_missing": False,
                    "offline": True,
                    "busy": False,
                    "hardware_error": True,
                },
                "raw_telemetry": raw_telemetry,
                "timestamp": now,
            }
            _cached_status = res
            _cached_time = now
            return res

        # ---------------------------------------------------------------------
        # Condition A: Stuck Jobs in the Windows Print Queue (EnumJobs)
        # ---------------------------------------------------------------------
        ERR_JOB_MASK = (
            win32print.JOB_STATUS_ERROR
            | win32print.JOB_STATUS_PAPEROUT
            | win32print.JOB_STATUS_USER_INTERVENTION
            | win32print.JOB_STATUS_OFFLINE
            | win32print.JOB_STATUS_BLOCKED_DEVQ
        )

        current_jids = set()
        for j in jobs:
            jid = j.get("JobId")
            current_jids.add(jid)
            if jid not in _job_entry_times:
                _job_entry_times[jid] = now

            age = now - _job_entry_times[jid]
            jst = j.get("Status", 0) or 0
            jpst = (j.get("pStatus") or "").strip().lower()

            has_err_bit = bool(jst & ERR_JOB_MASK)
            has_paper_err = (jst & win32print.JOB_STATUS_PAPEROUT) or any(k in jpst for k in ["paper out", "out of paper", "load paper", "no paper", "paper empty"])
            has_jam_err = any(k in jpst for k in ["jam", "paper jam"])
            has_door_err = any(k in jpst for k in ["door", "cover", "top cover", "lid"])
            has_cartridge_err = any(k in jpst for k in ["cartridge", "toner", "no cartridge", "toner empty"])
            has_explicit_err = bool(has_paper_err or has_jam_err or has_door_err or has_cartridge_err or ("error" in jpst and "no error" not in jpst))
            is_active_progress = bool(jst & (win32print.JOB_STATUS_PRINTING | win32print.JOB_STATUS_SPOOLING | 0x00000080)) or ("print" in jpst or "spool" in jpst)

            # Only trigger fault if explicit genuine hardware error bit/text while NOT in active progress, or if stalled without progress for >60s:
            if (not is_active_progress and (has_err_bit or has_explicit_err)) or (age > 60.0 and not printing_now and not is_active_progress and active_jobs_count > 0):
                msg = j.get("pStatus") or "Printer Blocked: Check Toner Cartridge, Top Cover, or Paper Tray"
                code = "PRINTER_BLOCKED"
                if has_paper_err:
                    code = "OUT_OF_PAPER"
                    msg = "Out of Paper — Load Tray to Continue"
                elif has_jam_err:
                    code = "PAPER_JAM"
                    msg = "Paper Jam Detected"
                elif has_door_err or has_cartridge_err:
                    code = "DOOR_OPEN"
                    msg = "Top Cover Open or Cartridge Missing"

                res = {
                    "status": "MAINTENANCE",
                    "is_ready": False,
                    "error_code": code,
                    "message": msg,
                    "printer_name": printer_name,
                    "port": port_name,
                    "driver": driver_name,
                    "raw_status_mask": status,
                    "raw_status_hex": f"0x{status:08X}",
                    "spooler_jobs_count": active_jobs_count,
                    "sensors": {
                        "paper_tray_empty": code == "OUT_OF_PAPER",
                        "paper_jam": code == "PAPER_JAM",
                        "door_open": code == "DOOR_OPEN",
                        "toner_low": False,
                        "toner_empty": False,
                        "cartridge_missing": code in ("DOOR_OPEN", "PRINTER_BLOCKED"),
                        "offline": False,
                        "busy": False,
                        "hardware_error": True,
                    },
                    "raw_telemetry": raw_telemetry,
                    "timestamp": now,
                }
                _cached_status = res
                _cached_time = now
                return res

        # Prune cleared jobs
        for old_jid in list(_job_entry_times.keys()):
            if old_jid not in current_jids:
                _job_entry_times.pop(old_jid, None)

        # ---------------------------------------------------------------------
        # Condition B: Blacklist-Filtered Popup Detection
        # ---------------------------------------------------------------------
        if printing_now and (now - _last_popup_scan) < 5.0:
            popup_err = _last_popup_result          # throttle the desktop scan while printing
        else:
            popup_err = _check_blacklist_filtered_popups()
            _last_popup_scan, _last_popup_result = now, popup_err
        if popup_err:
            res = {
                "status": "MAINTENANCE",
                "is_ready": False,
                "error_code": "PRINTER_BLOCKED",
                "message": popup_err["message"],
                "printer_name": printer_name,
                "port": port_name,
                "driver": driver_name,
                "raw_status_mask": status,
                "raw_status_hex": f"0x{status:08X}",
                "spooler_jobs_count": active_jobs_count,
                "sensors": {
                    "paper_tray_empty": "paper" in popup_err["message"].lower(),
                    "paper_jam": "jam" in popup_err["message"].lower(),
                    "door_open": "door" in popup_err["message"].lower() or "cover" in popup_err["message"].lower(),
                    "toner_low": False,
                    "toner_empty": "toner" in popup_err["message"].lower() or "cartridge" in popup_err["message"].lower(),
                    "cartridge_missing": "cartridge" in popup_err["message"].lower(),
                    "offline": False,
                    "busy": False,
                    "hardware_error": True,
                },
                "raw_telemetry": raw_telemetry,
                "timestamp": now,
            }
            _cached_status = res
            _cached_time = now
            return res

        # ---------------------------------------------------------------------
        # Spooler Status Bitmask (GetPrinter)
        # ---------------------------------------------------------------------
        if status & win32print.PRINTER_STATUS_PAPER_JAM:
            res = {
                "status": "MAINTENANCE",
                "is_ready": False,
                "error_code": "PAPER_JAM",
                "message": "Paper Jam Detected",
                "printer_name": printer_name,
                "port": port_name,
                "driver": driver_name,
                "raw_status_mask": status,
                "raw_status_hex": f"0x{status:08X}",
                "spooler_jobs_count": active_jobs_count,
                "sensors": {"paper_tray_empty": False, "paper_jam": True, "door_open": False, "toner_low": False, "toner_empty": False, "cartridge_missing": False, "offline": False, "busy": False, "hardware_error": True},
                "raw_telemetry": raw_telemetry,
                "timestamp": now,
            }
            _cached_status = res
            _cached_time = now
            return res

        if status & (win32print.PRINTER_STATUS_PAPER_OUT | win32print.PRINTER_STATUS_PAPER_PROBLEM):
            res = {
                "status": "MAINTENANCE",
                "is_ready": False,
                "error_code": "OUT_OF_PAPER",
                "message": "Out of Paper",
                "printer_name": printer_name,
                "port": port_name,
                "driver": driver_name,
                "raw_status_mask": status,
                "raw_status_hex": f"0x{status:08X}",
                "spooler_jobs_count": active_jobs_count,
                "sensors": {"paper_tray_empty": True, "paper_jam": False, "door_open": False, "toner_low": False, "toner_empty": False, "cartridge_missing": False, "offline": False, "busy": False, "hardware_error": True},
                "raw_telemetry": raw_telemetry,
                "timestamp": now,
            }
            _cached_status = res
            _cached_time = now
            return res

        if status & win32print.PRINTER_STATUS_DOOR_OPEN:
            res = {
                "status": "MAINTENANCE",
                "is_ready": False,
                "error_code": "DOOR_OPEN",
                "message": "Top Cover Open or Cartridge Missing",
                "printer_name": printer_name,
                "port": port_name,
                "driver": driver_name,
                "raw_status_mask": status,
                "raw_status_hex": f"0x{status:08X}",
                "spooler_jobs_count": active_jobs_count,
                "sensors": {"paper_tray_empty": False, "paper_jam": False, "door_open": True, "toner_low": False, "toner_empty": False, "cartridge_missing": True, "offline": False, "busy": False, "hardware_error": True},
                "raw_telemetry": raw_telemetry,
                "timestamp": now,
            }
            _cached_status = res
            _cached_time = now
            return res

        if status & (win32print.PRINTER_STATUS_ERROR | win32print.PRINTER_STATUS_USER_INTERVENTION):
            res = {
                "status": "MAINTENANCE",
                "is_ready": False,
                "error_code": "HARDWARE_ERROR",
                "message": "Printer Requires Attention",
                "printer_name": printer_name,
                "port": port_name,
                "driver": driver_name,
                "raw_status_mask": status,
                "raw_status_hex": f"0x{status:08X}",
                "spooler_jobs_count": active_jobs_count,
                "sensors": {"paper_tray_empty": False, "paper_jam": False, "door_open": False, "toner_low": False, "toner_empty": False, "cartridge_missing": False, "offline": False, "busy": False, "hardware_error": True},
                "raw_telemetry": raw_telemetry,
                "timestamp": now,
            }
            _cached_status = res
            _cached_time = now
            return res

        # ---------------------------------------------------------------------
        # Status == 0 and no stuck jobs -> 100% ONLINE and READY
        # ---------------------------------------------------------------------
        is_busy = bool(status & (win32print.PRINTER_STATUS_BUSY | win32print.PRINTER_STATUS_PRINTING | win32print.PRINTER_STATUS_PROCESSING))
        res = {
            "status": "ONLINE",
            "is_ready": True,
            "error_code": "NONE",
            "message": "Printing in progress" if is_busy else "Ready to Print",
            "printer_name": printer_name,
            "port": port_name,
            "driver": driver_name,
            "raw_status_mask": status,
            "raw_status_hex": f"0x{status:08X}",
            "spooler_jobs_count": active_jobs_count,
            "sensors": {
                "paper_tray_empty": False,
                "paper_jam": False,
                "door_open": False,
                "toner_low": is_toner_low_warning,
                "toner_empty": False,
                "cartridge_missing": False,
                "offline": False,
                "busy": is_busy,
                "hardware_error": False,
            },
            "raw_telemetry": raw_telemetry,
            "timestamp": now,
        }
        _cached_status = res
        _cached_time = now
        return res

    except Exception as e:
        err_res = {
            "status": "MAINTENANCE",
            "is_ready": False,
            "error_code": "OFFLINE",
            "message": f"Printer Unreachable / Offline ({e})",
            "printer_name": printer_name,
            "port": "USB001",
            "driver": "Unknown",
            "raw_status_mask": 0,
            "raw_status_hex": "0x00000000",
            "spooler_jobs_count": 0,
            "sensors": {
                "paper_tray_empty": False,
                "paper_jam": False,
                "door_open": False,
                "toner_low": False,
                "toner_empty": False,
                "cartridge_missing": False,
                "offline": True,
                "busy": False,
                "hardware_error": True,
            },
            "raw_telemetry": {
                "printer_name": printer_name,
                "spooler_status_int": -1,
                "attributes_int": -1,
                "active_jobs_count": 0,
                "job_status_int": 0,
                "error": str(e),
            },
            "timestamp": now,
        }
        _cached_status = err_res
        _cached_time = now
        return err_res
    finally:
        if handle:
            try:
                win32print.ClosePrinter(handle)
            except Exception:
                pass
