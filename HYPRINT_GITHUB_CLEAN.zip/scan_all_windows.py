import win32service, win32gui, win32con, win32process, psutil

hdesk = win32service.OpenDesktop('default', 0, True, win32con.GENERIC_ALL)
hwnds = hdesk.EnumDesktopWindows()
print(f"Total HWNDs on default desktop: {len(hwnds)}")

all_windows = []
for h in hwnds:
    t = win32gui.GetWindowText(h)
    vis = win32gui.IsWindowVisible(h)
    tid, pid = win32process.GetWindowThreadProcessId(h)
    pname = "unknown"
    try:
        pname = psutil.Process(pid).name()
    except Exception:
        pass
    
    # Check child windows
    children = []
    def enum_child(ch, _):
        ct = win32gui.GetWindowText(ch)
        if ct:
            children.append(ct)
    try:
        win32gui.EnumChildWindows(h, enum_child, None)
    except Exception:
        pass
        
    all_windows.append((vis, pname, pid, int(h), t, children))

print("\n--- ALL WINDOWS WITH TITLES OR CHILDREN ---")
for vis, pname, pid, h, t, children in all_windows:
    if t or children:
        vis_str = "VIS" if vis else "HID"
        print(f"[{vis_str}] [{pname:22}] PID={pid:6} HWND={h:8} | Title: '{t}' | Children: {children[:3]}")
