import requests
import json
import io

print("Testing job submission flow...")

# Create a minimal 1-page PDF
pdf_bytes = b"%PDF-1.4\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] >>\nendobj\nxref\n0 4\n0000000000 65535 f \n0000000009 00000 n \n0000000058 00000 n \n0000000115 00000 n \ntrailer\n<< /Size 4 /Root 1 0 R >>\nstartxref\n186\n%%EOF\n"

files = {
    'files': ('test_doc.pdf', io.BytesIO(pdf_bytes), 'application/pdf')
}
data = {
    'user_name': 'SelfTest User',
    'user_phone': '9876543210',
    'copies': '1',
    'duplex': 'false',
    'paper_size': 'A4',
    'pages_per_sheet': '1'
}

r = requests.post("http://127.0.0.1:8000/api/submit-job", files=files, data=data)
print(f"Submit Job response: {r.status_code}")
res_json = r.json()
print("Response:", json.dumps(res_json, indent=2))
assert r.status_code == 200, "Submit failed"

job_id = res_json.get("job_id") or res_json.get("id")
pin = res_json.get("release_pin")
print(f"Created Job ID: {job_id}, Release PIN: {pin}")

# Check job status
r_job = requests.get(f"http://127.0.0.1:8000/api/job/{job_id}")
print(f"Job Status: {r_job.json().get('status')}")
assert r_job.status_code == 200

print("Job flow test successful!")
