import win32print
import ctypes
from ctypes import wintypes
import psutil

print("=== CHECKING PRINTERS & QUEUES ===")
for name in ['HP LaserJet Pro P1100 plus series', 'HP LaserJet Pro P1100 plus series (Copy 1)', 'HP LaserJet 1020']:
    try:
        h = win32print.OpenPrinter(name)
        info = win32print.GetPrinter(h, 2)
        jobs = win32print.EnumJobs(h, 0, -1, 1)
        print(f"\nPrinter: {name}")
        print(f"  Port: {info.get('pPortName')}")
        print(f"  Driver: {info.get('pDriverName')}")
        print(f"  Status: {info.get('Status')} (hex: 0x{info.get('Status'):08X})")
        print(f"  Attributes: {info.get('Attributes')}")
        print(f"  Jobs in queue: {len(jobs)}")
        for j in jobs:
            print(f"    Job ID {j.get('JobId')}: Status={j.get('Status')} (0x{j.get('Status'):08X}), pStatus='{j.get('pStatus')}', doc='{j.get('pDocument')}'")
        win32print.ClosePrinter(h)
    except Exception as e:
        print(f"{name} error: {e}")

print("\n=== SCANNING ALL VISIBLE WINDOWS & PROCESSES ===")
user32 = ctypes.windll.user32
WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

found_windows = []

def enum_cb(hwnd, lparam):
    if not user32.IsWindowVisible(hwnd):
        return 1
    length = user32.GetWindowTextLengthW(hwnd)
    if length == 0:
        return 1
    buf = ctypes.create_unicode_buffer(length + 1)
    user32.GetWindowTextW(hwnd, buf, length + 1)
    title = buf.value.strip()
    if not title:
        return 1

    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    pname = "unknown"
    try:
        pname = psutil.Process(pid.value).name().lower()
    except Exception:
        pass

    found_windows.append((pname, title, pid.value, hwnd))
    return 1

cb = WNDENUMPROC(enum_cb)
user32.EnumWindows(cb, 0)

print(f"Found {len(found_windows)} visible windows:")
for pname, title, pid, hwnd in found_windows:
    # Highlight HP or spooler or alert windows
    is_hp = any(k in pname or k in title.lower() for k in ['hp', 'laserjet', 'print', 'spool', 'rundll', 'status', 'error', 'warn'])
    prefix = "[TARGET] " if is_hp else "         "
    print(f"{prefix}{pname:25} | PID: {pid:6} | Title: {title}")
