import win32print
for p in win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL):
    print(p[2])
