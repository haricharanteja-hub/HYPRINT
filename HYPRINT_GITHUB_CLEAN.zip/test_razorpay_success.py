"""
test_razorpay_success.py — Test normal clean print completion workflow
"""
import os
import requests
import pymupdf

BASE_URL = "http://127.0.0.1:8000"

doc = pymupdf.open()
p = doc.new_page(width=595, height=842)
p.insert_text((72, 100), "HYPRINT CLEAN PRINT TEST", fontsize=20)
doc.save("test_clean.pdf")
doc.close()

with open("test_clean.pdf", "rb") as f:
    res = requests.post(f"{BASE_URL}/api/submit-job", files=[("files", ("test_clean.pdf", f, "application/pdf"))],
        data={"is_final_approval": "true", "user_name": "Success Student", "user_phone": "9876543210"})
job_id = res.json()["id"]

order_res = requests.post(f"{BASE_URL}/api/payment/create-order", json={"job_id": job_id, "selected_pages": [1], "copies": 1})
order_data = order_res.json()
print("Order created:", order_data)

verify_res = requests.post(f"{BASE_URL}/api/payment/verify-and-print", json={
    "job_id": job_id,
    "razorpay_order_id": order_data["order_id"],
    "razorpay_payment_id": "pay_test_clean_12345",
    "razorpay_signature": f"mock_sig_{order_data['order_id']}",
    "selected_pages": [1],
    "copies": 1
})
print("Verify & Print status:", verify_res.status_code)
print("Verify & Print body:", verify_res.json())

if os.path.exists("test_clean.pdf"):
    os.remove("test_clean.pdf")
