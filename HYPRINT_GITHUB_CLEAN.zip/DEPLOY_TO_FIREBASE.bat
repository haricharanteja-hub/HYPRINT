@echo off
title Deploy to Firebase
cd /d "C:\Users\Student\.gemini\antigravity-ide\scratch\HYPRINT"

echo ===================================================
echo        DEPLOYING HYPRINT TO FIREBASE HOSTING
echo ===================================================
echo.
npx -y firebase-tools deploy --only hosting --project hyprint-64865
echo.
echo ===================================================
echo Your website is live at: https://hyprint-64865.web.app
echo ===================================================
pause
