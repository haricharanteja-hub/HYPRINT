import re

with open('cups_manager.py', 'r', encoding='utf-8') as f:
    code = f.read()

# Fix SumatraPDF arguments to include landscape
sumatra_args_old = """    if opts.get("duplex"):
        settings_parts.append("duplex")
    else:
        # Some drivers ignore duplex unless explicitly set to simplex when previously set
        settings_parts.append("simplex")"""

sumatra_args_new = """    if opts.get("duplex"):
        settings_parts.append("duplex")
    else:
        # Some drivers ignore duplex unless explicitly set to simplex when previously set
        settings_parts.append("simplex")

    if opts.get("orientation") == "landscape":
        settings_parts.append("landscape")"""

code = code.replace(sumatra_args_old, sumatra_args_new)

# Upgrade PyMuPDF GDI from 300 to 600 DPI, and increase darkness
gdi_old = """        contrast_enhancer = 1.4
        dark_table = [min(255, int((i / 255.0) ** 1.35 * 255)) for i in range(256)]

        hdc.StartDoc(title)
        try:
            for copy_idx in range(copies):
                for page in doc:
                    hdc.StartPage()
                    # 300 DPI grayscale (csGRAY) = 1 byte per pixel, crisp and lightweight
                    pix = page.get_pixmap(dpi=300, colorspace=pymupdf.csGRAY)
                    img = Image.frombytes("L", [pix.width, pix.height], pix.samples)

                    # --- Darkness & Contrast Boost for laser toner ---
                    img = ImageEnhance.Contrast(img).enhance(contrast_enhancer)
                    img = img.point(dark_table)"""

gdi_new = """        contrast_enhancer = 1.8
        # Use a stronger gamma (2.5) to pull light grays heavily towards pure black
        dark_table = [min(255, int((i / 255.0) ** 2.5 * 255)) for i in range(256)]

        hdc.StartDoc(title)
        try:
            for copy_idx in range(copies):
                for page in doc:
                    hdc.StartPage()
                    # 600 DPI for extremely high resolution native printing
                    pix = page.get_pixmap(dpi=600, colorspace=pymupdf.csGRAY)
                    img = Image.frombytes("L", [pix.width, pix.height], pix.samples)

                    # --- Aggressive Darkness & Contrast Boost for laser toner ---
                    img = ImageEnhance.Contrast(img).enhance(contrast_enhancer)
                    img = img.point(dark_table)"""

code = code.replace(gdi_old, gdi_new)

# Force SumatraPDF for ALL prints (since it sends vectors, which is infinite DPI and pure black)
# The GDI fallback will only execute if Sumatra fails.
force_sumatra_old = """    # For simplex prints, use native Windows GDI directly with contrast & darkness boost.
    # For duplex prints, use SumatraPDF with duplex print settings.
    if not opts.get("duplex"):
        print(f"[print] Using native Windows GDI with toner darkness boost for '{printer_name}'")
        return _print_windows_gdi(abs_path, printer_name, title, opts=opts)"""

force_sumatra_new = """    # We now route ALL prints through SumatraPDF natively to preserve vector data
    # (infinite resolution, 100% pure black text) instead of rasterizing via GDI.
    # GDI is strictly kept as a fallback mechanism if SumatraPDF hangs.
    # We removed the simplex/GDI override."""

code = code.replace(force_sumatra_old, force_sumatra_new)

with open('cups_manager.py', 'w', encoding='utf-8') as f:
    f.write(code)

print("Patched cups_manager.py")
