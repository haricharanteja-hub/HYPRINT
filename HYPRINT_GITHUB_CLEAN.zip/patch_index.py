import re

with open('index.html', 'r', encoding='utf-8') as f:
    code = f.read()

# 1. Inject User Name input before the dropzone (lines around 990)
user_name_html = """
      <div style="margin-bottom:16px;">
        <label style="display:block; font-size:13px; font-weight:600; color:var(--text-secondary); margin-bottom:8px;">Your Name</label>
        <input id="user-name" type="text" placeholder="John Doe" style="width:100%; padding:12px; border:1.5px solid var(--border); border-radius:var(--radius); font-size:15px; outline:none; transition:border-color 0.15s;" onfocus="this.style.borderColor='var(--green)'" onblur="this.style.borderColor='var(--border)'" />
      </div>
"""
code = code.replace('<div class="section">\n      <div class="section-label">1. Document</div>', '<div class="section">\n      <div class="section-label">1. Document</div>\n' + user_name_html)

# 2. Add Hardware Check overlay at the top of the body
hw_html = """
<div id="hw-lock-overlay" style="display:none; position:fixed; inset:0; background:rgba(255,255,255,0.95); z-index:9999; flex-direction:column; align-items:center; justify-content:center; padding:20px; text-align:center;">
  <svg style="width:64px;height:64px;color:#EF4444;margin-bottom:16px;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
  <h2 style="font-size:24px;font-weight:800;color:#7F1D1D;margin-bottom:8px;">Printer Unavailable</h2>
  <p id="hw-lock-reason" style="font-size:15px;color:#B91C1C;font-weight:500;">The hardware is currently offline or requires maintenance.</p>
</div>
"""
code = code.replace('<div class="app-container">', hw_html + '\n<div class="app-container">')

# 3. Add Hardware polling logic to JS
hw_js = """
  async function checkHardwareStatus() {
    try {
      const res = await fetch(apiUrl('/api/status'));
      const data = await res.json();
      if (data.status !== 'ONLINE') {
        document.getElementById('hw-lock-overlay').style.display = 'flex';
        document.getElementById('hw-lock-reason').innerText = data.reason || 'Printer is currently unreachable.';
      } else {
        document.getElementById('hw-lock-overlay').style.display = 'none';
      }
    } catch (e) {
      setTimeout(checkHardwareStatus, 3000);
    }
  }
  checkHardwareStatus();
  setInterval(checkHardwareStatus, 5000);
"""
code = code.replace('// --- Initialization ---', '// --- Initialization ---\n' + hw_js)

# 4. Modify submitJob payload to include user_name
code = code.replace("formData.append('user_name', S.userName);", "formData.append('user_name', document.getElementById('user-name') ? document.getElementById('user-name').value || 'Student' : S.userName);")

# 5. Hide PIN box natively
code = code.replace('<div class="pin-box">', '<div class="pin-box" style="display:none !important;">')
code = code.replace('<p id="job-status-message" class="job-message">Walk to the kiosk, press "Enter PIN", and punch in your code.</p>', '<p id="job-status-message" class="job-message">Your print is spooling...</p>')

# 6. Skip PIN waiting state in Payment callback
payment_callback_old = """    // We got standard webhook confirmation!
    if (data.release_pin) {
      S.releasePin = String(data.release_pin).trim();
      document.getElementById('release-pin-display').innerText = S.releasePin.split('').join(' ');
    }
    
    document.getElementById('job-status-pill').innerText = 'Payment Confirmed';
    document.getElementById('job-status-pill').style.background = 'var(--green-light)';
    document.getElementById('job-status-pill').style.color = 'var(--green-dark)';
    document.getElementById('job-status-message').innerText = 'Walk to the kiosk to release your print.';
    
    // Direct PIN release from backend if payment disabled:
    if (data.payment_disabled && data.release_pin) {
      const title = document.querySelector('.section-label.pin-ready-title');
      const sub = document.querySelector('.pin-ready-sub');
      if (title) title.innerText = `Hey ${S.userName}! Your PIN is Ready`;
      if (sub) sub.innerHTML = `Walk up to the <b>Kiosk</b>. Look for <b>${S.userName}</b> on the screen and enter your PIN <b>${S.releasePin}</b> to preview &amp; print.`;
    }"""
payment_callback_new = """    // We got standard webhook confirmation!
    document.getElementById('job-status-pill').innerText = 'Printing Document';
    document.getElementById('job-status-pill').style.background = 'var(--green-light)';
    document.getElementById('job-status-pill').style.color = 'var(--green-dark)';
    document.getElementById('job-status-message').innerText = 'Your document is being printed right now. Please collect it from the tray.';
"""
code = code.replace(payment_callback_old, payment_callback_new)

# 7. Update Simulate Payment callback
sim_pay_old = """        if (data.release_pin && !S.releasePin) {
          S.releasePin = String(data.release_pin).trim();
          document.getElementById('release-pin-display').innerText = S.releasePin.split('').join(' ');
        }
        document.getElementById('job-status-pill').innerText = 'Payment Confirmed';
        document.getElementById('job-status-pill').style.background = 'var(--green-light)';
        document.getElementById('job-status-pill').style.color = 'var(--green-dark)';
        document.getElementById('job-status-message').innerText = 'Walk to the kiosk to release your print.';
        if (data.simulated) {
            const title = document.querySelector('.section-label.pin-ready-title');
            const sub = document.querySelector('.pin-ready-sub');
            if (title) title.innerText = `Hey ${S.userName}! Your PIN is Ready`;
            if (sub) sub.innerHTML = `Walk up to the <b>Kiosk</b>. Look for <b>${S.userName}</b> on the screen and enter your PIN <b>${S.releasePin}</b> to preview &amp; print.`;
        }"""
sim_pay_new = """        document.getElementById('job-status-pill').innerText = 'Printing Document';
        document.getElementById('job-status-pill').style.background = 'var(--green-light)';
        document.getElementById('job-status-pill').style.color = 'var(--green-dark)';
        document.getElementById('job-status-message').innerText = 'Your document is being printed right now. Please collect it from the tray.';
"""
code = code.replace(sim_pay_old, sim_pay_new)

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(code)

print("Patched index.html")
