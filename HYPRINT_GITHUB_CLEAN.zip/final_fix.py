import re

with open('kiosk.html', 'r', encoding='utf-8') as f:
    code = f.read()

# 1. Fix the top right QR code image
code = code.replace('<img id="kiosk-qr-img" class="qr-banner-img" src="/kiosk_qr.png" alt="Scan QR" />', '<img id="kiosk-qr-img" class="qr-banner-img" src="kiosk_qr.png" alt="Scan QR" />')

# 2. Inject fetchHardware
fetch_js = """// Global Error Boundary to prevent any crashes
  async function fetchHardware() {
    try {
      const s = await fetch('/api/status');
      const d = await s.json();
      const beacon = document.getElementById('printer-beacon');
      const text = document.getElementById('printer-line-text');
      if(d.status === 'ONLINE') {
        if(beacon) beacon.style.background = '#10B981';
        if(text) text.innerHTML = `${d.printer_name || 'Printer'} - Ready`;
      } else {
        if(beacon) beacon.style.background = '#EF4444';
        if(text) text.innerHTML = `${d.printer_name || 'Printer'} - ${d.reason || 'OFFLINE'}`;
      }
    } catch(e){}
  }
  fetchHardware();
  setInterval(fetchHardware, 5000);
"""

code = code.replace('// Global Error Boundary to prevent any crashes', fetch_js)

# 3. Enhance executing panel if it's not already enhanced
if 'anim-stage-1' not in code:
    new_exec_panel = """
    <section class="keypad-panel" id="executing-panel" style="display:none; flex-direction:column; align-items:center; justify-content:center; text-align:center; height:100%; min-height:400px; padding:2rem;">
      <div id="anim-stage-1" style="display:none; animation: fadeIn 0.5s;">
        <h2 style="font-size:36px; font-weight:800; color:white; margin-bottom:12px;">Welcome <span id="exec-name-1" style="color:#60A5FA;"></span>!</h2>
        <p style="color:var(--text-muted); font-size:20px;">Your <span id="exec-pages-1" style="color:white;font-weight:bold;"></span> pages print is ready.</p>
      </div>
      
      <div id="anim-stage-2" style="display:none; animation: fadeIn 0.5s; width:100%;">
        <h2 style="font-size:24px; font-weight:700; color:white; margin-bottom:16px;">Previewing Document</h2>
        <div style="background:white; border-radius:12px; padding:8px; display:inline-block; max-height:280px; overflow:hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.5);">
            <img id="exec-preview-img" src="" style="max-height:260px; object-fit:contain;" />
        </div>
      </div>
      
      <div id="anim-stage-3" style="display:none; animation: fadeIn 0.5s;">
        <svg style="width:72px;height:72px;color:#10B981;margin:0 auto 24px auto; animation: pulse 2s infinite;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path></svg>
        <h2 style="font-size:32px; font-weight:800; color:white; margin-bottom:12px;">Printing Document</h2>
        <p style="color:var(--text-muted); font-size:18px;">For <span id="exec-name-3" style="color:#10B981;font-weight:700;"></span></p>
      </div>
    </section>
"""
    code = re.sub(r'<section class="keypad-panel" id="executing-panel".*?</section>', new_exec_panel, code, flags=re.DOTALL)

# 4. Cinematic animation state machine logic if not already present
if 'activeAnimJobId' not in code:
    anim_js = """
  let activeAnimJobId = null;
  let animTimer1 = null;
  let animTimer2 = null;

  async function pollCurrentJob() {
    try {
      const res = await fetch('/api/kiosk/current-job');
      const job = await res.json();
      
      const idle = document.getElementById('idle-panel');
      const exec = document.getElementById('executing-panel');
      
      if (job && (job.status === 'SPOOLING' || job.status === 'PRINTING' || job.status === 'PAID')) {
        
        // If this is a new job we haven't animated yet
        if (activeAnimJobId !== job.job_id) {
          activeAnimJobId = job.job_id;
          
          idle.style.display = 'none';
          exec.style.display = 'flex';
          
          const s1 = document.getElementById('anim-stage-1');
          const s2 = document.getElementById('anim-stage-2');
          const s3 = document.getElementById('anim-stage-3');
          
          if(s1) s1.style.display = 'block';
          if(s2) s2.style.display = 'none';
          if(s3) s3.style.display = 'none';
          
          if(document.getElementById('exec-name-1')) document.getElementById('exec-name-1').innerText = job.user_name || 'Student';
          if(document.getElementById('exec-name-3')) document.getElementById('exec-name-3').innerText = job.user_name || 'Student';
          
          const pages = job.pages_selected || job.source_page_count || 1;
          const total = (job.copies > 1) ? (pages * job.copies) : pages;
          if (document.getElementById('exec-pages-1')) document.getElementById('exec-pages-1').innerText = total;

          if(document.getElementById('exec-preview-img')) document.getElementById('exec-preview-img').src = '/api/preview/' + job.job_id + '?page=1';
          
          // Clear any old timers
          clearTimeout(animTimer1);
          clearTimeout(animTimer2);
          
          // Transition to Preview after 3s
          animTimer1 = setTimeout(() => {
            if(s1) s1.style.display = 'none';
            if(s2) s2.style.display = 'block';
            
            // Transition to Printing after another 3s
            animTimer2 = setTimeout(() => {
               if(s2) s2.style.display = 'none';
               if(s3) s3.style.display = 'block';
            }, 3000);
            
          }, 3000);
        }
      } else {
        // Reset when queue clears
        activeAnimJobId = null;
        clearTimeout(animTimer1);
        clearTimeout(animTimer2);
        
        idle.style.display = 'flex';
        exec.style.display = 'none';
      }
    } catch(e) {}
  }
"""
    code = re.sub(r'async function pollCurrentJob\(\) \{.*?\n  \}', anim_js, code, flags=re.DOTALL)

with open('kiosk.html', 'w', encoding='utf-8') as f:
    f.write(code)

print("Kiosk completely fixed")
