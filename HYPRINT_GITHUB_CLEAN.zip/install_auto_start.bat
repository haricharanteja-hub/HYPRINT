@echo off
echo ==================================================
echo HYPRINT KIOSK AUTO-START INSTALLER
echo ==================================================
echo.
echo Installing invisible startup script to Windows Startup folder...
set "startup_folder=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"

echo Set oWS = WScript.CreateObject("WScript.Shell") > CreateShortcut.vbs
echo sLinkFile = "%startup_folder%\StartHyprintKiosk.lnk" >> CreateShortcut.vbs
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> CreateShortcut.vbs
echo oLink.TargetPath = "%~dp0start_hyprint_backend.vbs" >> CreateShortcut.vbs
echo oLink.WorkingDirectory = "%~dp0" >> CreateShortcut.vbs
echo oLink.Save >> CreateShortcut.vbs

cscript //nologo CreateShortcut.vbs
del CreateShortcut.vbs

echo.
echo SUCCESS! The Kiosk Backend will now start automatically whenever Windows boots.
echo Press any key to exit...
pause >nul
