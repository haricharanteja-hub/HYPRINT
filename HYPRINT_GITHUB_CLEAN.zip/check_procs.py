import psutil

print("=== RUNNING HP / PRINT RELATED PROCESSES ===")
found = 0
for p in psutil.process_iter(['pid', 'name', 'exe']):
    try:
        n = (p.info['name'] or "").lower()
        if any(k in n for k in ['hp', 'laser', 'print', 'spool', 'status', 'rundll', 'smart']):
            print(f"PID {p.info['pid']:6}: {p.info['name']} | exe={p.info['exe']}")
            found += 1
    except Exception:
        pass
print(f"Total found: {found}")
