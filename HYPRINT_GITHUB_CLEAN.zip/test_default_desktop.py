import win32service, win32gui, win32con, win32process, psutil

hdesk = win32service.OpenDesktop('default', 0, True, win32con.GENERIC_ALL)
hwnds = hdesk.EnumDesktopWindows()
print(f"Total HWNDs on default desktop: {len(hwnds)}")

count = 0
for h in hwnds:
    if win32gui.IsWindowVisible(h):
        t = win32gui.GetWindowText(h)
        if t:
            tid, pid = win32process.GetWindowThreadProcessId(h)
            pname = "unknown"
            try:
                pname = psutil.Process(pid).name()
            except Exception:
                pass
            print(f"  [{pname:20}] PID={pid:6} HWND={int(h):8} | '{t}'")
            count += 1
print(f"Total visible titled windows on default desktop: {count}")
