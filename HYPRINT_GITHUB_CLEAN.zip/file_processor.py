"""
file_processor.py — Robust document normalization, multi-file merging, page slicing,
N-up imposition and graph-paper generation for the HyPrint Kiosk.
Uses PyMuPDF (pymupdf) for ultra-fast, loss-less PDF manipulation.

SHEET GEOMETRY CONTRACT
=======================
Every physical sheet produced by build_print_bundle() is an exact ISO A4 page
(595.2756 x 841.8898 pt portrait, or 841.8898 x 595.2756 pt landscape). The
student-facing preview (public/index.html: sheetGeometry()) mirrors the
constants and the slot maths below one-for-one, so what is drawn on the phone
is what comes out of the printer.

`orientation` is the orientation of the DOCUMENT PAGES the student is printing
(exactly like the Orientation box of a Windows print dialog). The sheet itself
is chosen the way every print driver does it:

    nup  orientation=portrait            orientation=landscape
    ---  ---------------------------     ---------------------------
     1   portrait sheet, 1 slot          landscape sheet, 1 slot
     2   landscape sheet, 2 cols x 1     portrait sheet, 1 col x 2 rows
     4   portrait sheet, 2 x 2           landscape sheet, 2 x 2
     6   landscape sheet, 3 cols x 2     portrait sheet, 2 cols x 3 rows

Graph-paper sheets are always portrait A4 at 1:1 scale (never shrunk by N-up).
"""

import os
import shutil
import subprocess
from PIL import Image, ImageOps
import pymupdf

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ISO A4 in PostScript points (1 pt = 1/72 in, 1 mm = 72/25.4 pt).
MM = 72.0 / 25.4
A4_W = 210.0 * MM          # 595.2756 pt
A4_H = 297.0 * MM          # 841.8898 pt
NUP_MARGIN = 5.0 * MM      # outer margin on N-up sheets (inside the P1108's ~4 mm unprintable border)
NUP_GUTTER = 3.0 * MM      # gap between N-up slots

VALID_NUP = (1, 2, 4, 6)


class PageRangeError(ValueError):
    """Raised when a custom page range cannot be honoured exactly."""


def parse_page_range(spec: str | None, page_count: int) -> list[int]:
    """
    Parse range strings like '1-3', '1, 3, 5-7' into a sorted, unique list of 1-based page numbers.
    If spec is None, empty, or 'all', returns all pages: [1, 2, ..., page_count].

    STRICT: anything that cannot be honoured exactly (malformed token, half-typed
    range such as '5-', page 0, or a page beyond page_count) raises PageRangeError.
    It never silently falls back to "all pages" — that used to charge students
    for the whole document when they asked for a few pages.
    """
    if page_count < 1:
        return []
    if not spec or not spec.strip() or spec.strip().lower() == "all":
        return list(range(1, page_count + 1))

    pages: set[int] = set()
    for raw in spec.split(","):
        chunk = raw.strip()
        if not chunk:
            continue
        if "-" in chunk:
            parts = [p.strip() for p in chunk.split("-")]
            if len(parts) != 2 or not parts[0].isdigit() or not parts[1].isdigit():
                raise PageRangeError(f"'{chunk}' is not a valid range.")
            start, end = int(parts[0]), int(parts[1])
            if start > end:
                start, end = end, start
        elif chunk.isdigit():
            start = end = int(chunk)
        else:
            raise PageRangeError(f"'{chunk}' is not a valid page number.")

        if start < 1 or end > page_count:
            article = "an" if str(page_count).startswith("8") or page_count in (11, 18) else "a"
            raise PageRangeError(f"Invalid range for {article} {page_count}-page document.")
        pages.update(range(start, end + 1))

    if not pages:
        raise PageRangeError("No pages selected.")
    return sorted(pages)


def _find_soffice() -> str:
    candidate = shutil.which("soffice") or shutil.which("soffice.exe")
    if candidate:
        return candidate
    common_paths = [
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
    ]
    for p in common_paths:
        if os.path.exists(p):
            return p
    return "soffice"


IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".tif", ".tiff")
OFFICE_EXTS = (".doc", ".docx", ".txt", ".rtf", ".odt", ".pptx", ".ppt", ".xlsx", ".xls")
SUPPORTED_EXTS = (".pdf",) + IMAGE_EXTS + OFFICE_EXTS


def normalize_to_a4_pdf(input_filepath: str, output_pdf_path: str = None) -> str:
    """
    Normalizes any supported file format (.pdf, images, .docx, .doc, .pptx, .xlsx, .txt ...)
    to a PDF. Page geometry is normalized to A4 later, in build_print_bundle().
    """
    if not output_pdf_path:
        output_pdf_path = os.path.splitext(input_filepath)[0] + "_norm.pdf"

    lower_name = input_filepath.lower()

    if lower_name.endswith(".pdf"):
        try:
            doc = pymupdf.open(input_filepath)
        except Exception as e:
            raise ValueError(f"PDF is damaged or not a real PDF ({e}).")
        try:
            if doc.needs_pass and not doc.authenticate(""):
                raise ValueError("PDF is password protected. Please remove the password before printing.")
            if len(doc) == 0:
                raise ValueError("PDF has no pages.")
            if doc.is_encrypted or doc.needs_pass:
                # Owner-password-only PDF: save a decrypted copy so later merges/slices work.
                doc.save(output_pdf_path, encryption=pymupdf.PDF_ENCRYPT_NONE, garbage=1)
                return output_pdf_path
        finally:
            doc.close()
        if os.path.abspath(input_filepath) != os.path.abspath(output_pdf_path):
            shutil.copyfile(input_filepath, output_pdf_path)
        return output_pdf_path

    # Image conversion -> proportional fit onto A4 (portrait, or landscape for wide images)
    if lower_name.endswith(IMAGE_EXTS):
        try:
            with Image.open(input_filepath) as im:
                im.seek(0)  # first frame of GIF/TIFF
                im = ImageOps.exif_transpose(im)
                if im.mode != "RGB":
                    if im.mode in ("RGBA", "LA", "P"):
                        rgba = im.convert("RGBA")
                        flat = Image.new("RGB", rgba.size, (255, 255, 255))
                        flat.paste(rgba, mask=rgba.split()[-1])
                        im = flat
                    else:
                        im = im.convert("RGB")

                # A4 at 300 DPI is 2480 x 3508 pixels
                a4_w, a4_h = 2480, 3508
                is_landscape = im.width > im.height
                canvas_w, canvas_h = (a4_h, a4_w) if is_landscape else (a4_w, a4_h)

                canvas = Image.new("RGB", (canvas_w, canvas_h), (255, 255, 255))
                # 94% fit leaves a clean printable margin
                max_w = int(canvas_w * 0.94)
                max_h = int(canvas_h * 0.94)
                scale = min(max_w / im.width, max_h / im.height)
                new_w = max(1, int(im.width * scale))
                new_h = max(1, int(im.height * scale))

                resized = im.resize((new_w, new_h), Image.Resampling.LANCZOS)
                canvas.paste(resized, ((canvas_w - new_w) // 2, (canvas_h - new_h) // 2))
                canvas.save(output_pdf_path, "PDF", resolution=300.0)
            return output_pdf_path
        except Exception as e:
            raise ValueError(f"Image conversion to A4 failed: {e}")

    # Documents -> convert via LibreOffice headless
    if lower_name.endswith(OFFICE_EXTS):
        try:
            outdir = os.path.dirname(os.path.abspath(output_pdf_path))
            soffice_cmd = _find_soffice()
            subprocess.run([soffice_cmd, "--headless", "--convert-to", "pdf", input_filepath, "--outdir", outdir],
                           timeout=60, check=True, capture_output=True)
            base_name = os.path.splitext(os.path.basename(input_filepath))[0]
            lo_out = os.path.join(outdir, base_name + ".pdf")
            if os.path.exists(lo_out):
                if os.path.abspath(lo_out) != os.path.abspath(output_pdf_path):
                    shutil.move(lo_out, output_pdf_path)
                return output_pdf_path
            raise ValueError("Converted document PDF not produced.")
        except subprocess.TimeoutExpired:
            raise ValueError("Document conversion timed out. Please export it as PDF and upload again.")
        except Exception as e:
            raise ValueError(f"Document conversion failed: {e}")

    raise ValueError(f"Unsupported file format: {os.path.basename(input_filepath)}")


def merge_pdfs(pdf_paths: list[str], output_path: str) -> tuple[int, str]:
    """
    Merges multiple PDF files in order into output_path using PyMuPDF.
    Returns (total_pages, output_path).
    """
    master_doc = pymupdf.open()
    abs_output = os.path.abspath(output_path)
    for p in pdf_paths:
        if os.path.exists(p) and os.path.abspath(p) != abs_output:
            try:
                with pymupdf.open(p) as sub_doc:
                    master_doc.insert_pdf(sub_doc)
            except Exception as e:
                print(f"[file_processor] Warning merging {p}: {e}")

    total_pages = len(master_doc)
    tmp_out = output_path + ".merge.tmp"
    try:
        master_doc.save(tmp_out, garbage=1)
    finally:
        master_doc.close()

    if os.path.exists(tmp_out):
        os.replace(tmp_out, output_path)

    return total_pages, output_path


def slice_pdf_pages(src_path: str, dest_path: str, selected_pages: list[int]) -> tuple[int, str]:
    """
    Extracts only the 1-based page numbers in `selected_pages` from src_path
    and saves them to dest_path using PyMuPDF.
    Returns (sliced_pages_count, dest_path).
    """
    doc = pymupdf.open(src_path)
    total_in_src = len(doc)

    zero_based = [p - 1 for p in selected_pages if 1 <= p <= total_in_src]
    if not zero_based or len(zero_based) != len(selected_pages):
        doc.close()
        raise PageRangeError(f"Selected pages do not exist in this {total_in_src}-page document.")

    doc.select(zero_based)
    tmp_dest = dest_path + ".slice.tmp"
    try:
        doc.save(tmp_dest, garbage=1)
        count = len(doc)
    finally:
        doc.close()

    if os.path.exists(tmp_dest):
        os.replace(tmp_dest, dest_path)

    return count, dest_path


def inspect_pdf_page_count(filepath: str) -> int:
    """
    Ultra-fast (<15ms) page count inspection using PyMuPDF.
    """
    if not os.path.exists(filepath):
        return 0
    try:
        with pymupdf.open(filepath) as doc:
            return len(doc)
    except Exception:
        return 0


def count_landscape_pages(filepath: str) -> int:
    """Number of pages that are wider than tall (as displayed, i.e. after /Rotate)."""
    if not filepath or not os.path.exists(filepath):
        return 0
    try:
        with pymupdf.open(filepath) as doc:
            return sum(1 for page in doc if page.rect.width > page.rect.height)
    except Exception:
        return 0


def sheet_is_landscape(nup: int, orientation: str = "portrait") -> bool:
    """Physical sheet orientation for a given N-up + document orientation (see module docstring)."""
    doc_landscape = (orientation or "portrait").lower() == "landscape"
    if nup in (2, 6):
        return not doc_landscape
    return doc_landscape


def sheet_geometry(nup: int, orientation: str = "portrait") -> tuple[float, float, list]:
    """
    Returns (sheet_width_pt, sheet_height_pt, [slot Rects in reading order]).
    Mirrored exactly by sheetGeometry() in public/index.html.
    """
    nup = nup if nup in VALID_NUP else 1
    landscape = sheet_is_landscape(nup, orientation)
    w, h = (A4_H, A4_W) if landscape else (A4_W, A4_H)

    if nup == 1:
        return w, h, [pymupdf.Rect(0, 0, w, h)]

    if nup == 2:
        cols, rows = (2, 1) if landscape else (1, 2)
    elif nup == 4:
        cols, rows = 2, 2
    else:  # 6
        cols, rows = (3, 2) if landscape else (2, 3)

    cell_w = (w - 2 * NUP_MARGIN - (cols - 1) * NUP_GUTTER) / cols
    cell_h = (h - 2 * NUP_MARGIN - (rows - 1) * NUP_GUTTER) / rows
    slots = []
    for r in range(rows):
        for c in range(cols):
            x0 = NUP_MARGIN + c * (cell_w + NUP_GUTTER)
            y0 = NUP_MARGIN + r * (cell_h + NUP_GUTTER)
            slots.append(pymupdf.Rect(x0, y0, x0 + cell_w, y0 + cell_h))
    return w, h, slots


def _impose_into(dest: "pymupdf.Document", src: "pymupdf.Document", page_indices: list[int],
                 nup: int, orientation: str) -> int:
    """Lays out src pages (0-based indices) onto A4 sheets appended to dest. Returns sheets added."""
    w, h, slots = sheet_geometry(nup, orientation)
    per_sheet = len(slots)
    added = 0
    for i in range(0, len(page_indices), per_sheet):
        sheet = dest.new_page(width=w, height=h)
        for slot_idx, pno in enumerate(page_indices[i:i + per_sheet]):
            # keep_proportion=True scales the page to fit and centres it in the slot.
            sheet.show_pdf_page(slots[slot_idx], src, pno, keep_proportion=True)
        added += 1
    return added


def impose_nup_pdf(pdf_path: str, nup: int = 1, orientation: str = "portrait") -> tuple[int, str]:
    """
    Imposes document pages onto physical A4 sheets according to nup (1, 2, 4, 6) and orientation
    (see the geometry table in the module docstring).
    Overwrites pdf_path with the newly laid-out PDF and returns (new_sheet_count, pdf_path).
    """
    nup = nup if nup in VALID_NUP else 1
    with pymupdf.open(pdf_path) as src:
        dest = pymupdf.open()
        try:
            _impose_into(dest, src, list(range(len(src))), nup, orientation)
            tmp_dest = pdf_path + ".nup.tmp"
            dest.save(tmp_dest, garbage=1)
            count = len(dest)
        finally:
            dest.close()
    os.replace(tmp_dest, pdf_path)
    return count, pdf_path


def _graph_template_candidates(template_path: str | None) -> list[str]:
    cands = []
    if template_path:
        cands.append(template_path if os.path.isabs(template_path) else os.path.join(BASE_DIR, template_path))
    cands += [
        os.path.join(BASE_DIR, "graph_paper.pdf"),
        os.path.join(BASE_DIR, "static", "graph_paper.pdf"),
        os.path.join(BASE_DIR, "public", "graph_paper.pdf"),
    ]
    return cands


def ensure_graph_paper_template(template_path: str = "graph_paper.pdf") -> str:
    """
    Locates or procedurally synthesizes an exact ISO A4 (595.28 x 841.89 pt) 2mm-grid vector graph paper PDF.
    The generated grid is 190 x 270 mm (95 x 135 cells of 2 mm, every 5th line a bold 10 mm line),
    centred on the sheet so all four borders are bold lines.
    """
    for p in _graph_template_candidates(template_path):
        if os.path.exists(p) and os.path.getsize(p) > 0:
            return p

    out_file = _graph_template_candidates(template_path)[0]
    doc = pymupdf.open()
    page = doc.new_page(width=A4_W, height=A4_H)

    step = 2.0 * MM
    cols, rows = 95, 135                      # 190 mm x 270 mm
    x0 = (A4_W - cols * step) / 2.0           # 10 mm
    y0 = (A4_H - rows * step) / 2.0           # 13.5 mm
    x1, y1 = x0 + cols * step, y0 + rows * step

    minor_color = (0.78, 0.88, 0.95)  # light blueprint cyan
    major_color = (0.45, 0.65, 0.85)  # crisp 10 mm line

    # Minor lines first so major lines are drawn on top.
    for major_pass in (False, True):
        for i in range(cols + 1):
            if (i % 5 == 0) != major_pass:
                continue
            x = x0 + i * step
            page.draw_line(pymupdf.Point(x, y0), pymupdf.Point(x, y1),
                           color=major_color if major_pass else minor_color,
                           width=0.7 if major_pass else 0.35)
        for j in range(rows + 1):
            if (j % 5 == 0) != major_pass:
                continue
            y = y0 + j * step
            page.draw_line(pymupdf.Point(x0, y), pymupdf.Point(x1, y),
                           color=major_color if major_pass else minor_color,
                           width=0.7 if major_pass else 0.35)

    tmp = out_file + ".tmp"
    doc.save(tmp)
    doc.close()
    os.replace(tmp, out_file)
    return out_file


def build_print_bundle(
    doc_src_path: str | None,
    dest_path: str,
    selected_pages: list[int] | None = None,
    nup: int = 1,
    orientation: str = "portrait",
    graph_sheets: int = 0
) -> tuple[int, int, str]:
    """
    Creates the final unified print PDF (one copy):
    1. Slices the selected document pages and imposes them onto exact A4 sheets (also for 1-up,
       which normalizes Letter/odd-sized pages to A4 in the requested orientation).
    2. STRICT GRAPH ISOLATION: appends 1:1 scale portrait A4 2mm-grid sheets after the document sheets.
    Returns: (doc_sheets, total_physical_sheets, dest_path).
    """
    nup = nup if nup in VALID_NUP else 1
    dest_doc = pymupdf.open()
    doc_sheets = 0
    graph_count = max(0, int(graph_sheets or 0))

    try:
        if doc_src_path and os.path.exists(doc_src_path):
            with pymupdf.open(doc_src_path) as src_doc:
                total_in_src = len(src_doc)
                if selected_pages:
                    bad = [p for p in selected_pages if not 1 <= p <= total_in_src]
                    if bad:
                        raise PageRangeError(f"Page {bad[0]} does not exist in this {total_in_src}-page document.")
                    indices = [p - 1 for p in selected_pages]
                else:
                    indices = list(range(total_in_src))
                doc_sheets = _impose_into(dest_doc, src_doc, indices, nup, orientation)

        if graph_count > 0:
            graph_template = ensure_graph_paper_template()
            with pymupdf.open(graph_template) as g_doc:
                for _ in range(graph_count):
                    dest_doc.insert_pdf(g_doc, from_page=0, to_page=0)

        if len(dest_doc) == 0:
            raise ValueError("Nothing to print: no document pages and no graph sheets.")

        total_physical_sheets = len(dest_doc)
        tmp_out = dest_path + ".bundle.tmp"
        dest_doc.save(tmp_out, garbage=1, deflate=True)
    finally:
        dest_doc.close()

    os.replace(tmp_out, dest_path)
    return doc_sheets, total_physical_sheets, dest_path


def render_sheet_preview(pdf_path: str, sheet_index: int, output_img_path: str, dpi: int = 130,
                         gray: bool = False, jpg_quality: int = 82) -> str:
    """
    On-demand lazy preview rendering for a specific physical sheet index (1-based).
    Caches output to output_img_path (written atomically so parallel requests never see half a PNG).
    """
    if os.path.exists(output_img_path) and os.path.getsize(output_img_path) > 0:
        return output_img_path

    os.makedirs(os.path.dirname(os.path.abspath(output_img_path)), exist_ok=True)
    with pymupdf.open(pdf_path) as doc:
        total_sheets = len(doc)
        page_idx = max(0, min(sheet_index - 1, total_sheets - 1))
        # gray=True matches the monochrome laser output and makes the image much smaller
        pix = doc[page_idx].get_pixmap(dpi=dpi, colorspace=pymupdf.csGRAY if gray else pymupdf.csRGB)
        ext = os.path.splitext(output_img_path)[1].lower() or ".png"
        tmp = f"{output_img_path}.{os.getpid()}.{id(pix)}.tmp{ext}"
        if ext in (".jpg", ".jpeg"):
            pix.save(tmp, jpg_quality=jpg_quality)
        else:
            pix.save(tmp)
    os.replace(tmp, output_img_path)
    return output_img_path
