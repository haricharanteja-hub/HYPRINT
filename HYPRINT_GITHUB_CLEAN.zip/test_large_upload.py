import urllib.request
import time
import os
import pymupdf

# Create a 20-page 3MB PDF
doc = pymupdf.open()
for i in range(20):
    page = doc.new_page(width=595, height=842)
    page.insert_text((50, 100), f"Test Document Page {i+1} of 20 with content text", fontsize=24)
    # Add some dummy graphics/rectangles to increase size
    for j in range(20):
        page.draw_rect(pymupdf.Rect(50, 150 + j * 20, 500, 160 + j * 20), color=(0.2, 0.4, 0.8), fill=(0.9, 0.95, 1.0))
dummy_pdf = "test_large_probe.pdf"
doc.save(dummy_pdf)
doc.close()

file_size_mb = os.path.getsize(dummy_pdf) / (1024 * 1024)
print(f"Generated test file: {dummy_pdf} ({file_size_mb:.2f} MB, 20 pages)")

boundary = "----WebKitBoundaryProbe999"
part1 = (
    f"--{boundary}\r\n"
    f'Content-Disposition: form-data; name="files"; filename="test_large_probe.pdf"\r\n'
    f"Content-Type: application/pdf\r\n\r\n"
).encode()
with open(dummy_pdf, "rb") as f:
    pdf_bytes = f.read()
part2 = f"\r\n--{boundary}--\r\n".encode()
body = part1 + pdf_bytes + part2

print("Testing large upload through Cloudflare tunnel...")
t0 = time.time()
req_cf = urllib.request.Request(
    "https://educated-school-spiritual-fall.trycloudflare.com/api/upload",
    data=body,
    headers={"Content-Type": f"multipart/form-data; boundary={boundary}"}
)
try:
    resp_cf = urllib.request.urlopen(req_cf, timeout=30)
    res_str = resp_cf.read().decode()
    print("Tunnel OK in", round(time.time() - t0, 2), "s:")
    print(res_str[:200])
except Exception as e:
    print("Tunnel FAIL:", e)

if os.path.exists(dummy_pdf):
    os.remove(dummy_pdf)
