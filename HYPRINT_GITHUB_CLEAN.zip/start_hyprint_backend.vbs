Set WshShell = CreateObject("WScript.Shell")
strPath = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
WshShell.CurrentDirectory = strPath
' Run auto_tunnel silently (0 means hidden window, False means do not wait)
WshShell.Run """" & strPath & "\.venv\Scripts\python.exe"" """ & strPath & "\auto_tunnel.py""", 0, False

