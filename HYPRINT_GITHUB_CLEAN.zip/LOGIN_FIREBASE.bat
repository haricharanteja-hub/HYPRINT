@echo off
title Firebase Login
cd /d "C:\Users\Student\.gemini\antigravity-ide\scratch\HYPRINT"

echo ===================================================
echo           FIREBASE GOOGLE ACCOUNT LOGIN
echo ===================================================
echo.
echo Opening Google login in your browser...
echo Please click your Google account and click ALLOW.
echo.
npx -y firebase-tools login
echo.
echo ===================================================
echo If it says "Success! Logged in", you can close this!
echo ===================================================
pause
