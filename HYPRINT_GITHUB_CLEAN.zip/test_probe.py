import urllib.request
import time
import os

dummy_pdf = "test_upload_probe.pdf"
with open(dummy_pdf, "wb") as f:
    f.write(b"%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Count 1/Kids[3 0 R]>>endobj\n3 0 obj<</Type/Page/MediaBox[0 0 612 792]/Parent 2 0 R>>endobj\nxref\n0 4\n0000000000 65535 f\n0000000009 00000 n\n0000000052 00000 n\n0000000097 00000 n\ntrailer<</Size 4/Root 1 0 R>>\nstartxref\n178\n%%EOF\n")

boundary = "----WebKitBoundary123"
part1 = (
    f"--{boundary}\r\n"
    f'Content-Disposition: form-data; name="files"; filename="test_probe.pdf"\r\n'
    f"Content-Type: application/pdf\r\n\r\n"
).encode()
with open(dummy_pdf, "rb") as f:
    pdf_bytes = f.read()
part2 = f"\r\n--{boundary}--\r\n".encode()
body = part1 + pdf_bytes + part2

# 1. Local
print("Direct local upload...")
t0 = time.time()
req = urllib.request.Request(
    "http://127.0.0.1:8000/api/upload",
    data=body,
    headers={"Content-Type": f"multipart/form-data; boundary={boundary}"}
)
try:
    resp = urllib.request.urlopen(req, timeout=10)
    print("Local OK in", round(time.time() - t0, 2), "s:", resp.read().decode()[:150])
except Exception as e:
    print("Local FAIL:", e)

# 2. Cloudflare tunnel
print("Cloudflare tunnel upload...")
t0 = time.time()
req_cf = urllib.request.Request(
    "https://educated-school-spiritual-fall.trycloudflare.com/api/upload",
    data=body,
    headers={"Content-Type": f"multipart/form-data; boundary={boundary}"}
)
try:
    resp_cf = urllib.request.urlopen(req_cf, timeout=15)
    print("Tunnel OK in", round(time.time() - t0, 2), "s:", resp_cf.read().decode()[:150])
except Exception as e:
    print("Tunnel FAIL:", e)

if os.path.exists(dummy_pdf):
    os.remove(dummy_pdf)
