# HYPRINT — engine & logic overhaul

The UI looks exactly as before: no CSS, colours, fonts, cards or layout changed, and every element ID/class is kept.
The only markup changes are:
- the "Add More Files" drawer now accepts the same file types as the main upload,
- a small red inline span shows the invalid-page-range warning,
- the drawer's hint text names the supported formats.

Files changed: `main.py`, `file_processor.py`, `cups_manager.py`, `config.py`, `database.py`, `requirements.txt`,
`public/index.html` and `public/kiosk.html`. The `public/` pages are copied byte-for-byte into `static/` and the repository root.

## Root causes behind the symptoms students saw
| Symptom | Real cause | Fix |
|---|---|---|
| Price stuck at ₹0, preview not updating after changing options | `recalc()` threw `ReferenceError: isCustomRange is not defined` on every document, so it aborted before updating the price. It also aborted every caller (`setNup`, `setPageSel`, the post-upload render). | Rewrote `recalc()` (one formula, shared with the server). |
| Phone stuck on "Printing…" after paying | (1) `verify-and-print` printed **inside** the HTTP request, which ran past the Cloudflare tunnel's 100 s limit. (2) The phone's status poller referenced an undefined `data`, so every poll crashed silently. | Verification now answers in ~10 ms and printing runs in a background queue. The phone tracks progress over WebSocket plus a working poller. |
| "Upload issue" although the file reached the server | Tunnel 502/524 errors and dropped connections were reported as failures. The automatic retry then re-uploaded and **merged the file twice**. | The phone proposes the job id and tags each batch with an `upload_id`. On an ambiguous failure it asks `GET /api/upload/status/{job}` whether the batch landed. A retried batch is never merged twice, and a per-job lock serialises edits. |
| Whole page dead on some campus Wi-Fi | `pdfjsLib.GlobalWorkerOptions` ran unguarded. If the pdf.js CDN was blocked, the entire script died. | Guarded. |

## Preview / orientation engine (Category 1)
- `file_processor.sheet_geometry()` is the single geometry contract, mirrored one-for-one by `sheetGeometry()` in `index.html`. Sheets are exact ISO A4: 595.2756 × 841.8898 pt, or the reverse for landscape. Margins are 5 mm and gutters 3 mm.
- Orientation works like a real print-driver orientation box:

  | Pages per sheet | Portrait document | Landscape document |
  |---|---|---|
  | 1 | portrait sheet | landscape sheet |
  | 2 | landscape sheet, 2×1 | portrait sheet, 1×2 |
  | 4 | portrait sheet, 2×2 | landscape sheet, 2×2 |
  | 6 | landscape sheet, 3×2 | portrait sheet, 2×3 |

- `impose_nup_pdf()` now really uses `orientation`. 1-up pages are also normalised onto exact A4 (Letter and odd page sizes included).
- `/api/preview` accepts `orientation`. Its cache key is a hash of the source file plus nup, orientation, range and graph count, so changing the page range can no longer show a stale image. Parallel thumbnail requests share a single bundle build behind a lock.
- Thumbnails are exactly 1:√2 (120 × 169.71 px or 170 × 120.21 px) and use `object-fit: contain`. A guard re-fits the card to the PNG's real aspect ratio. The fullscreen view shows server-rendered sheets at their natural aspect, with no padded container and no CSS rotation.
- 6-on-1 is now a landscape card. 4-on-1 landscape works.
- On upload, slides and wide photos switch the orientation to landscape automatically, unless the student has already chosen an orientation.

## Page range (Category 2)
- The parsers in `index.html` and `file_processor.py` are strict and identical. `5-` (half-typed) and `15-20` on an 8-page document are errors. They never fall back to "all pages".
- When the range is invalid:
  - an inline warning shows: `⚠️ Invalid range for an 8-page document`
  - the price shows `₹—`
  - the Pay button reads "Fix Page Range" and is disabled
  - the server also returns 400 for it at checkout
- The preview refreshes only after typing pauses, and only for a valid range.

## HP LaserJet P1108 (Category 3)
- The printer is simplex only, so every path bills ₹2.00 per physical sheet. The old ₹3 duplex rate in `submit_job` is gone, and `/api/locations` now reports `duplex: false`.
- The 2-sided button stays locked with its existing "Simplex Laser" badge.
- SumatraPDF is found next to `cups_manager.py` instead of relative to the current working directory.
- The engine is no longer forced into landscape. Each bundle page already carries its orientation, so mixed bundles (for example landscape 2-up sheets followed by portrait graph paper) print correctly.
- The watchdog judges success by **our** spooler job only, not by unrelated queue entries. Its timeouts are realistic for a host-based 18 ppm printer.
- Jobs print one at a time through a printer lock.
- Linux/CUPS printing is real. Previously it returned "success" without printing anything.

## Graph paper (Category 4)
- Graph paper is now a sheet count, not an uploaded file. The sheets are 1:1 portrait A4 with a 2 mm grid, appended after the document sheets and never shrunk by N-up.
- It works with or without a document; graph-paper-only checkout is supported.
- It appears as a cart chip ("📐 Graph Paper — N sheets ✕"). Preview cards are labelled `Sheet N: Graph Paper 📐`.
- Removing graph paper invalidates the cached preview images.
- The old filename heuristic is removed. It treated any file whose name contained "graph", such as `graph_theory_notes.pdf`, as graph paper.
- The template grid is generated with integer maths (190 × 270 mm, bold line every 10 mm) and saved next to the code, not in the current working directory.

## Cart & uploads (Category 5)
- Removing the last item resets everything: page count, dropzone, banner and job.
- A failed removal no longer splices the cart locally, which used to desynchronise the file indexes from the server.
- Both file inputs accept the same types: PDF, Word, PowerPoint, Excel, TXT/RTF/ODT, and images (JPG, PNG, WebP, BMP, GIF, TIFF).
- Files without an extension (some Android camera uploads) are recognised by their MIME type.
- In a multi-file batch, one bad file is skipped with a warning; the rest still upload.
- Encrypted-but-openable PDFs are decrypted. Corrupt PDFs give a clear error.
- File names are HTML-escaped in the cart.

## Security & privacy (Category 6)
- **Admin:** a genuinely local request on the kiosk PC is always allowed. Anything arriving through the tunnel needs `KIOSK_ADMIN_TOKEN`; with no token set, remote admin is impossible.
- **`/api/release`:** removed (returns 410). It printed any job for free given its PIN or job id.
- **Payment verification:**
  - checks that the paid `razorpay_order_id` is this job's current order;
  - prints only the spec frozen when the order was created;
  - ignores client-sent copies or pages at verify time (previously: pay ₹2, then send `copies: 99`).
  - A payment for a stale order is refunded in full automatically.
- **Order edits:** editing a job after an order was created invalidates that unpaid order.
- **`report-print-failure`** (self-service refund) is now staff-only.
- **`/api/kiosk/job/{id}/pdf`:** kiosk PC only.
- **Startup warning:** a loud warning is logged if Razorpay keys are missing, because the mock gateway accepts any signature.
- **File retention:**
  - every finished job (completed, refunded, failed or expired) has all its files destroyed 10 minutes after it ends, on Windows too (`KIOSK_FINISHED_FILE_TTL`);
  - unpaid jobs expire after 30 idle minutes (`KIOSK_ABANDONED_TTL`), including `ORDER_CREATED` jobs, which previously never expired;
  - orphan files and folders in `uploads/` are swept as well.

## Zero PIN (requirement 2)
No PIN is generated, stored, returned or displayed anywhere: `release_pin` is no longer in API responses. The flow is: upload → options → pay → it prints.

## Kiosk screen (Category 7)
- The execution preview is sheet 1 of the actual print bundle, with the same N-up, orientation, range and graph paper the student paid for.
- The sheet count no longer multiplies copies twice.

## Pricing (single source of truth)
```
doc_sheets      = ceil(selected_pages / pages_per_sheet)
sheets_per_copy = doc_sheets + graph_sheets
total_sheets    = sheets_per_copy × copies
price           = total_sheets × ₹2.00
```
- `main.py:compute_quote()` and `index.html:recalc()` implement this identically.
- The phone compares the server's order amount with what is on screen before opening Razorpay.
- Copies are clamped to `KIOSK_MAX_COPIES` (default now 99, matching the UI) instead of silently resetting to 1.

## Deploy
1. On the kiosk PC: `pip install -r requirements.txt`.
2. Run `python auto_tunnel.py`. It starts the backend, opens the tunnel, writes `api_config.json` and runs `firebase deploy --only hosting --project hyprint-64865`.
3. Set `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET` and (optionally) `KIOSK_ADMIN_TOKEN` in `.env`.

## Update: seamless printing for large jobs (fixes "2 pages, pause, 2 pages")
The HP LaserJet Pro P1108 is a host-based printer with roughly 2 pages of memory, so the PC must stream every page in real time. Three things starved that stream:
1. **SumatraPDF sent each page as a ~100 MB full-colour bitmap.** It is replaced by a new default engine (`KIOSK_PRINT_ENGINE=fast`) that sends 1-bit, 600 dpi, pre-dithered pages (~4 MB each), drawn 1:1 in device pixels. A background thread renders upcoming pages while the current one is sent: about 0.36 s per page against the printer's 3.3 s. SumatraPDF remains available via `KIOSK_PRINT_ENGINE=sumatra`.
2. **The hardware monitor queried the printer over USB and ran WMI and window scans every second**, and so did every phone's status and preflight request. Now, while a job prints, the monitor goes quiet: no USB status queries, no WMI, and window scans are throttled. API endpoints read the monitor's cached state instead of touching the printer.
3. **The stale-job purger could delete the live job**, because its "busy" check called a function that did not exist. `cups_manager.is_busy()` now exists, and purging is disabled while printing.

The watchdog now counts physical print time from the start of spooling and polls once per second, using local spooler reads only.

Phone previews are now grayscale JPEGs, matching the monochrome output:
- thumbnails are about 50 KB (were 100–140 KB);
- full-size previews are about 200–360 KB (were up to 2 MB).
