import asyncio
import io
import json
import time
import requests
import pymupdf

BASE_URL = "http://127.0.0.1:8000"

def test_overhaul_flow():
    print("==================================================")
    print("HYPRINT ENTERPRISE ARCHITECTURAL OVERHAUL VERIFICATION")
    print("==================================================")

    # 1. Hardware Status O(1) Check
    print("\n[1] Testing O(1) non-blocking hardware status...")
    t0 = time.time()
    res = requests.get(f"{BASE_URL}/api/status", timeout=5)
    t_hw = time.time() - t0
    assert res.status_code == 200, f"Hardware status failed: {res.text}"
    hw_data = res.json()
    print(f"  -> Hardware status response in {t_hw*1000:.1f}ms: status={hw_data.get('status')}, ready={hw_data.get('is_ready')}")
    assert t_hw < 0.2, f"Hardware check took too long: {t_hw}s"

    # 2. Fast Streaming Upload of 15-Page Document
    print("\n[2] Testing fast streaming upload of 15-page document...")
    # Generate 15-page synthetic PDF
    doc = pymupdf.open()
    for i in range(15):
        p = doc.new_page(width=595.28, height=841.89)
        p.insert_text((50, 100), f"HYPRINT TEST DOCUMENT - PAGE {i+1} of 15", fontsize=18)
        p.insert_text((50, 150), f"High-speed streaming ingestion verification content: {time.time()}", fontsize=12)
    pdf_bytes = doc.tobytes()
    doc.close()

    t_up0 = time.time()
    files = {"files": ("test_doc_15p.pdf", io.BytesIO(pdf_bytes), "application/pdf")}
    data = {
        "user_name": "Test Student",
        "user_phone": "9876543210",
        "kiosk_id": "0004",
        "copies": "1",
        "duplex": "false",
        "pages_per_sheet": "2"
    }
    up_res = requests.post(f"{BASE_URL}/api/upload", files=files, data=data, timeout=10)
    t_up = time.time() - t_up0
    assert up_res.status_code == 200, f"Upload failed: {up_res.text}"
    up_data = up_res.json()
    job_id = up_data.get("id") or up_data.get("job_id")
    print(f"  -> Uploaded 15 pages in {t_up:.2f}s: job_id={job_id}, source_pages={up_data.get('source_page_count')}")
    assert up_data.get("source_page_count") == 15, "Page count mismatch"

    # 3. WYSIWYG Imposition & Strict Graph Preview
    print("\n[3] Testing WYSIWYG 2-on-1 imposition preview with 2 Graph Paper sheets...")
    t_prev0 = time.time()
    # 15 pages in 2-on-1 = 8 sheets. + 2 graph sheets = 10 sheets total.
    # Sheet 1: 2-on-1 imposed document pages 1 & 2
    prev_res1 = requests.get(f"{BASE_URL}/api/preview/{job_id}/1?layout=2&graph_sheets=2", timeout=10)
    assert prev_res1.status_code == 200, f"Preview sheet 1 failed: {prev_res1.text}"
    assert prev_res1.headers.get("content-type") == "image/png"
    print(f"  -> Sheet 1 (2-on-1 Document) preview generated: {len(prev_res1.content)} bytes")

    # Sheet 9: 1st Graph Paper sheet (appended 1:1 scale)
    prev_res9 = requests.get(f"{BASE_URL}/api/preview/{job_id}/9?layout=2&graph_sheets=2", timeout=10)
    assert prev_res9.status_code == 200, f"Preview sheet 9 (Graph) failed: {prev_res9.text}"
    print(f"  -> Sheet 9 (1:1 Graph Paper) preview generated: {len(prev_res9.content)} bytes")

    # 4. Accurate Physical Billing with Document + Graph Paper
    print("\n[4] Testing server-side physical billing (8 doc sheets + 2 graph sheets = 10 sheets @ Rs.2)...")
    order_payload = {
        "job_id": job_id,
        "copies": 1,
        "pages_per_sheet": 2, # 15 pages / 2 = 8 doc sheets
        "graph_sheets": 2,    # + 2 graph sheets = 10 physical sheets
        "color_mode": "monochrome"
    }
    order_res = requests.post(f"{BASE_URL}/api/payment/create-order", json=order_payload, timeout=5)
    assert order_res.status_code == 200, f"Create order failed: {order_res.text}"
    order_data = order_res.json()
    print(f"  -> Order created: {order_data.get('order_id')}")
    print(f"  -> Sheets to print: {order_data.get('sheets_to_print')} (doc_sheets={order_data.get('doc_sheets')}, graph_sheets={order_data.get('graph_sheets')})")
    print(f"  -> Total amount: Rs.{order_data.get('amount_rupees')} ({order_data.get('amount_paise')} paise)")
    assert order_data.get("sheets_to_print") == 10, f"Expected 10 sheets, got {order_data.get('sheets_to_print')}"
    assert order_data.get("amount_rupees") == 20.0, f"Expected Rs.20.0, got {order_data.get('amount_rupees')}"

    # 5. Customer Dispute Fail-Safe Endpoint
    print("\n[5] Testing customer dispute fail-safe endpoint...")
    dispute_payload = {
        "job_id": job_id,
        "reason": "Test dispute validation"
    }
    # Should reject gracefully if not paid yet
    dispute_res = requests.post(f"{BASE_URL}/api/payment/report-print-failure", json=dispute_payload, timeout=5)
    print(f"  -> Dispute response for unpaid job: status={dispute_res.status_code}")
    assert dispute_res.status_code in (400, 200)

    print("\n==================================================")
    print("ALL ENTERPRISE OVERHAUL MODULES VERIFIED 100% OPERATIONAL!")
    print("==================================================")

if __name__ == "__main__":
    test_overhaul_flow()
