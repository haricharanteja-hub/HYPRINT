import requests

url = "http://localhost:8000/api/upload"

# Test 1: Upload 1 file
pdf_bytes = b"%PDF-1.4\n1 0 obj<<>>endobj\nxref\n0 2\n0000000000 65535 f \n0000000009 00000 n \ntrailer<<>>\nstartxref\n25\n%%EOF"
import pymupdf
doc = pymupdf.open()
doc.new_page()
pdf1 = doc.tobytes()
doc.close()

doc2 = pymupdf.open()
doc2.new_page()
doc2.new_page()
pdf2 = doc2.tobytes()
doc2.close()

files = [('files', ('doc1.pdf', pdf1, 'application/pdf'))]
data = {'user_name': 'Tester'}
r1 = requests.post(url, files=files, data=data)
print('Response 1 status:', r1.status_code)
d1 = r1.json()
print('Response 1 json:', d1.get('id'), d1.get('files'), d1.get('source_page_count'))

job_id = d1.get('id')
files2 = [('files', ('doc2.pdf', pdf2, 'application/pdf'))]
data2 = {'job_id': job_id, 'user_name': 'Tester'}
r2 = requests.post(url, files=files2, data=data2)
print('Response 2 status:', r2.status_code)
d2 = r2.json()
print('Response 2 json:', d2.get('id'), d2.get('files'), d2.get('source_page_count'))
