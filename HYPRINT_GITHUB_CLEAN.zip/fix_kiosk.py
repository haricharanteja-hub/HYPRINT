import re

with open('kiosk.html', 'r', encoding='utf-8') as f:
    code = f.read()

# Fix the JS QR code URL
code = code.replace("img.src = '/kiosk_qr.png?v=2';", "img.src = 'kiosk_qr.png?v=2';")

# Fix the header status JS
header_js_old = """      const dot = document.querySelector('.status-dot');
      const text = document.querySelector('.header-status');
      
      if(d.status === 'ONLINE') {
        if(dot) dot.style.background = '#10B981';
        if(text) text.innerHTML = `<div class="status-dot" style="background:#10B981"></div> ${d.printer_name || 'Printer'} - Ready`;
      } else {
        if(dot) dot.style.background = '#EF4444';
        if(text) text.innerHTML = `<div class="status-dot" style="background:#EF4444"></div> ${d.printer_name || 'Printer'} - ${d.reason || 'OFFLINE'}`;
      }"""

header_js_new = """      const beacon = document.getElementById('printer-beacon');
      const text = document.getElementById('printer-line-text');
      
      if(d.status === 'ONLINE') {
        if(beacon) beacon.style.background = '#10B981';
        if(text) text.innerHTML = `${d.printer_name || 'Printer'} - Ready`;
      } else {
        if(beacon) beacon.style.background = '#EF4444';
        if(text) text.innerHTML = `${d.printer_name || 'Printer'} - ${d.reason || 'OFFLINE'}`;
      }"""
code = code.replace(header_js_old, header_js_new)

# Add sheets_total / pages to the Welcome screen
anim_html_old = """<h2 style="font-size:36px; font-weight:800; color:white; margin-bottom:12px;">Welcome <span id="exec-name-1" style="color:#60A5FA;"></span>!</h2>
        <p style="color:var(--text-muted); font-size:20px;">Your print is ready.</p>"""

anim_html_new = """<h2 style="font-size:36px; font-weight:800; color:white; margin-bottom:12px;">Welcome <span id="exec-name-1" style="color:#60A5FA;"></span>!</h2>
        <p style="color:var(--text-muted); font-size:20px;">Your <span id="exec-pages-1" style="color:white;font-weight:bold;"></span> pages print is ready.</p>"""
code = code.replace(anim_html_old, anim_html_new)

# Update the JS to pass sheets_total
anim_js_old = """          document.getElementById('exec-name-1').innerText = job.user_name || 'Student';
          document.getElementById('exec-name-3').innerText = job.user_name || 'Student';"""

anim_js_new = """          document.getElementById('exec-name-1').innerText = job.user_name || 'Student';
          document.getElementById('exec-name-3').innerText = job.user_name || 'Student';
          const pages = job.pages_selected || job.source_page_count || 1;
          const total = (job.copies > 1) ? (pages * job.copies) : pages;
          if (document.getElementById('exec-pages-1')) document.getElementById('exec-pages-1').innerText = total;"""
code = code.replace(anim_js_old, anim_js_new)

with open('kiosk.html', 'w', encoding='utf-8') as f:
    f.write(code)

print("Fixed kiosk.html")
