import subprocess
import time
import win32print
import win32service
import win32gui
import win32con
import win32process
import psutil

printer_name = "HP LaserJet Pro P1100 plus series"
print(f"Sending test print to: {printer_name}...")
hdesk = win32service.OpenDesktop('default', 0, True, win32con.GENERIC_ALL)
h = win32print.OpenPrinter(printer_name)

# Send test page via printui
p = subprocess.Popen(['rundll32.exe', 'printui.dll,PrintUIEntry', '/k', '/n', printer_name])

for i in range(20):
    time.sleep(0.5)
    jobs = win32print.EnumJobs(h, 0, -1, 1)
    hwnds = hdesk.EnumDesktopWindows()
    alerts = []
    for hw in hwnds:
        if win32gui.IsWindowVisible(hw):
            t = win32gui.GetWindowText(hw)
            if t:
                try:
                    _, pid = win32process.GetWindowThreadProcessId(hw)
                    pn = psutil.Process(pid).name().lower()
                except Exception:
                    pn = ''
                if any(k in pn or k in t.lower() for k in ['hp', 'laser', 'print', 'cartridge', 'door', 'cover', 'test', 'error', 'warn', 'dialog']):
                    alerts.append(f"{pn} (PID {pid}): '{t}'")
    
    jobs_str = [f"Job {j.get('JobId')} (0x{j.get('Status'):08X}, pStatus='{j.get('pStatus')}')" for j in jobs]
    print(f"[{i*0.5:4.1f}s] Spooler Jobs ({len(jobs)}): {jobs_str}")
    if alerts:
        print(f"       Windows: {alerts}")

win32print.ClosePrinter(h)
