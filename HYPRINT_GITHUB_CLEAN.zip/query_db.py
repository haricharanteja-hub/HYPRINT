from database import get_session, PrintJob
with get_session() as s:
    jobs = s.query(PrintJob).all()
    for j in jobs:
        print(j.id, j.status, j.original_filename)
