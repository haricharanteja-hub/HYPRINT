import subprocess
import re
import json
import os
import time
import sys
import shutil
import urllib.request

LOG_FILE = "cloudflare.log"

def is_backend_alive():
    try:
        req = urllib.request.urlopen("http://127.0.0.1:8000/api/status", timeout=3)
        return req.status == 200
    except Exception:
        return False

def is_tunnel_alive(tunnel_url):
    try:
        req = urllib.request.urlopen(f"{tunnel_url}/api/status", timeout=5)
        return req.status == 200
    except Exception:
        return False

def ensure_backend_running():
    if not is_backend_alive():
        print("[HYPRINT Auto-Manager] FastAPI Backend is NOT running on port 8000. Launching Uvicorn...")
        venv_python = os.path.join(".venv", "Scripts", "python.exe")
        python_exe = venv_python if os.path.exists(venv_python) else sys.executable
        
        subprocess.Popen(
            [python_exe, "-m", "uvicorn", "main:app", "--port", "8000", "--host", "0.0.0.0"],
            creationflags=subprocess.CREATE_NEW_CONSOLE if os.name == 'nt' else 0
        )
        
        for _ in range(12):
            time.sleep(1)
            if is_backend_alive():
                print("[HYPRINT Auto-Manager] FastAPI Backend started successfully on http://127.0.0.1:8000")
                return True
        print("[HYPRINT Auto-Manager] Warning: Backend took long to start, proceeding anyway...")
    else:
        print("[HYPRINT Auto-Manager] FastAPI Backend is healthy on http://127.0.0.1:8000")

def update_html_fallbacks(tunnel_url):
    """Update hardcoded DEFAULT_BACKEND_URL in all HTML files."""
    for html_name in ["index.html", "kiosk.html"]:
        for dir_path in [".", "static", "public"]:
            target_path = os.path.join(dir_path, html_name) if dir_path != "." else html_name
            if os.path.exists(target_path):
                try:
                    with open(target_path, "r", encoding="utf-8") as f:
                        content = f.read()
                    updated = re.sub(
                        r"const DEFAULT_BACKEND_URL = ['\"][^'\"]+['\"];",
                        f"const DEFAULT_BACKEND_URL = '{tunnel_url}';",
                        content
                    )
                    with open(target_path, "w", encoding="utf-8") as f:
                        f.write(updated)
                except Exception as e:
                    print(f"[HYPRINT Auto-Manager] Error updating {target_path}: {e}")

def run_tunnel_and_deploy():
    ensure_backend_running()

    print("[HYPRINT Auto-Manager] Starting fresh Cloudflare Tunnel...")
    if os.path.exists(LOG_FILE):
        try:
            os.remove(LOG_FILE)
        except Exception:
            pass

    cloudflared_bin = os.path.join("bin", "cloudflared.exe")
    if not os.path.exists(cloudflared_bin):
        cloudflared_bin = "cloudflared"

    process = subprocess.Popen(
        [cloudflared_bin, "tunnel", "--protocol", "http2", "--url", "http://127.0.0.1:8000", "--logfile", LOG_FILE],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    tunnel_url = None
    url_pattern = re.compile(r'https://[a-zA-Z0-9-]+\.trycloudflare\.com')

    print("[HYPRINT Auto-Manager] Waiting for Cloudflare Tunnel URL...")
    for _ in range(30):
        time.sleep(1)
        if os.path.exists(LOG_FILE):
            try:
                with open(LOG_FILE, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                match = url_pattern.search(content)
                if match:
                    tunnel_url = match.group(0)
                    break
            except Exception as e:
                print(f"[HYPRINT Auto-Manager] Error reading log: {e}")

    if not tunnel_url:
        print("[HYPRINT Auto-Manager] Failed to get Cloudflare Tunnel URL. Retrying...")
        try:
            process.terminate()
        except Exception:
            pass
        return

    print(f"\n=======================================================")
    print(f"[HYPRINT Auto-Manager] ACTIVE CLOUDFLARE TUNNEL URL:")
    print(f"  {tunnel_url}")
    print(f"=======================================================\n")

    # Write tunnel.url file
    try:
        with open("tunnel.url", "w") as f:
            f.write(tunnel_url + "\n")
    except Exception:
        pass

    # Keep PUBLIC_BASE_URL pointing to published Firebase portal
    # The tunnel is recorded in tunnel.url and api_config.json for API calls

    # Update api_config.json everywhere
    config_payload = {"backend_url": tunnel_url, "updated_at": int(time.time())}
    for p in ["api_config.json", os.path.join("public", "api_config.json"), os.path.join("static", "api_config.json")]:
        try:
            os.makedirs(os.path.dirname(p), exist_ok=True) if os.path.dirname(p) else None
            with open(p, "w") as f:
                json.dump(config_payload, f, indent=2)
        except Exception as e:
            print(f"[HYPRINT Auto-Manager] Warning writing {p}: {e}")

    # Update HTML fallbacks
    update_html_fallbacks(tunnel_url)

    # Deploy to Firebase Hosting
    print("[HYPRINT Auto-Manager] Deploying updated configs to Firebase Hosting...")
    try:
        deploy_cmd = 'cmd.exe /c "set GOOGLE_APPLICATION_CREDENTIALS=firebase-key.json && C:\\Users\\Student\\AppData\\Roaming\\npm\\firebase.cmd deploy --only hosting --project hyprint-64865 --non-interactive"'
        d_res = subprocess.run(deploy_cmd, shell=True, capture_output=True, text=True, timeout=90)
        if d_res.returncode == 0:
            print("[HYPRINT Auto-Manager] Firebase Hosting deployment SUCCESSFUL!")
        else:
            print(f"[HYPRINT Auto-Manager] Firebase deploy warning: {d_res.stderr or d_res.stdout}")
    except Exception as err:
        print(f"[HYPRINT Auto-Manager] Firebase deploy error: {err}")

    # Monitor loop with tunnel health checking
    print(f"[HYPRINT Auto-Manager] Monitoring tunnel health...")
    fail_count = 0
    try:
        while process.poll() is None:
            time.sleep(10)
            if not is_backend_alive():
                print("[HYPRINT Auto-Manager] Backend fell offline! Restarting backend...")
                ensure_backend_running()
            
            # Health check the tunnel
            if not is_tunnel_alive(tunnel_url):
                fail_count += 1
                print(f"[HYPRINT Auto-Manager] Warning: Tunnel health check failed ({fail_count}/3)...")
                if fail_count >= 3:
                    print("[HYPRINT Auto-Manager] Tunnel expired or dropped! Triggering fresh reconnection...")
                    try:
                        process.terminate()
                    except Exception:
                        pass
                    break
            else:
                fail_count = 0
    except KeyboardInterrupt:
        try:
            process.terminate()
        except Exception:
            pass
        sys.exit(0)

if __name__ == "__main__":
    while True:
        try:
            run_tunnel_and_deploy()
        except KeyboardInterrupt:
            print("Exiting...")
            break
        except Exception as e:
            print(f"[HYPRINT Auto-Manager] Loop error: {e}")
        time.sleep(5)
