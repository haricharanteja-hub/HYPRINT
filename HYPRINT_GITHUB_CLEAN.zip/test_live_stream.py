import asyncio
import websockets
import json
import time

async def stream_test():
    uri = 'ws://127.0.0.1:8000/ws/status'
    print(f'Connecting to {uri}...')
    async with websockets.connect(uri) as ws:
        for i in range(3):
            t0 = time.time()
            msg = await asyncio.wait_for(ws.recv(), timeout=2.5)
            d = json.loads(msg)
            t_elapsed = time.time() - t0
            st = d.get('status')
            code = d.get('error_code')
            sensors = d.get('sensors', {})
            door = sensors.get('door_open')
            toner_low = sensors.get('toner_low')
            cartridge_missing = sensors.get('cartridge_missing')
            print(f'Packet {i+1} in {t_elapsed:.2f}s -> Status: {st} | Code: {code} | DoorOpen: {door} | TonerLow: {toner_low} | CartridgeMissing: {cartridge_missing}')

if __name__ == '__main__':
    asyncio.run(stream_test())
