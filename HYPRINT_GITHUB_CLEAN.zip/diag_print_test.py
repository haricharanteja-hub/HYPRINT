import subprocess
import time
import win32print
import win32service
import win32gui
import win32con
import win32process
import psutil

printer_name = "HP LaserJet Pro P1100 plus series"
pdf_path = r"C:\Users\Student\.gemini\antigravity-ide\scratch\HYPRINT\graph_paper.pdf"
sumatra_path = r"C:\Users\Student\.gemini\antigravity-ide\scratch\HYPRINT\bin\SumatraPDF.exe"

print(f"=== TESTING PRINT DISPATCH TO: '{printer_name}' ===")
h = win32print.OpenPrinter(printer_name)

# Initial queue state
jobs_before = win32print.EnumJobs(h, 0, -1, 1)
print(f"Queue before print: {len(jobs_before)} job(s)")

# Launch SumatraPDF
cmd = [sumatra_path, "-silent", "-print-to", printer_name, "-print-settings", "fit,monochrome,simplex", "-exit-on-print", pdf_path]
print("Running command:", " ".join(cmd))
t0 = time.time()
proc = subprocess.run(cmd, capture_output=True, timeout=10)
print(f"SumatraPDF exited in {time.time() - t0:.2f}s with code: {proc.returncode}")

# Now watch for 12 seconds
print("\n=== WATCHING FOR 12 SECONDS (SPOOLER JOBS + WINDOWS) ===")
hdesk = win32service.OpenDesktop('default', 0, True, win32con.GENERIC_ALL)

for i in range(24): # 24 x 0.5s = 12s
    time.sleep(0.5)
    now_elapsed = (i + 1) * 0.5
    
    # 1. Spooler status & jobs
    info = win32print.GetPrinter(h, 2)
    p_status = info.get("Status", 0)
    jobs = win32print.EnumJobs(h, 0, -1, 1)
    
    # 2. Windows on default desktop
    hwnds = hdesk.EnumDesktopWindows()
    detected_alerts = []
    for hw in hwnds:
        if win32gui.IsWindowVisible(hw):
            t = win32gui.GetWindowText(hw)
            if t:
                try:
                    _, pid = win32process.GetWindowThreadProcessId(hw)
                    pname = psutil.Process(pid).name().lower()
                except Exception:
                    pname = "unknown"
                
                # Check if not browser/IDE
                if pname not in ['chrome.exe', 'msedge.exe', 'firefox.exe', 'antigravity.exe', 'antigravity ide.exe', 'code.exe']:
                    detected_alerts.append(f"{pname} (PID {pid}): '{t}'")
    
    jobs_summary = [f"Job {j.get('JobId')} (Status=0x{j.get('Status'):08X}, pStatus='{j.get('pStatus')}')" for j in jobs]
    print(f"[T={now_elapsed:4.1f}s] Printer Status=0x{p_status:08X} | Jobs ({len(jobs)}): {jobs_summary}")
    if detected_alerts:
        print(f"         Alert Windows: {detected_alerts}")

win32print.ClosePrinter(h)
