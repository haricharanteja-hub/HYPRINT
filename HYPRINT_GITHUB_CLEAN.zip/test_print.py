import asyncio
import cups_manager
import config
import hardware_monitor

async def test_print():
    printer = cups_manager.get_active_printer_name()
    print(f"Active printer (cups_manager): {printer}")
    
    status = hardware_monitor._fetch_raw_printer_status()
    print(f"Hardware Monitor Status: {status}")

if __name__ == "__main__":
    asyncio.run(test_print())
