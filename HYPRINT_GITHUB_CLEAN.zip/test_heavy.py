import urllib.request
import time
import os

dummy_pdf = "test_heavy.pdf"
# Create an 8MB dummy PDF file
with open(dummy_pdf, "wb") as f:
    f.write(b"%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Count 1/Kids[3 0 R]>>endobj\n3 0 obj<</Type/Page/MediaBox[0 0 612 792]/Parent 2 0 R>>endobj\nstream\n" + (b"0" * (8 * 1024 * 1024)) + b"\nendstream\nxref\n0 4\n0000000000 65535 f\n0000000009 00000 n\n0000000052 00000 n\n0000000097 00000 n\ntrailer<</Size 4/Root 1 0 R>>\nstartxref\n178\n%%EOF\n")

print("8MB test PDF created. Uploading via Cloudflare tunnel...")
boundary = "----WebKitBoundaryHeavy"
part1 = f'--{boundary}\r\nContent-Disposition: form-data; name="files"; filename="test_heavy.pdf"\r\nContent-Type: application/pdf\r\n\r\n'.encode()
with open(dummy_pdf, "rb") as f:
    pdf_bytes = f.read()
part2 = f"\r\n--{boundary}--\r\n".encode()
body = part1 + pdf_bytes + part2

t0 = time.time()
req_cf = urllib.request.Request(
    "https://educated-school-spiritual-fall.trycloudflare.com/api/upload",
    data=body,
    headers={"Content-Type": f"multipart/form-data; boundary={boundary}"}
)
try:
    resp = urllib.request.urlopen(req_cf, timeout=60)
    print("8MB Tunnel upload succeeded in", round(time.time() - t0, 2), "s!")
    print(resp.read().decode()[:200])
except Exception as e:
    print("8MB Tunnel upload failed:", e)

if os.path.exists(dummy_pdf):
    os.remove(dummy_pdf)
