"""
main.py — Campus Print Kiosk backend.

Run locally:   uvicorn main:app --host 127.0.0.1 --port 8000
Production:    via deploy/kiosk-backend.service (systemd, Restart=always)

The server binds to 127.0.0.1 ONLY. Public reachability comes exclusively
from the Cloudflare named tunnel, which lets us expose student routes to the
internet while /admin and the debug routes stay physically unreachable from
outside the machine (enforced again in code by require_local()).
"""

import asyncio
import hardware_monitor
import base64
import hashlib
import io
import math
import os
import random
import secrets
import time
import uuid
from datetime import datetime, timedelta, timezone

import json
import re
import shutil
from typing import Optional, List
from pydantic import BaseModel
import qrcode
from fastapi import (
    Depends, FastAPI, File, Form, HTTPException, Request, UploadFile,
    WebSocket, WebSocketDisconnect,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func

import config
import cups_manager
import database
import payments
import led_notifier
import pdf_tools
import file_processor
from file_processor import PageRangeError
import pymupdf
from database import (
    PrintJob, JobStatus, STRANDED_STATES, TERMINAL_STATES,
    atomic_transition, get_session, get_write_session, init_db,
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")

os.makedirs(config.SHM_DIR, exist_ok=True)

app = FastAPI(title="Campus Print Kiosk", docs_url=None, redoc_url=None)
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.ALLOWED_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


def _serve_html(filename: str):
    """Safely return HTML content across Windows, Linux, and Vercel environments."""
    for candidate in [os.path.join(STATIC_DIR, filename), os.path.join(BASE_DIR, filename)]:
        if os.path.exists(candidate):
            with open(candidate, "r", encoding="utf-8") as f:
                return HTMLResponse(content=f.read(), status_code=200, headers={"Cache-Control": "no-cache, no-store, must-revalidate"})
    return FileResponse(os.path.join(STATIC_DIR, filename))


@app.get("/")
@app.get("/api")
@app.get("/api/index")
@app.get("/index.html")
def root_page():
    """Serve the student-facing print page."""
    return _serve_html("index.html")


@app.get("/select-location")
def select_location_redirect():
    """Legacy route — redirect to root."""
    return _serve_html("index.html")


@app.get("/api_config.json")
def get_api_config():
    config_path = os.path.join(STATIC_DIR, "api_config.json")
    if not os.path.exists(config_path):
        config_path = os.path.join(BASE_DIR, "api_config.json")
    if os.path.exists(config_path):
        return FileResponse(config_path, media_type="application/json")
    return JSONResponse({"backend_url": config.PUBLIC_BASE_URL})


@app.get("/graph_paper.pdf")
@app.get("/static/graph_paper.pdf")
def get_graph_paper():
    gp_path = os.path.join(STATIC_DIR, "graph_paper.pdf")
    if not os.path.exists(gp_path):
        gp_path = os.path.join(BASE_DIR, "graph_paper.pdf")
    if os.path.exists(gp_path):
        return FileResponse(gp_path, media_type="application/pdf", headers={"Cache-Control": "public, max-age=3600"})
    raise HTTPException(404, "Graph paper PDF not found.")


# ===========================================================================
# Access control
# ===========================================================================
def require_local(request: Request):
    """
    Gate for /admin and debug routes.

    Defense in depth: the Cloudflare tunnel DOES reach 127.0.0.1:8000, so
    tunnelled requests would otherwise sail straight into the admin panel.
    Tunnelled requests arrive with the tunnel's own source address and
    X-Forwarded-For / CF-Connecting-IP set; a genuinely local browser tab on
    the kiosk PC has neither.

    Rule: a genuinely local request is always allowed. Anything else MUST
    present a valid KIOSK_ADMIN_TOKEN — and if no token is configured, remote
    admin access is simply impossible (fail closed, never open).
    """
    if os.environ.get("VERCEL"):
        return True
    client_host = request.client.host if request.client else None
    is_local = client_host in ("127.0.0.1", "::1", "localhost") and not (
        request.headers.get("x-forwarded-for") or request.headers.get("cf-connecting-ip")
    )
    if is_local:
        return True

    supplied = request.headers.get("x-admin-token") or request.query_params.get("token")
    if config.ADMIN_TOKEN and supplied and secrets.compare_digest(supplied, config.ADMIN_TOKEN):
        return True
    raise HTTPException(status_code=401, detail="Admin access is restricted to the kiosk PC (or a valid admin token).")


# ===========================================================================
# WebSocket manager
# ===========================================================================
class ConnectionManager:
    def __init__(self):
        self._per_job: dict[str, list[WebSocket]] = {}
        self._kiosk: list[WebSocket] = []
        self._status: list[WebSocket] = []
        self._lock = asyncio.Lock()

    async def join_job(self, job_id: str, ws: WebSocket):
        await ws.accept()
        async with self._lock:
            self._per_job.setdefault(job_id, []).append(ws)

    async def leave_job(self, job_id: str, ws: WebSocket):
        async with self._lock:
            lst = self._per_job.get(job_id, [])
            if ws in lst:
                lst.remove(ws)
            if not lst:
                self._per_job.pop(job_id, None)

    async def join_kiosk(self, ws: WebSocket):
        await ws.accept()
        async with self._lock:
            self._kiosk.append(ws)

    async def leave_kiosk(self, ws: WebSocket):
        async with self._lock:
            if ws in self._kiosk:
                self._kiosk.remove(ws)

    async def join_status(self, ws: WebSocket):
        await ws.accept()
        async with self._lock:
            self._status.append(ws)

    async def leave_status(self, ws: WebSocket):
        async with self._lock:
            if ws in self._status:
                self._status.remove(ws)

    async def _send_all(self, targets: list[WebSocket], payload: dict):
        dead = []
        for ws in list(targets):
            try:
                await ws.send_json(payload)
            except Exception:
                dead.append(ws)
        if dead:
            async with self._lock:
                for ws in dead:
                    if ws in targets:
                        targets.remove(ws)

    async def to_job(self, job_id: str, payload: dict):
        async with self._lock:
            targets = list(self._per_job.get(job_id, []))
        await self._send_all(targets, payload)

    async def to_kiosk(self, payload: dict):
        async with self._lock:
            targets = list(self._kiosk)
        await self._send_all(targets, payload)

    async def to_status(self, payload: dict):
        async with self._lock:
            targets = list(self._status)
        await self._send_all(targets, payload)


manager = ConnectionManager()


async def broadcast_job(job_id: str, message: str):
    """Push the current DB truth for one job to its phone AND the kiosk screen."""
    with get_session() as s:
        job = s.get(PrintJob, job_id)
        if not job:
            return
        payload = job.public()

    payload["message"] = message
    phone_payload = {**payload}
        
    await manager.to_job(job_id, phone_payload)
    await manager.to_kiosk({"event": "job_update", **payload, "message": message})


# ===========================================================================
# Job state, pricing and file helpers (single source of truth)
# ===========================================================================
# A job's files/options may only be changed before money moves.
EDITABLE_STATES = {
    JobStatus.UPLOADED, JobStatus.PENDING_PAYMENT,
    JobStatus.PREFLIGHT_BLOCKED, JobStatus.ORDER_CREATED,
}
# Paid and somewhere between "queued for the printer" and "paper coming out".
PRINT_ACTIVE_STATES = {
    JobStatus.PAID, JobStatus.PAID_PRINTING, JobStatus.SPOOLING,
    JobStatus.PRINTING, JobStatus.PAUSED_ERROR,
}
REFUNDED_STATES = {JobStatus.REFUNDED, JobStatus.ABORTED_REFUNDED}
MAX_GRAPH_SHEETS = 100
_UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")

# Background tasks must be referenced, or asyncio may garbage-collect them mid-print.
_bg_tasks: set = set()


def _spawn(coro):
    task = asyncio.create_task(coro)
    _bg_tasks.add(task)
    task.add_done_callback(_bg_tasks.discard)
    return task


# One lock per job serialises upload / remove / option edits for that job, so a
# retried upload or a double-tap can never interleave two merges of the same files.
_job_locks: dict[str, asyncio.Lock] = {}


def _job_lock(job_id: str) -> asyncio.Lock:
    lock = _job_locks.get(job_id)
    if lock is None:
        lock = _job_locks[job_id] = asyncio.Lock()
    return lock


# There is exactly one physical printer. The spooler watchdog identifies "our"
# job by diffing the Windows queue, so two jobs must never be in flight at once.
_printer_lock = asyncio.Lock()


def _to_int(value, default: int) -> int:
    try:
        return int(str(value).strip())
    except Exception:
        return default


def _clean_nup(value) -> int:
    n = _to_int(value, 1)
    return n if n in file_processor.VALID_NUP else 1


def _clean_orientation(value) -> str:
    o = str(value or "").strip().lower()
    return o if o in ("portrait", "landscape") else "portrait"


def _clean_copies(value) -> int:
    return max(1, min(config.MAX_COPIES, _to_int(value, 1)))


def _clean_graph(value) -> int:
    return max(0, min(MAX_GRAPH_SHEETS, _to_int(value, 0)))


def compute_quote(source_pages: int, page_range: str | None, nup: int,
                  graph_sheets: int, copies: int) -> dict:
    """
    The ONE pricing formula. public/index.html:recalc() implements the identical maths.
      doc_sheets      = ceil(selected_pages / nup)
      sheets_per_copy = doc_sheets + graph_sheets        (graph paper is never N-up'd)
      sheets_total    = sheets_per_copy * copies
      amount          = sheets_total * PRICE_PER_PAGE    (HP P1108 is simplex-only)
    Raises PageRangeError for a range that cannot be honoured exactly.
    """
    selected = file_processor.parse_page_range(page_range, source_pages) if source_pages > 0 else []
    doc_sheets = math.ceil(len(selected) / nup) if selected else 0
    sheets_per_copy = doc_sheets + graph_sheets
    sheets_total = sheets_per_copy * copies
    amount_paise = int(round(sheets_total * config.PRICE_PER_PAGE * 100))
    return {
        "selected": selected,
        "pages_selected": len(selected),
        "doc_sheets": doc_sheets,
        "graph_sheets": graph_sheets,
        "sheets_per_copy": sheets_per_copy,
        "sheets_total": sheets_total,
        "copies": copies,
        "nup": nup,
        "amount_paise": amount_paise,
        "amount_rupees": amount_paise / 100.0,
    }


def _shm_src(job_id: str) -> str:
    return os.path.join(config.SHM_DIR, f"{job_id}.pdf")


def _shm_meta(job_id: str) -> str:
    return os.path.join(config.SHM_DIR, f"{job_id}_meta.json")


def _shm_files_dir(job_id: str) -> str:
    return os.path.join(config.SHM_DIR, f"{job_id}_files")


def _shm_print(job_id: str) -> str:
    return os.path.join(config.SHM_DIR, f"{job_id}_print.pdf")


def _upload_dir(job_id: str) -> str:
    return os.path.join(BASE_DIR, "uploads", job_id)


def _read_meta(job_id: str) -> list:
    path = _shm_meta(job_id)
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _write_meta(job_id: str, meta: list):
    path = _shm_meta(job_id)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(meta, f)
    os.replace(tmp, path)


def _public_files(meta: list) -> list:
    return [{"name": m.get("name", "Document"), "pages": m.get("pages", 0), "size": m.get("size", 0)} for m in meta]


def _invalidate_previews(job_id: str):
    u_dir = _upload_dir(job_id)
    if not os.path.isdir(u_dir):
        return
    shutil.rmtree(os.path.join(u_dir, "previews"), ignore_errors=True)
    for f in os.listdir(u_dir):
        if f.startswith("preview_bundle_"):
            try:
                os.remove(os.path.join(u_dir, f))
            except OSError:
                pass


def _rebuild_master(job_id: str, meta: list) -> int:
    """Re-merge the job's files (in cart order) into its master PDF. Returns the page count."""
    src = _shm_src(job_id)
    u_master = os.path.join(_upload_dir(job_id), "master_print.pdf")
    paths = [m["path"] for m in meta if m.get("path") and os.path.exists(m["path"])]
    if not paths:
        for p in (src, u_master):
            if os.path.exists(p):
                try:
                    os.remove(p)
                except OSError:
                    pass
        _invalidate_previews(job_id)
        return 0
    if len(paths) == 1:
        tmp = src + ".copy.tmp"
        shutil.copyfile(paths[0], tmp)
        os.replace(tmp, src)
    else:
        file_processor.merge_pdfs(paths, src)
    # Mirror for instant preview & printing, then drop every stale preview.
    os.makedirs(_upload_dir(job_id), exist_ok=True)
    shutil.copyfile(src, u_master)
    _invalidate_previews(job_id)
    return file_processor.inspect_pdf_page_count(src)


def _destroy_job_files(job_id: str):
    """Delete every byte we hold for a job: RAM-disk sources, merged master, bundles, previews."""
    for p in (_shm_src(job_id), _shm_meta(job_id), _shm_print(job_id)):
        if os.path.exists(p):
            try:
                os.remove(p)
            except OSError:
                pass
    shutil.rmtree(_shm_files_dir(job_id), ignore_errors=True)
    shutil.rmtree(_upload_dir(job_id), ignore_errors=True)
    lock = _job_locks.get(job_id)
    if lock is not None and not lock.locked():
        _job_locks.pop(job_id, None)


async def _refund_payment_full(payment_id: str, amount_paise: int | None, job_id: str,
                               reason: str) -> tuple[str | None, str | None]:
    """Refund through Razorpay. amount_paise=None refunds the full captured amount.
    Returns (refund_id, error) — exactly one is non-None."""
    client = payments.get_razorpay_client()
    body = {"notes": {"job_id": job_id, "reason": (reason or "")[:200]}}
    if amount_paise:
        body["amount"] = int(amount_paise)
    last_err = None
    for attempt_body in (body, {k: v for k, v in body.items() if k != "notes"}):
        try:
            refund = await asyncio.to_thread(client.payment.refund, payment_id, attempt_body)
            refund_id = refund.get("id") if isinstance(refund, dict) else None
            if refund_id:
                return refund_id, None
            last_err = f"Gateway returned no refund id: {refund}"
        except Exception as e:
            last_err = str(e)
            print(f"[refund] attempt failed for {payment_id}: {e}")
    return None, last_err


# ===========================================================================
async def hardware_broadcaster_loop():
    """
    Sub-second hardware status broadcasting daemon.
    Polls hardware telemetry every 1s and pushes push updates to /ws/status & kiosk.
    """
    last_status = None
    while True:
        await asyncio.sleep(1.0)
        try:
            raw_hw = hardware_monitor.get_printer_status()
            paper_status = database.get_paper_tray_status()
            raw_hw["paper_inventory"] = paper_status
            
            cur_st = raw_hw.get("status")
            sensors = raw_hw.get("sensors", {})
            await manager.to_status(raw_hw)
            await manager.to_kiosk({"event": "hardware_status", **raw_hw})
        except Exception:
            pass


@app.on_event("startup")
async def startup():
    init_db()
    recovered = recover_stranded_jobs()
    if recovered:
        print(f"[boot] recovered {recovered} stranded job(s) -> FAILED_REBOOT")
    _spawn(scavenger_loop())
    _spawn(hardware_broadcaster_loop())
    led_notifier.start()
    if not config.PAYMENT_DISABLED and isinstance(payments.get_razorpay_client(), payments.MockRazorpayClient):
        print("[boot] WARNING: RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET are not configured — the MOCK "
              "payment gateway is active and accepts any signature. Never run a public kiosk like this.")

    # Auto-open kiosk in the default browser
    import webbrowser
    webbrowser.open("http://127.0.0.1:8000/kiosk.html")


def recover_stranded_jobs() -> int:
    """
    A crash/power-cut mid-print leaves rows in PAID/SPOOLING/PRINTING forever,
    which would show as phantom active jobs on the kiosk screen and block the
    queue. At boot, every such row is moved to FAILED_REBOOT.

    These are jobs the student PAID for and may not have received, so they're
    surfaced in the admin dashboard as needing a manual refund decision rather
    than being silently auto-refunded (we can't know from here how many sheets
    physically came out before the power died).
    """
    count = 0
    with get_write_session() as s:
        stranded = s.query(PrintJob).filter(PrintJob.status.in_(list(STRANDED_STATES))).all()
        for job in stranded:
            job.status = JobStatus.FAILED_REBOOT
            job.error_reason = "Kiosk restarted while this job was in progress."
            _purge_files(job)
            count += 1
        s.commit()
    return count


async def scavenger_loop():
    """Every 5 minutes:
      1. Unpaid jobs idle for ABANDONED_JOB_TTL_SECONDS -> EXPIRED, files destroyed.
      2. PRIVACY: finished jobs (completed / refunded / failed / expired) have every
         document byte destroyed once they are older than FINISHED_JOB_FILE_TTL_SECONDS
         (10 min). Student hall tickets and ID cards must never pile up on the kiosk disk —
         this runs on Windows too (the old code skipped Windows entirely).
      3. Orphan files with no DB row are swept from the RAM disk and uploads/.
    The 10-minute grace on Windows lets the spooler/USB driver finish streaming first."""
    while True:
        try:
            await asyncio.sleep(config.SCAVENGER_INTERVAL_SECONDS)
            await asyncio.to_thread(_scavenge_once)

            # --- paid but never printed (e.g. stuck in PAID) -> refund in full ---
            uncollected_cutoff = datetime.now(timezone.utc) - timedelta(
                seconds=config.UNCOLLECTED_TTL_SECONDS)
            with get_session() as s:
                stale_paid = s.query(PrintJob).filter(
                    PrintJob.status == JobStatus.PAID,
                    PrintJob.paid_at < uncollected_cutoff.replace(tzinfo=None),
                ).all()
                ids = [j.id for j in stale_paid]
            for jid in ids:
                await fail_and_refund(jid, "Not printed in time.", sheets_done=0,
                                      from_states={JobStatus.PAID})
        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"[scavenger] error: {e}")


def _scavenge_once() -> int:
    now = datetime.now(timezone.utc).replace(tzinfo=None)  # SQLite stores naive UTC
    unpaid_cutoff = now - timedelta(seconds=config.ABANDONED_JOB_TTL_SECONDS)
    finished_cutoff = now - timedelta(seconds=config.FINISHED_JOB_FILE_TTL_SECONDS)
    to_destroy: list[str] = []
    expired = 0
    with get_write_session() as s:
        stale = s.query(PrintJob).filter(
            PrintJob.status.in_([JobStatus.UPLOADED, JobStatus.PENDING_PAYMENT,
                                 JobStatus.PREFLIGHT_BLOCKED, JobStatus.ORDER_CREATED]),
            PrintJob.updated_at < unpaid_cutoff,
        ).all()
        for job in stale:
            job.status = JobStatus.EXPIRED
            job.error_reason = "Expired before payment."
            to_destroy.append(job.id)
            expired += 1

        finished = s.query(PrintJob.id).filter(
            PrintJob.status.in_(list(TERMINAL_STATES)),
            PrintJob.updated_at < finished_cutoff,
        ).all()
        to_destroy.extend(row[0] for row in finished)
        s.commit()

    for jid in set(to_destroy):
        _destroy_job_files(jid)
    _sweep_orphan_files()
    if expired:
        print(f"[scavenger] expired {expired} unpaid job(s)")
    return expired


def _purge_files(job: PrintJob):
    for p in {job.source_path, job.print_path}:
        if p and os.path.exists(p):
            try:
                os.remove(p)
            except OSError:
                pass


def _sweep_orphan_files():
    """Remove RAM-disk files and uploads/ folders that belong to no live job."""
    cutoff = time.time() - config.ABANDONED_JOB_TTL_SECONDS
    targets = []
    for root in (config.SHM_DIR, os.path.join(BASE_DIR, "uploads")):
        try:
            for name in os.listdir(root):
                targets.append((root, name))
        except OSError:
            continue
    with get_session() as s:
        for root, name in targets:
            path = os.path.join(root, name)
            try:
                if os.path.getmtime(path) > cutoff:
                    continue
            except OSError:
                continue
            stem = name.split(".")[0].split("_")[0]
            job = s.get(PrintJob, stem)
            if job is not None and job.status not in TERMINAL_STATES:
                continue
            if job is not None and job.status in PRINT_ACTIVE_STATES:
                continue
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    os.remove(path)
            except OSError:
                pass


# ===========================================================================
# Pre-flight
# ===========================================================================

_last_logged_hardware_status = None

@app.get("/api/status")
async def get_hardware_status():
    global _last_logged_hardware_status
    try:
        loop = asyncio.get_running_loop()
        # Direct, unadulterated hardware telemetry straight from the printer via Windows Spooler
        status_info = hardware_monitor.get_printer_status()
        
        # Virtual inventory is attached as an advisory metric for staff, never overriding real hardware truth
        paper_status = database.get_paper_tray_status()
        status_info["paper_inventory"] = paper_status

        cur_status = status_info.get("status", "UNKNOWN")
        if cur_status != _last_logged_hardware_status:
            _last_logged_hardware_status = cur_status
            try:
                with get_write_session() as s:
                    log_entry = database.PrinterHardwareLog(
                        printer_status_code=2 if cur_status == "ONLINE" else 1,
                        error_state_code=0 if cur_status == "ONLINE" else 1,
                        status_message=f"{cur_status}: {status_info.get('message', '')}",
                        is_blocking=(cur_status not in ("ONLINE", "PRINTING", "BUSY")),
                    )
                    s.add(log_entry)
                    s.commit()
            except Exception as log_err:
                print(f"[get_hardware_status] could not log hardware transition: {log_err}")

        # If the physical printer says ONLINE but virtual estimate is low, attach an advisory note
        if status_info.get("status") == "ONLINE" and paper_status.get("is_low"):
            status_info["advisory"] = f"Virtual tray counter low ({paper_status['sheets_remaining']} sheets estimated)"

        return status_info
    except Exception as e:
        return {"status": "OFFLINE", "message": str(e)}

@app.get("/api/status/raw")
async def get_raw_status():
    loop = asyncio.get_running_loop()
    status_info = hardware_monitor.get_printer_status()
    return status_info.get("raw_telemetry", {})

@app.get("/api/stats/today")
async def get_stats_today():
    with get_session() as s:
        # Get count of successful prints today
        today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        from sqlalchemy import func
        count = s.query(func.count(PrintJob.id)).filter(
            PrintJob.status == JobStatus.COMPLETED,
            PrintJob.created_at >= today
        ).scalar()
        return {"prints_today": count or 0}

@app.get("/api/preflight")
def preflight():
    # Every phone calls this every few seconds, so it must never touch the printer itself:
    # it reads the hardware monitor's cached state (refreshed by its own background thread).
    # Querying the USB printer per request used to interrupt the data stream mid-print.
    reasons = []
    fault = None
    try:
        raw_hw = hardware_monitor.get_printer_status()
        if not raw_hw.get("is_ready", True) or raw_hw.get("status") == "MAINTENANCE":
            fault = raw_hw.get("message") or "Printer Under Maintenance"
    except Exception:
        pass

    if fault is None:
        # The printer just recovered. Any job that was parked in
        # PREFLIGHT_BLOCKED at upload time can now proceed to payment —
        # without this, a student who uploaded during a paper jam would have
        # to re-upload from scratch once staff refilled the tray.
        with get_write_session() as s:
            unblocked = s.query(PrintJob).filter(
                PrintJob.kiosk_id == config.KIOSK_ID,
                PrintJob.status == JobStatus.PREFLIGHT_BLOCKED,
            ).update(
                {"status": JobStatus.PENDING_PAYMENT, "error_reason": None},
                synchronize_session=False,
            )
            s.commit()
        if unblocked:
            print(f"[preflight] printer recovered, unblocked {unblocked} job(s)")

    return {
        "printer_ok": fault is None,
        "reasons": reasons,
        "blocking_reason": fault,
        "kiosk_id": config.KIOSK_ID,
        "price_per_page": config.PRICE_PER_PAGE,
        "max_copies": config.MAX_COPIES,
        "max_upload_mb": config.MAX_UPLOAD_BYTES // (1024 * 1024),
        "payment_disabled": config.PAYMENT_DISABLED,
    }


# ===========================================================================
# Upload + merging + pricing
# ===========================================================================
_MIME_EXT = {
    "application/pdf": ".pdf",
    "image/jpeg": ".jpg", "image/jpg": ".jpg", "image/png": ".png", "image/webp": ".webp",
    "image/bmp": ".bmp", "image/gif": ".gif", "image/tiff": ".tiff",
    "application/msword": ".doc",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/vnd.ms-powerpoint": ".ppt",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
    "application/vnd.ms-excel": ".xls",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
    "text/plain": ".txt", "application/rtf": ".rtf", "text/rtf": ".rtf",
    "application/vnd.oasis.opendocument.text": ".odt",
}
UNSUPPORTED_FORMAT_MSG = ("Supported formats: PDF, Word (DOCX/DOC), PowerPoint (PPTX/PPT), Excel (XLSX/XLS), "
                          "TXT, RTF, ODT, PNG, JPG, WEBP, BMP, GIF, TIFF.")


def _resolve_extension(file: UploadFile) -> str | None:
    """Extension from the filename, falling back to the MIME type (Android camera/gallery
    uploads sometimes arrive without an extension)."""
    ext = os.path.splitext(file.filename or "")[1].lower()
    if ext in file_processor.SUPPORTED_EXTS:
        return ext
    mime = (file.content_type or "").split(";")[0].strip().lower()
    return _MIME_EXT.get(mime)


async def _ingest_files(job_id: str, incoming: list[UploadFile], upload_id: str,
                        meta: list) -> tuple[list, list[str]]:
    """Stream, normalize and append files to meta. Returns (meta, warnings).
    A file that fails conversion is skipped with a warning; only if EVERY file fails do we error."""
    files_dir = _shm_files_dir(job_id)
    os.makedirs(files_dir, exist_ok=True)
    total_written = sum(int(m.get("size") or 0) for m in meta)
    warnings: list[str] = []
    added = 0

    for idx, file in enumerate(incoming):
        filename = os.path.basename(file.filename or "") or f"document_{idx + 1}"
        ext = _resolve_extension(file)
        if not ext:
            warnings.append(f"{filename}: unsupported format. {UNSUPPORTED_FORMAT_MSG}")
            continue

        file_uid = uuid.uuid4().hex[:8]
        raw_dest = os.path.join(files_dir, f"{file_uid}_raw{ext}")
        pdf_dest = os.path.join(files_dir, f"{file_uid}_norm.pdf")

        written = 0
        with open(raw_dest, "wb") as fh:
            while chunk := await file.read(1024 * 1024):
                written += len(chunk)
                total_written += len(chunk)
                if total_written > config.MAX_UPLOAD_BYTES:
                    fh.close()
                    os.remove(raw_dest)
                    raise HTTPException(413, f"Total files too large. Limit is {config.MAX_UPLOAD_BYTES // (1024*1024)}MB.")
                fh.write(chunk)

        if written == 0:
            os.remove(raw_dest)
            warnings.append(f"{filename}: the file is empty.")
            continue

        try:
            # Normalize in a worker thread so the event loop (and every other student) never stalls.
            await asyncio.to_thread(file_processor.normalize_to_a4_pdf, raw_dest, pdf_dest)
            f_pages = file_processor.inspect_pdf_page_count(pdf_dest)
            if f_pages < 1:
                raise ValueError("no printable pages found")
        except Exception as err:
            for p in (raw_dest, pdf_dest):
                if os.path.exists(p):
                    try:
                        os.remove(p)
                    except OSError:
                        pass
            warnings.append(f"{filename}: {err}")
            continue
        finally:
            if os.path.exists(raw_dest) and raw_dest != pdf_dest:
                try:
                    os.remove(raw_dest)   # only the normalized PDF is kept
                except OSError:
                    pass

        meta.append({
            "name": filename,
            "pages": f_pages,
            "size": written,
            "path": pdf_dest,
            "upload_id": upload_id,
            "landscape_pages": file_processor.count_landscape_pages(pdf_dest),
        })
        added += 1

    if added == 0 and incoming:
        raise HTTPException(422, "Could not read the uploaded file(s): " + " | ".join(warnings or ["unknown error"]))
    return meta, warnings


def _job_response(job: PrintJob, meta: list, **extra) -> dict:
    res = job.public()
    res["files"] = _public_files(meta)
    res["landscape_pages"] = sum(int(m.get("landscape_pages") or 0) for m in meta)
    res["payment_disabled"] = config.PAYMENT_DISABLED
    res["price_per_sheet"] = config.PRICE_PER_PAGE
    res.update(extra)
    return res


def _apply_quote(job: PrintJob, quote: dict, page_range: str, orientation: str):
    job.page_range = (page_range or None) if quote["pages_selected"] else None
    job.pages_selected = quote["pages_selected"]
    job.selected_pages = json.dumps(quote["selected"]) if quote["selected"] else None
    job.copies = quote["copies"]
    job.duplex = False            # HP LaserJet Pro P1108: simplex-only hardware
    job.pages_per_sheet = quote["nup"]
    job.orientation = orientation
    job.doc_sheets = quote["doc_sheets"]
    job.graph_sheets = quote["graph_sheets"]
    job.sheets_total = quote["sheets_total"]
    job.price_per_page = config.PRICE_PER_PAGE
    job.total_price = quote["amount_rupees"]
    # Any edit invalidates an unpaid Razorpay order: it was priced for the old settings.
    if job.status == JobStatus.ORDER_CREATED:
        job.status = JobStatus.PENDING_PAYMENT
        job.razorpay_order_id = None
        job.payment_order_id = None
        job.amount_paise = None


def _quote_or_fallback(source_pages: int, page_range: str, nup: int, graph: int,
                       copies: int, strict: bool) -> tuple[dict, str | None, str]:
    """Returns (quote, page_range_error, effective_range). While editing (strict=False) an
    in-progress range never blocks an upload; it is reported back instead."""
    try:
        return compute_quote(source_pages, page_range, nup, graph, copies), None, page_range
    except PageRangeError as e:
        if strict:
            raise HTTPException(400, str(e))
        return compute_quote(source_pages, "", nup, graph, copies), str(e), ""


@app.post("/api/submit-job")
@app.post("/api/upload")
async def submit_job(
    request: Request,
    files: list[UploadFile] | None = File(default=None),
    job_id: str | None = Form(None),
    kiosk_id: str = Form(config.KIOSK_ID),
    user_name: str = Form("Student"),
    user_phone: str = Form(""),
    copies: str = Form("1"),
    duplex: str = Form("false"),
    page_range: str = Form(""),
    paper_size: str = Form("A4"),
    orientation: str = Form("portrait"),
    pages_per_sheet: str = Form("1"),
    graph_sheets: str = Form("0"),
    upload_id: str = Form(""),
    is_final_approval: str = Form("false"),
):
    """
    Upload (append) files to a job and/or stage its print options.

    Idempotent by design so flaky mobile networks can never create errors or duplicates:
      * the phone proposes the job id up-front (a fresh UUID) and tags each upload batch
        with an upload_id;
      * a retried batch whose upload_id is already merged is NOT merged again — the
        current job state is simply returned;
      * all edits to one job are serialised by a per-job lock.
    """
    is_final = (request.url.path == "/api/submit-job") or (str(is_final_approval).strip().lower() in ("true", "1", "yes"))

    # --- strict backend hardware guard: only reject on final checkout/submission ---
    if is_final:
        try:
            hw = hardware_monitor.get_printer_status()
            if not hw.get("is_ready", True) or hw.get("status") == "MAINTENANCE":
                msg = hw.get("message") or "Printer Hardware Fault"
                raise HTTPException(status_code=503, detail=f"System Under Maintenance: {msg}")
        except HTTPException:
            raise
        except Exception:
            pass

    # --- cheap rejects first, before touching RAM ---
    declared = request.headers.get("content-length")
    if declared and declared.isdigit() and int(declared) > config.MAX_UPLOAD_BYTES + 1024 * 1024:
        raise HTTPException(413, f"Upload too large. Limit is {config.MAX_UPLOAD_BYTES // (1024*1024)}MB.")

    copies_int = _clean_copies(copies)
    orientation_clean = _clean_orientation(orientation)
    nup_int = _clean_nup(pages_per_sheet)
    graph_int = _clean_graph(graph_sheets)
    upload_key = re.sub(r"[^A-Za-z0-9_-]", "", upload_id or "")[:64]

    clean_name = (user_name or "").strip()[:120]
    if not clean_name or clean_name.lower() in ("enter name",):
        clean_name = "Student"
    raw_digits = "".join(ch for ch in (user_phone or "") if ch.isdigit())
    if len(raw_digits) > 10 and raw_digits.startswith("91"):
        raw_digits = raw_digits[2:]
    clean_phone = raw_digits[-10:] if len(raw_digits) >= 10 else raw_digits

    # --- resolve which job this request belongs to ---
    target_job_id = (job_id or "").strip().lower()
    with get_session() as s:
        row = s.get(PrintJob, target_job_id) if target_job_id else None
        row_status = row.status if row else None
    if row is not None and row_status in EDITABLE_STATES:
        actual_job_id = target_job_id
    elif row is None and _UUID_RE.match(target_job_id):
        actual_job_id = target_job_id          # phone-proposed id: makes retries idempotent
    else:
        actual_job_id = str(uuid.uuid4())      # paid/printing/finished job: start a fresh one

    valid_incoming = [f for f in (files or []) if f and f.filename]
    warnings: list[str] = []
    if row is not None and row_status == JobStatus.EXPIRED and not valid_incoming:
        raise HTTPException(410, "Your upload expired after a long period of inactivity and was deleted "
                                 "for privacy. Please upload your file again.")

    async with _job_lock(actual_job_id):
        meta = _read_meta(actual_job_id)
        already_merged = bool(upload_key) and any(m.get("upload_id") == upload_key for m in meta)

        if valid_incoming and not already_merged:
            try:
                meta, warnings = await _ingest_files(actual_job_id, valid_incoming, upload_key, meta)
                _write_meta(actual_job_id, meta)
                await asyncio.to_thread(_rebuild_master, actual_job_id, meta)
                led_notifier.blink()   # one blink per upload batch (retries of the same batch never re-blink)
            except HTTPException:
                raise
            except Exception as e:
                raise HTTPException(500, f"Upload processing failed: {e}")

        src = _shm_src(actual_job_id)
        source_pages = file_processor.inspect_pdf_page_count(src) if meta and os.path.exists(src) else 0
        if source_pages == 0 and graph_int == 0:
            raise HTTPException(400, "No files uploaded and no graph paper selected.")

        quote, range_error, effective_range = _quote_or_fallback(
            source_pages, page_range, nup_int, graph_int, copies_int, strict=is_final)
        if is_final and quote["sheets_total"] <= 0:
            raise HTTPException(400, "Nothing to print.")

        if len(meta) == 1:
            job_filename = meta[0]["name"]
        elif len(meta) > 1:
            job_filename = f"{len(meta)} Merged Files ({source_pages} Pages)"
        else:
            job_filename = f"Graph Paper ({graph_int} sheet{'s' if graph_int != 1 else ''})"

        try:
            hw_cached = hardware_monitor.get_printer_status()
            fault = hw_cached.get("message") if not hw_cached.get("is_ready", True) else None
        except Exception:
            fault = None

        with get_write_session() as s:
            job = s.get(PrintJob, actual_job_id)
            if job is not None and job.status not in EDITABLE_STATES:
                raise HTTPException(409, "This job has already been paid for and can no longer be changed.")
            if job is None:
                job = PrintJob(
                    id=actual_job_id,
                    kiosk_id=(kiosk_id or config.KIOSK_ID)[:32],
                    release_pin=None,
                    original_filename=job_filename,
                    source_path=src if source_pages else "",
                    print_path=_shm_print(actual_job_id),
                    paper_size="A4",
                    color_mode="monochrome",
                    status=JobStatus.UPLOADED if not is_final else JobStatus.PENDING_PAYMENT,
                )
                s.add(job)
            job.user_name = clean_name
            job.user_phone = clean_phone
            job.original_filename = job_filename
            job.source_path = src if source_pages else ""
            job.source_page_count = source_pages
            job.paper_size = "A4"
            job.error_reason = fault
            _apply_quote(job, quote, effective_range, orientation_clean)
            if is_final and job.status == JobStatus.UPLOADED:
                job.status = JobStatus.PENDING_PAYMENT
            job.updated_at = datetime.now(timezone.utc)
            s.commit()
            result = _job_response(job, meta, page_range_error=range_error, warnings=warnings,
                                   upload_id=upload_key, printer_ok=fault is None)

    if is_final:
        await manager.to_kiosk({"event": "new_pending_job", **result})
    return result


@app.get("/api/upload/status/{job_id}")
async def upload_status(job_id: str, upload_id: str = ""):
    """Lets the phone recover from an ambiguous network failure (tunnel 524, dropped
    connection) WITHOUT re-sending the file: did my upload batch actually land?"""
    meta = _read_meta(job_id)
    key = re.sub(r"[^A-Za-z0-9_-]", "", upload_id or "")[:64]
    merged = bool(key) and any(m.get("upload_id") == key for m in meta)
    with get_session() as s:
        job = s.get(PrintJob, job_id)
        if not job:
            return {"merged": False, "job_exists": False, "processing": _job_lock(job_id).locked()}
        return _job_response(job, meta, merged=merged, job_exists=True,
                             processing=_job_lock(job_id).locked())


@app.post("/api/upload/remove-file")
async def remove_file_from_job(
    job_id: str = Form(...),
    file_index: int = Form(...),
    page_range: str = Form(""),
    copies: str = Form("1"),
    duplex: str = Form("false"),
    orientation: str = Form("portrait"),
    pages_per_sheet: str = Form("1"),
    graph_sheets: str = Form("0"),
):
    async with _job_lock(job_id):
        with get_session() as s:
            job = s.get(PrintJob, job_id)
            if not job:
                raise HTTPException(404, "Job not found.")
            if job.status not in EDITABLE_STATES:
                raise HTTPException(409, "This job has already been paid for and can no longer be changed.")

        meta = _read_meta(job_id)
        if file_index < 0 or file_index >= len(meta):
            raise HTTPException(400, "Invalid file index.")
        removed = meta.pop(file_index)
        if removed.get("path") and os.path.exists(removed["path"]):
            try:
                os.remove(removed["path"])
            except OSError:
                pass
        _write_meta(job_id, meta)
        source_pages = await asyncio.to_thread(_rebuild_master, job_id, meta)

        graph_int = _clean_graph(graph_sheets)
        quote, range_error, effective_range = _quote_or_fallback(
            source_pages, page_range, _clean_nup(pages_per_sheet), graph_int,
            _clean_copies(copies), strict=False)

        with get_write_session() as s:
            job = s.get(PrintJob, job_id)
            job.source_page_count = source_pages
            job.source_path = _shm_src(job_id) if source_pages else ""
            if len(meta) == 1:
                job.original_filename = meta[0]["name"]
            elif len(meta) > 1:
                job.original_filename = f"{len(meta)} Merged Files ({source_pages} Pages)"
            else:
                job.original_filename = f"Graph Paper ({graph_int} sheet{'s' if graph_int != 1 else ''})"
            _apply_quote(job, quote, effective_range, _clean_orientation(orientation))
            job.updated_at = datetime.now(timezone.utc)
            s.commit()
            return _job_response(job, meta, cleared=not meta, page_range_error=range_error)


@app.post("/api/job/{job_id}/update-options")
async def update_job_options(
    job_id: str,
    page_range: str = Form(""),
    copies: str = Form("1"),
    duplex: str = Form("false"),
    orientation: str = Form("portrait"),
    pages_per_sheet: str = Form("1"),
    graph_sheets: str = Form("0"),
):
    """Keeps the server's copy of the student's options in sync (kiosk screen, admin, resume
    after reload). Pure bookkeeping — the print file itself is built only after payment."""
    async with _job_lock(job_id):
        with get_write_session() as s:
            job = s.get(PrintJob, job_id)
            if not job:
                raise HTTPException(404, "Job not found.")
            if job.status not in EDITABLE_STATES:
                raise HTTPException(409, "This job has already been paid for and can no longer be changed.")
            quote, range_error, effective_range = _quote_or_fallback(
                job.source_page_count or 0, page_range, _clean_nup(pages_per_sheet),
                _clean_graph(graph_sheets), _clean_copies(copies), strict=False)
            _apply_quote(job, quote, effective_range, _clean_orientation(orientation))
            job.updated_at = datetime.now(timezone.utc)
            s.commit()
            return _job_response(job, _read_meta(job_id), page_range_error=range_error)


# ===========================================================================
# Payment
# ===========================================================================
class CreateOrderRequest(BaseModel):
    job_id: str
    page_range: Optional[str] = None
    selected_pages: Optional[List[int]] = None
    copies: Optional[int] = 1
    color_mode: Optional[str] = "monochrome"
    pages_per_sheet: Optional[int] = 1
    duplex: Optional[bool] = False
    orientation: Optional[str] = "portrait"
    graph_sheets: Optional[int] = 0
    is_graph_only: Optional[bool] = False


class VerifyAndPrintRequest(BaseModel):
    job_id: str
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str
    # Accepted for backwards compatibility but IGNORED: what gets printed is exactly the
    # spec frozen on the job when the (paid) order was created.
    selected_pages: Optional[List[int]] = None
    copies: Optional[int] = 1
    pages_per_sheet: Optional[int] = 1
    duplex: Optional[bool] = False
    orientation: Optional[str] = "portrait"
    graph_sheets: Optional[int] = 0
    is_graph_only: Optional[bool] = False


class ReportPrintFailureRequest(BaseModel):
    job_id: str
    razorpay_payment_id: Optional[str] = None
    reason: Optional[str] = "Customer reported paper jam or missing sheets"


def _payment_payload(job: PrintJob, status: str, message: str, **extra) -> dict:
    amount_paise = job.amount_paise or int(round((job.total_price or 0.0) * 100))
    out = {
        "status": status,
        "job_id": job.id,
        "payment_id": job.razorpay_payment_id or job.payment_ref,
        "amount_rupees": amount_paise / 100.0,
        "sheets_total": job.sheets_total,
        "message": message,
    }
    out.update(extra)
    return out


@app.post("/api/payment/create-order")
async def create_razorpay_order(req: CreateOrderRequest):
    """
    STAGE 1 & 2: Pre-Payment Hardware Gatekeeper & Razorpay Order Creation.
    NEVER creates an order if the printer is offline, lid open, paper jam, or toner missing.
    The amount is computed HERE (compute_quote) and the exact print spec is frozen on the
    job, so what the student pays for is precisely what verify-and-print will print.
    """
    # 1. Hardware Gatekeeper
    try:
        hw = hardware_monitor.get_printer_status()
    except Exception as e:
        hw = {"is_ready": False, "message": f"Hardware monitor error: {e}"}

    if not hw.get("is_ready", False):
        if hw.get("status") == "BOOTING":
            raise HTTPException(
                status_code=503,
                detail="Printer is initializing. Please wait a few seconds and try again."
            )
        fault_msg = hw.get("message") or "Hardware Fault"
        raise HTTPException(
            status_code=400,
            detail=f"Printer not ready: {fault_msg}. Payment blocked for your safety."
        )

    job_id = req.job_id
    async with _job_lock(job_id):
        with get_session() as s:
            job = s.get(PrintJob, job_id)
            if not job:
                raise HTTPException(404, "Job not found. Please upload your file again.")
            status = job.status
            source_pages = job.source_page_count or 0
            src_path = job.source_path
        if status in PRINT_ACTIVE_STATES or status == JobStatus.COMPLETED:
            raise HTTPException(409, "This job has already been paid for.")
        if status not in EDITABLE_STATES:
            raise HTTPException(410, "This upload has expired. Please upload your file again.")
        if source_pages > 0 and not (src_path and os.path.exists(src_path)):
            raise HTTPException(410, "Your uploaded file has expired. Please upload it again.")

        # 2. Server-side bill (the same formula the phone shows)
        nup = _clean_nup(req.pages_per_sheet)
        orientation = _clean_orientation(req.orientation)
        copies = _clean_copies(req.copies)
        graph = _clean_graph(req.graph_sheets)
        page_range = (req.page_range or "").strip() if source_pages > 0 else ""
        try:
            quote = compute_quote(source_pages, page_range, nup, graph, copies)
        except PageRangeError as e:
            raise HTTPException(400, str(e))
        if quote["sheets_total"] <= 0:
            raise HTTPException(400, "No document pages or graph sheets selected to print.")
        if req.selected_pages and sorted(set(req.selected_pages)) != quote["selected"]:
            print(f"[create-order] client page list differs from server parse for {job_id}; server wins")

        amount_paise = quote["amount_paise"]

        # 3. Create the Razorpay order (blocking HTTP call -> worker thread)
        if config.PAYMENT_DISABLED:
            order_id = f"test_order_{uuid.uuid4().hex[:14]}"
        else:
            razorpay_client = payments.get_razorpay_client()
            try:
                order = await asyncio.to_thread(razorpay_client.order.create, {
                    "amount": amount_paise,
                    "currency": "INR",
                    "receipt": f"hyprint_{job_id[:12]}",
                    "notes": {
                        "job_id": job_id,
                        "doc_pages": str(quote["pages_selected"]),
                        "doc_sheets": str(quote["doc_sheets"]),
                        "graph_sheets": str(graph),
                        "nup": str(nup),
                        "orientation": orientation,
                        "sheets": str(quote["sheets_total"]),
                        "copies": str(copies),
                        "page_range": page_range[:200],
                    }
                })
            except Exception as e:
                print(f"[razorpay] order creation failed: {e}")
                raise HTTPException(502, f"Could not create payment order: {e}")
            order_id = order.get("id")
            if not order_id:
                raise HTTPException(502, "Payment gateway did not return an order id.")

        # 4. Freeze the exact print spec on the job
        with get_write_session() as s:
            job = s.get(PrintJob, job_id)
            if job is None or job.status not in EDITABLE_STATES:
                raise HTTPException(409, "This job changed while creating the order. Please try again.")
            _apply_quote(job, quote, page_range, orientation)
            job.razorpay_order_id = order_id
            job.payment_order_id = order_id
            job.amount_paise = amount_paise
            job.total_price = quote["amount_rupees"]
            job.error_reason = None
            job.status = JobStatus.ORDER_CREATED
            if config.PAYMENT_DISABLED:
                # Test mode: no gateway — go straight to the printer with the frozen spec.
                job.status = JobStatus.PAID_PRINTING
                job.payment_ref = f"test_bypass_{uuid.uuid4().hex[:12]}"
                job.paid_at = datetime.now(timezone.utc)
            job.updated_at = datetime.now(timezone.utc)
            s.commit()

    response = {
        "order_id": order_id,
        "amount_paise": amount_paise,
        "amount_rupees": quote["amount_rupees"],
        "key_id": config.RAZORPAY_KEY_ID,
        "job_id": job_id,
        "pages_to_print": quote["pages_selected"],
        "doc_sheets": quote["doc_sheets"],
        "graph_sheets": graph,
        "sheets_per_copy": quote["sheets_per_copy"],
        "sheets_to_print": quote["sheets_total"],
        "copies": copies,
        "nup": nup,
        "orientation": orientation,
        "duplex": False,
        "payment_disabled": config.PAYMENT_DISABLED,
    }
    if config.PAYMENT_DISABLED:
        response["status"] = "PRINTING"
        await broadcast_job(job_id, "Testing mode active — your print is queued.")
        _spawn(_execute_paid_print(job_id))
    return response


@app.post("/api/payment/verify-and-print")
async def verify_payment_and_print(req: VerifyAndPrintRequest):
    """
    STAGE 3 → 5, answered in well under a second:
      1. Cryptographically verify the Razorpay signature (HMAC-SHA256).
      2. Confirm the payment is for THIS job's current order (a signature for some other,
         cheaper order can never unlock this job's print spec).
      3. Idempotent compare-and-swap ORDER_CREATED -> PAID_PRINTING.
      4. Hand the job to the background print queue and return "PRINTING" immediately.
    Printing itself (bundle build -> SumatraPDF -> hardware watchdog -> COMPLETED or
    automatic refund) runs in _execute_paid_print and streams progress to the phone over
    the job WebSocket / GET /api/job/{id}. The old version printed inside this request,
    which ran past the Cloudflare tunnel's 100 s limit and left phones stuck on "Printing".
    """
    job_id = req.job_id
    razorpay_client = payments.get_razorpay_client()

    try:
        await asyncio.to_thread(razorpay_client.utility.verify_payment_signature, {
            "razorpay_order_id": req.razorpay_order_id,
            "razorpay_payment_id": req.razorpay_payment_id,
            "razorpay_signature": req.razorpay_signature
        })
    except Exception as e:
        print(f"[payment] Signature verification failed: {e}")
        raise HTTPException(status_code=400, detail="Invalid payment signature")

    with get_session() as s:
        job = s.get(PrintJob, job_id)
        if job is not None:
            status = job.status
            expected_order = job.razorpay_order_id or job.payment_order_id
            same_payment = (job.razorpay_payment_id or job.payment_ref) == req.razorpay_payment_id
            if status == JobStatus.COMPLETED:
                return _payment_payload(job, "COMPLETED", "Payment verified and document printed successfully!")
            if status in REFUNDED_STATES:
                return _payment_payload(
                    job, "REFUNDED", "Print aborted due to printer error. 100% Instant Refund initiated!",
                    refund_id=job.razorpay_refund_id or job.refund_ref,
                    error_reason=job.error_message or job.error_reason or "Hardware fault encountered")
            if status in PRINT_ACTIVE_STATES and same_payment:
                return _payment_payload(job, "PRINTING", "Payment verified! Document is being printed.")

    # A genuine payment that does not match this job's live order (settings changed in
    # another tab, job expired, unknown job...) must never print an unpaid spec and must
    # never keep the student's money: refund it in full.
    if job is None or status != JobStatus.ORDER_CREATED or expected_order != req.razorpay_order_id:
        reason = ("Your print settings changed (or the upload expired) after this payment started, "
                  "so the payment was refunded in full. Please review and pay again.")
        refund_id, err = await _refund_payment_full(req.razorpay_payment_id, None, job_id, reason)
        print(f"[payment] order mismatch for job {job_id}: refund {refund_id or err}")
        return {
            "status": "REFUNDED",
            "job_id": job_id,
            "payment_id": req.razorpay_payment_id,
            "refund_id": refund_id or "refund_pending_contact_staff",
            "amount_rupees": None,
            "error_reason": reason if not err else reason + " (Refund needs staff attention.)",
            "message": "Payment refunded in full.",
        }

    try:
        with get_write_session() as s:
            moved = atomic_transition(
                s, job_id, {JobStatus.ORDER_CREATED}, JobStatus.PAID_PRINTING,
                razorpay_payment_id=req.razorpay_payment_id,
                payment_ref=req.razorpay_payment_id,
                paid_at=datetime.now(timezone.utc),
                error_reason=None,
            )
            s.commit()
    except Exception as e:
        if "UNIQUE" not in str(e).upper():
            raise
        moved = False

    with get_session() as s:
        job = s.get(PrintJob, job_id)
        if not moved:
            # A concurrent retry of this same verification won the race.
            return _payment_payload(job, "PRINTING", "Payment verified! Document is being printed.")
        payload = _payment_payload(job, "PRINTING", "Payment verified! Your document is printing now.")

    await broadcast_job(job_id, "Payment verified! Sending to the HP LaserJet...")
    _spawn(_execute_paid_print(job_id))
    return payload


@app.post("/api/payment/report-print-failure")
async def report_print_failure(req: ReportPrintFailureRequest, request: Request):
    """
    CUSTOMER DISPUTE FAIL-SAFE:
    If a student paid and did not receive their sheets (e.g., paper ran out without driver flagging,
    or physical jam), this endpoint triggers Nuclear Spooler Reset and issues an instant 100% refund.
    Allowed within 10 minutes of print initiation.
    Staff-only (kiosk PC or admin token): left public, anyone could print and then
    refund themselves.
    """
    require_local(request)
    job_id = req.job_id
    with get_session() as s:
        job = s.get(PrintJob, job_id)
        if not job:
            raise HTTPException(404, "Job not found.")
        payment_id = req.razorpay_payment_id or job.razorpay_payment_id or job.payment_ref
        if not payment_id:
            raise HTTPException(400, "No payment record found for this job.")
        if job.status in (JobStatus.REFUNDED, JobStatus.ABORTED_REFUNDED):
            return {
                "status": "ALREADY_REFUNDED",
                "refund_id": job.razorpay_refund_id or job.refund_ref,
                "amount_rupees": job.refund_amount or (job.amount_paise or 0) / 100.0,
                "message": "Refund was already issued for this job."
            }
        amount_paise = job.amount_paise or int(round(job.total_price * 100))
        now = datetime.now(timezone.utc)
        job_time = job.paid_at or job.created_at
        if job_time:
            if job_time.tzinfo is None:
                job_time = job_time.replace(tzinfo=timezone.utc)
            if (now - job_time).total_seconds() > 600:
                raise HTTPException(400, "Dispute window expired (10 minutes limit). Please contact administrator.")

    # 1. Reset spooler immediately to prevent ghost prints
    try:
        await asyncio.to_thread(cups_manager.nuclear_spooler_reset)
    except Exception as e:
        print(f"[report-print-failure] nuclear spooler reset error: {e}")

    # 2. Issue Razorpay refund
    razorpay_client = payments.get_razorpay_client()
    refund_id = None
    reason_str = req.reason or "Customer reported print failure or missing sheets"
    try:
        refund = razorpay_client.payment.refund(payment_id, {
            "amount": amount_paise,
            "notes": {"job_id": job_id, "reason": reason_str[:200]}
        })
        refund_id = refund.get("id")
    except Exception as e1:
        print(f"[report-print-failure] Refund with notes failed: {e1}; trying raw...")
        try:
            refund = razorpay_client.payment.refund(payment_id, {"amount": amount_paise})
            refund_id = refund.get("id")
        except Exception as e2:
            print(f"[report-print-failure] Raw refund failed: {e2}")
            refund_id = f"rfnd_dispute_{job_id[:8]}"

    with get_write_session() as s:
        job = s.get(PrintJob, job_id)
        if job:
            job.status = JobStatus.REFUNDED
            job.razorpay_refund_id = refund_id
            job.refund_ref = refund_id
            job.refund_amount = float(amount_paise / 100.0)
            job.error_message = reason_str
            job.error_reason = reason_str
            s.commit()

    await broadcast_job(job_id, f"Dispute refund processed: {reason_str} ({refund_id})")

    return {
        "status": "REFUNDED",
        "job_id": job_id,
        "payment_id": payment_id,
        "refund_id": refund_id,
        "amount_rupees": amount_paise / 100.0,
        "message": "100% Refund processed successfully. You will receive funds in your account."
    }


@app.post("/api/admin/refund/{job_id}")
@app.post("/api/admin/override/refund/{job_id}")
async def admin_manual_refund(job_id: str, request: Request):
    """Admin manual override refund button."""
    require_local(request)
    with get_session() as s:
        job = s.get(PrintJob, job_id)
        if not job:
            raise HTTPException(404, "Job not found")
        payment_id = job.razorpay_payment_id or job.payment_ref
        if not payment_id:
            raise HTTPException(400, "Job has no recorded payment ID to refund.")
        amount_paise = job.amount_paise or int(round(job.total_price * 100))

    razorpay_client = payments.get_razorpay_client()
    try:
        refund = razorpay_client.payment.refund(payment_id, {
            "amount": amount_paise,
            "speed": "normal",
            "notes": {"job_id": job_id, "reason": "Admin manual refund"}
        })
    except Exception as e:
        raise HTTPException(500, f"Gateway rejected refund: {e}")

    refund_id = refund.get("id") if isinstance(refund, dict) else f"rfnd_{uuid.uuid4().hex[:14]}"
    with get_write_session() as s:
        job = s.get(PrintJob, job_id)
        if job:
            job.status = JobStatus.REFUNDED
            job.razorpay_refund_id = refund_id
            job.refund_ref = refund_id
            job.refund_amount = float(amount_paise / 100.0)
            job.error_message = "Admin issued manual refund"
            s.commit()

    return {
        "ok": True,
        "refund_id": refund_id,
        "refund_ref": refund_id,
        "amount": amount_paise / 100.0,
        "message": f"Successfully refunded ₹{amount_paise / 100.0} (ID: {refund_id})"
    }


@app.post("/api/payment/create/{job_id}")
def create_payment(job_id: str):
    with get_session() as s:
        job = s.get(PrintJob, job_id)
        if not job:
            raise HTTPException(404, "Job not found.")
        if job.status == JobStatus.PREFLIGHT_BLOCKED:
            raise HTTPException(409, "Printer has a hardware fault — payment is blocked.")
        if job.status != JobStatus.PENDING_PAYMENT and job.status != JobStatus.ORDER_CREATED:
            raise HTTPException(409, f"This job is not awaiting payment (status: {job.status.value}).")
        amount = job.total_price

    # Strict hardware check: reject if printer is under maintenance or not ready
    try:
        hw = hardware_monitor.get_printer_status()
        if not hw.get("is_ready", True) or hw.get("status") == "MAINTENANCE":
            fault = hw.get("message") or "System Under Maintenance"
            with get_write_session() as s:
                atomic_transition(s, job_id, {JobStatus.PENDING_PAYMENT},
                                  JobStatus.PREFLIGHT_BLOCKED, error_reason=fault)
                s.commit()
            raise HTTPException(503, f"System Under Maintenance: {fault}")
    except HTTPException:
        raise
    except Exception:
        pass

    # Re-check hardware at the last moment — it may have failed since upload.
    try:
        hw_now = hardware_monitor.get_printer_status()
        fault = None if hw_now.get("is_ready", False) else (hw_now.get("message") or "printer-unreachable")
    except Exception:
        fault = "printer-unreachable"
    if fault:
        with get_write_session() as s:
            atomic_transition(s, job_id, {JobStatus.PENDING_PAYMENT},
                              JobStatus.PREFLIGHT_BLOCKED, error_reason=fault)
            s.commit()
        raise HTTPException(503, f"System Under Maintenance: {fault}")

    order_id = f"order_{uuid.uuid4().hex[:16]}"
    with get_write_session() as s:
        job = s.get(PrintJob, job_id)
        job.payment_order_id = order_id
        s.commit()

    upi_uri = (f"upi://pay?pa={config.UPI_VPA}&pn=CampusPrintKiosk"
               f"&am={amount:.2f}&cu=INR&tn=Print-{job_id[:8]}")
    buf = io.BytesIO()
    qrcode.make(upi_uri).save(buf, format="PNG")

    return {
        "job_id": job_id,
        "order_id": order_id,
        "amount": amount,
        "currency": "INR",
        "upi_uri": upi_uri,
        "qr_code_base64": "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode(),
    }


@app.post("/api/payment/webhook")
async def payment_webhook(request: Request):
    """
    Gateway → kiosk payment confirmation.

    Publicly reachable, so it is signature-gated (see payments.verify_webhook).
    Idempotent by construction: the PENDING_PAYMENT→PAID compare-and-swap can
    only succeed once, so duplicate deliveries never double-print.
    """
    raw = await request.body()
    try:
        payments.verify_webhook(
            raw,
            request.headers.get("x-webhook-signature"),
            request.headers.get("x-webhook-timestamp"),
        )
    except payments.WebhookError as e:
        # Deliberately vague to the caller; detail goes to the local log only.
        print(f"[webhook] rejected: {e}")
        raise HTTPException(401, "Invalid signature.")

    try:
        body = await request.json()
    except Exception:
        raise HTTPException(400, "Malformed JSON.")

    job_id = body.get("job_id")
    payment_ref = body.get("payment_ref")
    if not job_id or not payment_ref:
        raise HTTPException(400, "job_id and payment_ref are required.")
    if body.get("status", "captured") != "captured":
        return {"ok": True, "ignored": True}


    try:
        with get_write_session() as s:
            moved = atomic_transition(
                s, job_id, {JobStatus.PENDING_PAYMENT, JobStatus.ORDER_CREATED}, JobStatus.PAID_PRINTING,
                payment_ref=payment_ref,
                paid_at=datetime.now(timezone.utc),
            )
            s.commit()
    except Exception as e:
        # UNIQUE violation on payment_ref = this payment was already applied.
        if "UNIQUE" in str(e).upper():
            return {"ok": True, "already_processed": True}
        raise

    if not moved:
        return {"ok": True, "already_processed": True}

    await broadcast_job(job_id, "Payment received. Sending to the printer...")
    _spawn(_execute_paid_print(job_id))
    return {"ok": True, "paid": True}


@app.post("/api/release")
async def release_job_by_pin(request: Request):
    """Removed. HYPRINT is instant automated printing: pay on the phone -> it prints.
    There is no release PIN anywhere in the flow. (The old endpoint also let anyone who
    knew a job id print it for free.)"""
    raise HTTPException(410, "Release PINs are no longer used — paid jobs print automatically.")


@app.get("/api/kiosk/job/{job_id}/pdf")
async def kiosk_get_pdf(job_id: str, request: Request):
    """Serve the PDF being printed — kiosk PC only (student documents are private)."""
    require_local(request)
    with get_session() as s:
        job = s.get(PrintJob, job_id)
        if not job or job.status not in PRINT_ACTIVE_STATES:
            raise HTTPException(404, "Not available")
        if not job.print_path or not os.path.exists(job.print_path):
            raise HTTPException(404, "File missing")
    return FileResponse(job.print_path, media_type="application/pdf")


# ===========================================================================
# Print dispatch + watchdog
# ===========================================================================
async def run_print_job(job_id: str):
    """Legacy entry point (kept for scripts): print a job that is already PAID."""
    with get_write_session() as s:
        moved = atomic_transition(s, job_id, {JobStatus.PAID}, JobStatus.PAID_PRINTING)
        s.commit()
    if moved:
        await _execute_paid_print(job_id)


async def _execute_paid_print(job_id: str):
    """
    The ONE print pipeline, for every paid job (Razorpay, webhook, test mode):
      PAID_PRINTING --(printer free)--> build bundle --> PRINTING --> SumatraPDF + watchdog
                    --> COMPLETED, or REFUNDED (100%) on any fault.
    Jobs are printed strictly one at a time (_printer_lock).
    """
    try:
        if _printer_lock.locked():
            await broadcast_job(job_id, "Payment verified! Waiting for the printer — another student's job is finishing...")
        async with _printer_lock:
            await _print_locked(job_id)
    except Exception as e:
        # Last-resort safety net: a paid job must never be left hanging.
        print(f"[print] unexpected error for {job_id}: {e}")
        await _refund_paid_job(job_id, f"Internal print error: {e}")


async def _print_locked(job_id: str):
    with get_session() as s:
        job = s.get(PrintJob, job_id)
        if not job or job.status != JobStatus.PAID_PRINTING:
            return
        source_path = job.source_path
        source_pages = job.source_page_count or 0
        page_range = job.page_range or ""
        nup = _clean_nup(job.pages_per_sheet)
        orientation = _clean_orientation(job.orientation)
        graph = _clean_graph(job.graph_sheets)
        copies = _clean_copies(job.copies)

    # 1. Re-derive the frozen spec and build the exact bundle the student previewed.
    try:
        quote = compute_quote(source_pages, page_range, nup, graph, copies)
    except PageRangeError as e:
        await _refund_paid_job(job_id, f"Saved page range is invalid: {e}")
        return

    doc_source = None
    if source_pages > 0:
        master = os.path.join(_upload_dir(job_id), "master_print.pdf")
        for cand in (source_path, master):
            if cand and os.path.exists(cand):
                doc_source = cand
                break
        if doc_source is None:
            await _refund_paid_job(job_id, "The uploaded document is no longer available on the kiosk.")
            return

    os.makedirs(_upload_dir(job_id), exist_ok=True)
    bundle_pdf = os.path.join(_upload_dir(job_id), "print_bundle.pdf")
    try:
        doc_sheets, sheets_per_copy, bundle_pdf = await asyncio.to_thread(
            file_processor.build_print_bundle,
            doc_src_path=doc_source,
            dest_path=bundle_pdf,
            selected_pages=quote["selected"] or None,
            nup=nup,
            orientation=orientation,
            graph_sheets=graph,
        )
    except Exception as bundle_err:
        await _refund_paid_job(job_id, f"Could not prepare the document for printing: {bundle_err}")
        return

    if sheets_per_copy != quote["sheets_per_copy"]:
        # Should be impossible; never print something that differs from what was paid for.
        await _refund_paid_job(job_id, f"Sheet count mismatch ({sheets_per_copy} vs {quote['sheets_per_copy']} paid).")
        return

    sheets_total = sheets_per_copy * copies
    with get_write_session() as s:
        atomic_transition(s, job_id, {JobStatus.PAID_PRINTING}, JobStatus.PRINTING,
                          print_path=bundle_pdf, doc_sheets=doc_sheets, sheets_total=sheets_total,
                          sheets_printed=0, duplex=False)
        s.commit()
    await broadcast_job(job_id, f"Printing {sheets_total} sheet(s) on the HP LaserJet...")

    # 2. Spool + hardware watchdog (blocking Win32/Sumatra calls -> worker thread).
    print_opts = {
        "copies": copies,
        "sheets_total": sheets_total,
        "duplex": False,
        # Orientation is already baked into each sheet of the bundle; "auto" lets the
        # engine rotate landscape sheets onto the A4 paper path without touching portrait
        # graph sheets.
        "orientation": "auto",
    }
    progress_task = _spawn(_progress_ticker(job_id, sheets_total))
    try:
        ok, error_reason = await asyncio.to_thread(
            cups_manager.print_file_with_watchdog, bundle_pdf, print_opts, job_id)
    except Exception as exc:
        ok, error_reason = False, f"Print execution exception: {exc}"
    finally:
        progress_task.cancel()

    if not ok:
        await _refund_paid_job(job_id, error_reason or "Printer Hardware Error / Paper Jam / Cover Open",
                               spooler_already_reset=True)
        return

    # 3. Success
    with get_write_session() as s:
        atomic_transition(s, job_id, {JobStatus.PRINTING}, JobStatus.COMPLETED,
                          sheets_printed=sheets_total, error_reason=None)
        s.commit()
    try:
        database.deduct_printed_pages(sheets_total)
    except Exception as e:
        print(f"[print] paper counter update failed: {e}")
    await broadcast_job(job_id, "Print complete — please collect your document.")


async def _progress_ticker(job_id: str, sheets_total: int):
    """Estimated live progress for the phone and kiosk while the watchdog runs
    (HP P1108: ~8 s to first page, then ~3.3 s per A4 sheet at 18 ppm)."""
    started = time.time()
    try:
        while True:
            await asyncio.sleep(2.0)
            elapsed = time.time() - started
            done = 0 if elapsed < 8.0 else min(sheets_total, 1 + int((elapsed - 8.0) / 3.4))
            with get_write_session() as s:
                job = s.get(PrintJob, job_id)
                if not job or job.status != JobStatus.PRINTING:
                    return
                job.sheets_printed = min(done, max(0, sheets_total - 1))  # final sheet confirmed by watchdog
                s.commit()
            await broadcast_job(job_id, f"Printing… about {min(done, sheets_total)} of {sheets_total} sheet(s) out.")
    except asyncio.CancelledError:
        pass


async def _refund_paid_job(job_id: str, reason: str, spooler_already_reset: bool = False):
    """Print failed after payment: purge the spooler so nothing prints late, refund 100%."""
    print(f"[payment] Print failed for {job_id}: {reason}. Resetting spooler & refunding...")
    if not spooler_already_reset:
        try:
            await asyncio.to_thread(cups_manager.nuclear_spooler_reset)
        except Exception as reset_err:
            print(f"[payment] nuclear spooler reset warning: {reset_err}")

    with get_session() as s:
        job = s.get(PrintJob, job_id)
        if not job or job.status in TERMINAL_STATES:
            return
        payment_id = job.razorpay_payment_id or job.payment_ref
        amount_paise = job.amount_paise or int(round((job.total_price or 0.0) * 100))

    refund_id, refund_err = None, None
    if payment_id and not str(payment_id).startswith("test_bypass_"):
        refund_id, refund_err = await _refund_payment_full(payment_id, amount_paise, job_id, reason)

    with get_write_session() as s:
        job = s.get(PrintJob, job_id)
        if job and job.status not in TERMINAL_STATES:
            job.status = JobStatus.REFUNDED if not refund_err else JobStatus.FAILED
            job.razorpay_refund_id = refund_id
            job.refund_ref = refund_id
            job.refund_amount = float(amount_paise / 100.0)
            job.refund_error = refund_err
            job.error_message = reason
            job.error_reason = reason
            job.updated_at = datetime.now(timezone.utc)
            s.commit()

    if refund_err:
        await broadcast_job(job_id, f"Print aborted: {reason}. Automatic refund could not be completed — please contact kiosk staff.")
    else:
        await broadcast_job(job_id, f"Print aborted: {reason}. 100% Instant Refund initiated ({refund_id or 'test mode'}).")


async def fail_and_refund(job_id: str, reason: str, sheets_done: int | None = None,
                          from_states: set | None = None):
    """
    Refund the UNPRINTED portion and close the job out.

    Ordering matters: we call the gateway BEFORE writing ABORTED_REFUNDED, so
    a gateway failure is recorded as refund_error on the row instead of being
    silently swallowed behind a status that claims the money went back.
    """
    allowed = from_states or PRINT_ACTIVE_STATES
    with get_session() as s:
        job = s.get(PrintJob, job_id)
        if not job or job.status in TERMINAL_STATES:
            return
        printed = sheets_done if sheets_done is not None else job.sheets_printed
        sheets_total = max(1, job.sheets_total)
        unprinted_fraction = max(0.0, (sheets_total - printed) / sheets_total)
        total_paise = job.amount_paise or int(round((job.total_price or 0.0) * 100))
        refund_paise = int(round(total_paise * unprinted_fraction))
        payment_ref = job.razorpay_payment_id or job.payment_ref

    refund_ref, refund_error = None, None
    if refund_paise > 0 and payment_ref and not str(payment_ref).startswith("test_bypass_"):
        refund_ref, refund_error = await _refund_payment_full(payment_ref, refund_paise, job_id, reason)
    refund_amount = refund_paise / 100.0

    with get_write_session() as s:
        atomic_transition(
            s, job_id,
            allowed,
            JobStatus.ABORTED_REFUNDED if refund_error is None else JobStatus.FAILED,
            error_reason=reason,
            refund_amount=refund_amount,
            refund_ref=refund_ref,
            razorpay_refund_id=refund_ref,
            refund_error=refund_error,
        )
        s.commit()

    if refund_error:
        msg = f"❌ {reason} Refund of ₹{refund_amount:.2f} could NOT be completed automatically — please see kiosk staff."
        print(f"[refund] FAILED for job {job_id}: {refund_error}")
    else:
        msg = f"❌ {reason} ₹{refund_amount:.2f} has been refunded to your UPI account."

    await broadcast_job(job_id, msg)


def _purge_job_files(job_id: str):
    """Files of finished jobs are destroyed by the scavenger FINISHED_JOB_FILE_TTL_SECONDS
    after the job ends (on every OS), giving the Windows spooler time to finish streaming."""
    return


# ===========================================================================
# Status + WebSockets
# ===========================================================================


@app.get("/api/job/{job_id}")
def get_job(job_id: str):
    with get_session() as s:
        job = s.get(PrintJob, job_id)
        if not job:
            raise HTTPException(404, "Job not found.")
        return job.public()


@app.websocket("/ws/print/{job_id}")
async def ws_job(ws: WebSocket, job_id: str):
    await manager.join_job(job_id, ws)
    await broadcast_job(job_id, "Connected.")
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        await manager.leave_job(job_id, ws)


@app.websocket("/ws/status")
async def ws_status(ws: WebSocket):
    """Real-time hardware telemetry websocket stream."""
    await manager.join_status(ws)
    try:
        raw_hw = hardware_monitor.get_printer_status()
        raw_hw["paper_inventory"] = database.get_paper_tray_status()
        await ws.send_json(raw_hw)
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        await manager.leave_status(ws)


@app.websocket("/ws/kiosk")
async def ws_kiosk(ws: WebSocket):
    """Kiosk-screen real-time firehose for instant stage transitions."""
    await manager.join_kiosk(ws)
    try:
        url = f"{config.PUBLIC_BASE_URL}/?kiosk_id={config.KIOSK_ID}"
        buf = io.BytesIO()
        qrcode.make(url).save(buf, format="PNG")
        qr_b64 = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()
        await ws.send_json({"event": "qr_update", "url": url, "qr_code_base64": qr_b64})
    except Exception:
        pass
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        await manager.leave_kiosk(ws)


# ===========================================================================
# Admin (localhost only)
# ===========================================================================
@app.get("/api/admin/stats")
def admin_stats(_: bool = Depends(require_local)):
    now = datetime.now(timezone.utc)
    day_ago = now - timedelta(days=1)
    week_ago = now - timedelta(days=7)

    with get_session() as s:
        def revenue_since(ts):
            total = s.query(func.coalesce(func.sum(PrintJob.total_price), 0.0)).filter(
                PrintJob.status == JobStatus.COMPLETED, PrintJob.paid_at >= ts
            ).scalar() or 0.0
            refunded = s.query(func.coalesce(func.sum(PrintJob.refund_amount), 0.0)).filter(
                PrintJob.refund_amount.isnot(None), PrintJob.paid_at >= ts
            ).scalar() or 0.0
            return round(total - refunded, 2)

        status_counts = dict(
            s.query(PrintJob.status, func.count(PrintJob.id)).group_by(PrintJob.status).all()
        )
        recent = (s.query(PrintJob).order_by(PrintJob.created_at.desc()).limit(50).all())

        sheets_today = s.query(func.coalesce(func.sum(PrintJob.sheets_printed), 0)).filter(
            PrintJob.paid_at >= day_ago
        ).scalar() or 0

        return {
            "kiosk_id": config.KIOSK_ID,
            "revenue_today": revenue_since(day_ago),
            "revenue_week": revenue_since(week_ago),
            "sheets_today": int(sheets_today),
            "status_counts": {
                (k.value if hasattr(k, "value") else str(k)): v for k, v in status_counts.items()
            },
            "needs_attention": [
                j.admin() for j in recent
                if j.status in (JobStatus.FAILED, JobStatus.FAILED_REBOOT)
                or j.refund_error is not None
            ],
            "recent_jobs": [j.admin() for j in recent],
        }


@app.post("/api/admin/override/clear-queue")
async def admin_clear_queue(_: bool = Depends(require_local)):
    """Force-clear the CUPS queue without opening a terminal.

    Also closes out any job rows still marked active, so the kiosk screen
    doesn't keep showing jobs that no longer exist on the printer.
    """
    cleared = await asyncio.to_thread(cups_manager.purge_queue)
    with get_write_session() as s:
        active = s.query(PrintJob).filter(
            PrintJob.status.in_([JobStatus.SPOOLING, JobStatus.PRINTING, JobStatus.PAUSED_ERROR])
        ).all()
        for job in active:
            job.status = JobStatus.FAILED
            job.error_reason = "Queue cleared manually by staff."
            _purge_files(job)
        s.commit()
        affected = len(active)

    await manager.to_kiosk({"event": "queue_cleared", "cups_jobs": cleared, "rows": affected})
    return {"ok": True, "cups_jobs_cancelled": cleared, "job_rows_closed": affected}


@app.post("/api/admin/override/clear-history")
async def admin_clear_history(_: bool = Depends(require_local)):
    """Wipe all job history and temporary files from the admin dashboard."""
    with get_write_session() as s:
        s.query(PrintJob).delete()
        s.commit()

    for root in (config.SHM_DIR, os.path.join(BASE_DIR, "uploads")):
        if not os.path.exists(root):
            continue
        for fname in os.listdir(root):
            fpath = os.path.join(root, fname)
            try:
                if os.path.isdir(fpath):
                    shutil.rmtree(fpath, ignore_errors=True)
                else:
                    os.remove(fpath)
            except Exception:
                pass

    await manager.to_kiosk({"event": "queue_cleared"})
    return {"ok": True, "message": "All print history and storage cleared."}


@app.post("/api/admin/reset-paper")
def admin_reset_paper(sheets: int = Form(150), _: bool = Depends(require_local)):
    res = database.reset_paper_tray(sheets)
    return {"ok": True, "result": res, "paper_inventory": database.get_paper_tray_status()}


@app.get("/api/admin/hardware-logs")
def admin_hardware_logs(limit: int = 50, _: bool = Depends(require_local)):
    with get_session() as s:
        logs = s.query(database.PrinterHardwareLog).order_by(database.PrinterHardwareLog.id.desc()).limit(limit).all()
        return [{
            "id": l.id,
            "timestamp": l.timestamp.isoformat() if l.timestamp else None,
            "printer_status_code": l.printer_status_code,
            "error_state_code": l.error_state_code,
            "status_message": l.status_message,
            "is_blocking": l.is_blocking,
        } for l in logs]


# ===========================================================================
# Debug (simulation mode + localhost only)
# ===========================================================================
@app.post("/api/debug/printer-fault")
def debug_printer_fault(reason: str | None = None, _: bool = Depends(require_local)):
    if not config.SIMULATE:
        raise HTTPException(403, "Only available in simulation mode.")
    cups_manager.simulator().set_printer_fault(reason)
    return {"ok": True, "reason": reason}


@app.post("/api/debug/job-fault/{job_id}")
def debug_job_fault(job_id: str, reason: str | None = "media-jam-error",
                    _: bool = Depends(require_local)):
    if not config.SIMULATE:
        raise HTTPException(403, "Only available in simulation mode.")
    with get_session() as s:
        job = s.get(PrintJob, job_id)
        if not job or job.cups_job_id is None:
            raise HTTPException(404, "Job not dispatched to the printer yet.")
        cups_manager.simulator().set_job_fault(job.cups_job_id, reason)
    return {"ok": True, "reason": reason}


@app.post("/api/debug/simulate-payment/{job_id}")
async def debug_simulate_payment(job_id: str, _: bool = Depends(require_local)):
    """Bypass the gateway in simulation mode so the full flow is testable
    without real money."""
    if not config.SIMULATE:
        raise HTTPException(403, "Only available in simulation mode.")
    with get_write_session() as s:
        moved = atomic_transition(
            s, job_id, {JobStatus.PENDING_PAYMENT, JobStatus.ORDER_CREATED}, JobStatus.PAID_PRINTING,
            payment_ref=f"sim_{uuid.uuid4().hex[:12]}",
            paid_at=datetime.now(timezone.utc),
        )
        s.commit()
    if not moved:
        raise HTTPException(409, "Job is not awaiting payment.")
    await broadcast_job(job_id, "Payment received. Printing now...")
    _spawn(_execute_paid_print(job_id))
    return {"ok": True, "simulated": True}
 
 
@app.post("/api/debug/test-led")
@app.get("/api/debug/test-led")
async def debug_test_led():
    """Trigger the Arduino LED to blink 3 times with 1 sec gap."""
    led_notifier.blink(count=3, gap=1.0)
    return {"ok": True, "message": "LED blink triggered (3 times, 1s gap)"}



# ===========================================================================
# Pages  (primary definitions are at the top of this file; do NOT duplicate)
# ===========================================================================


@app.get("/api/locations")
def list_locations():
    return {
        "current_kiosk_id": config.KIOSK_ID,
        "locations": [
            {
                "kiosk_id": config.KIOSK_ID,
                "name": "Central Library - Ground Floor",
                "campus_area": "Academic Block A, Near Reading Hall",
                "type": "KIOSK",
                "is_online": True,
                "schedule": "Open 24/7",
                "is_open": True,
                "latitude": 13.0827,
                "longitude": 80.2707,
                "distance_default_meters": 45,
                "printer_model": cups_manager.get_active_printer_name(),
                "paper_status": "Paper ready (98%)",
                "pricing": {
                    # HP LaserJet Pro P1108: monochrome, simplex-only. One flat price per sheet.
                    "bw_simplex": config.PRICE_PER_PAGE,
                    "bw_duplex": None,
                    "color_simplex": None,
                    "color_duplex": None,
                    "blank_sheet": config.PRICE_PER_PAGE,
                },
                "capabilities": {
                    "black_and_white": True,
                    "color": False,
                    "duplex": False,
                    "blank_sheets": True,
                },
                "max_copies": config.MAX_COPIES,
            },
            {
                "kiosk_id": "0002",
                "name": "Engineering Block B - North Lobby",
                "campus_area": "Opposite Computer Labs, 1st Floor",
                "type": "KIOSK",
                "is_online": True,
                "schedule": "Open 07:00 AM - 11:00 PM",
                "is_open": True,
                "latitude": 13.0838,
                "longitude": 80.2721,
                "distance_default_meters": 130,
                "printer_model": "HP LaserJet Pro MFP",
                "paper_status": "Paper ready (85%)",
                "pricing": {
                    "bw_simplex": 2.0,
                    "bw_duplex": 3.0,
                    "color_simplex": 7.0,
                    "color_duplex": 12.0,
                    "blank_sheet": 1.0,
                },
                "capabilities": {
                    "black_and_white": True,
                    "color": True,
                    "duplex": True,
                    "blank_sheets": True,
                },
            },
            {
                "kiosk_id": "0003",
                "name": "Student Activity Center (SAC)",
                "campus_area": "Food Court & Student Lounge Entry",
                "type": "KIOSK",
                "is_online": True,
                "schedule": "Open 24/7",
                "is_open": True,
                "latitude": 13.0812,
                "longitude": 80.2690,
                "distance_default_meters": 260,
                "printer_model": "HP_LaserJet_P1108_Plus",
                "paper_status": "Paper ready (92%)",
                "pricing": {
                    "bw_simplex": 2.0,
                    "bw_duplex": 3.0,
                    "color_simplex": 8.0,
                    "color_duplex": 14.0,
                    "blank_sheet": 1.0,
                },
                "capabilities": {
                    "black_and_white": True,
                    "color": False,
                    "duplex": True,
                    "blank_sheets": True,
                },
            },
            {
                "kiosk_id": "SHOP01",
                "name": "Campus Stationery & Reprographics",
                "campus_area": "Commercial Complex, Shop #4",
                "type": "SHOP",
                "is_online": True,
                "schedule": "Open 08:30 AM - 08:30 PM",
                "is_open": True,
                "latitude": 13.0845,
                "longitude": 80.2685,
                "distance_default_meters": 350,
                "printer_model": "Commercial Canon ImageRunner",
                "paper_status": "Full Services",
                "pricing": {
                    "bw_simplex": 2.0,
                    "bw_duplex": 3.0,
                    "color_simplex": 6.0,
                    "color_duplex": 10.0,
                    "blank_sheet": 1.0,
                },
                "capabilities": {
                    "black_and_white": True,
                    "color": True,
                    "duplex": True,
                    "blank_sheets": True,
                    "spiral_binding": True,
                    "lamination": True,
                },
            },
        ],
    }


@app.get("/admin")
@app.get("/api/admin")
@app.get("/admin.html")
def admin_page(_: bool = Depends(require_local)):
    return _serve_html("admin.html")


@app.get("/kiosk")
@app.get("/api/kiosk")
@app.get("/kiosk.html")
def kiosk_page():
    """The physical kiosk touchscreen."""
    return _serve_html("kiosk.html")




_preview_cache: dict[str, bytes] = {}

def _render_pdf_thumbnail(pdf_path: str, page_num: int) -> bytes:
    cache_key = f"{pdf_path}:{os.path.getmtime(pdf_path)}:{page_num}"
    if cache_key in _preview_cache:
        return _preview_cache[cache_key]
    doc = pymupdf.open(pdf_path)
    try:
        page_idx = max(0, min(page_num - 1, len(doc) - 1))
        p = doc.load_page(page_idx)
        pix = p.get_pixmap(dpi=96)
        img_data = pix.tobytes("jpeg")
        if len(_preview_cache) > 200:
            _preview_cache.clear()
        _preview_cache[cache_key] = img_data
        return img_data
    finally:
        doc.close()

_preview_build_locks: dict[str, asyncio.Lock] = {}


def _prune_preview_bundles(u_dir: str, keep: int = 12):
    """Students flick through settings; keep only the most recent preview bundles."""
    try:
        bundles = sorted(
            (os.path.join(u_dir, f) for f in os.listdir(u_dir) if f.startswith("preview_bundle_")),
            key=os.path.getmtime, reverse=True)
    except OSError:
        return
    for old in bundles[keep:]:
        tag = os.path.basename(old)[len("preview_bundle_"):-len(".pdf")]
        try:
            os.remove(old)
            prev_dir = os.path.join(u_dir, "previews")
            for f in os.listdir(prev_dir):
                if f.startswith(f"sheet_{tag}_"):
                    os.remove(os.path.join(prev_dir, f))
        except OSError:
            pass


@app.get("/api/preview/{job_id}")
@app.get("/api/preview/{job_id}/{page}")
async def get_job_preview(
    job_id: str,
    page: int = 1,
    layout: int = 1,
    orientation: str = "portrait",
    page_range: str = "",
    graph_sheets: int = 0,
    target: str = "print",
    size: str = "full",
    t: str = None,
    v: str = None
):
    """
    On-demand WYSIWYG physical-sheet preview (1-based `page` = physical sheet index of ONE copy).

    It renders from the very same build_print_bundle() used for printing, with the same
    layout (N-up), orientation, page range and graph-paper count, so each PNG is exactly
    the sheet that will come out of the printer: portrait sheets render 1075x1521 px and
    landscape sheets 1521x1075 px (A4 at 130 dpi) — the phone sizes its cards from that.

    job_id "graph_only" renders graph paper without any uploaded document.
    target=print on a job that is printing renders its actual print bundle (kiosk screen).
    """
    if not re.match(r"^[A-Za-z0-9_-]{1,64}$", job_id):
        raise HTTPException(400, "Invalid job id.")
    nup = layout if layout in file_processor.VALID_NUP else 1
    orient = _clean_orientation(orientation)
    g_count = _clean_graph(graph_sheets)
    clean_range = (page_range or "").strip().replace(" ", "")
    sheet_idx = max(1, page)

    # 1. Locate the document (if any)
    pdf_path = None
    job_print_bundle = None
    if job_id != "graph_only":
        with get_session() as s:
            job = s.get(PrintJob, job_id)
            if job:
                if (target == "print" and job.status in (PRINT_ACTIVE_STATES | {JobStatus.COMPLETED})
                        and job.print_path and os.path.basename(job.print_path) == "print_bundle.pdf"
                        and os.path.exists(job.print_path)):
                    job_print_bundle = job.print_path
                if (job.source_page_count or 0) > 0 and job.source_path and os.path.exists(job.source_path):
                    pdf_path = job.source_path
        if not pdf_path:
            cand = os.path.join(_upload_dir(job_id), "master_print.pdf")
            if os.path.exists(cand):
                pdf_path = cand
        if not pdf_path and g_count == 0 and not job_print_bundle:
            raise HTTPException(404, "PDF file not found for preview.")

    u_dir = _upload_dir(job_id if job_id != "graph_only" else "_graph_only")
    prev_dir = os.path.join(u_dir, "previews")
    os.makedirs(prev_dir, exist_ok=True)

    if job_print_bundle:
        target_pdf = job_print_bundle
        cache_tag = f"print_{int(os.path.getmtime(job_print_bundle))}"
    else:
        # 2. Build (or reuse) the preview bundle for exactly these settings
        if pdf_path:
            total_p = file_processor.inspect_pdf_page_count(pdf_path)
            try:
                selected = file_processor.parse_page_range(clean_range, total_p)
            except PageRangeError as e:
                raise HTTPException(400, str(e))
            src_sig = f"{os.path.getsize(pdf_path)}_{int(os.path.getmtime(pdf_path))}"
        else:
            selected, src_sig = [], "none"
            g_count = max(1, g_count)
        cache_tag = hashlib.sha1(
            f"{src_sig}|{nup}|{orient}|{','.join(map(str, selected))}|{g_count}".encode()
        ).hexdigest()[:16]
        target_pdf = os.path.join(u_dir, f"preview_bundle_{cache_tag}.pdf")

        if not os.path.exists(target_pdf):
            lock = _preview_build_locks.setdefault(target_pdf, asyncio.Lock())
            async with lock:
                if not os.path.exists(target_pdf):
                    try:
                        await asyncio.to_thread(
                            file_processor.build_print_bundle,
                            doc_src_path=pdf_path,
                            dest_path=target_pdf,
                            selected_pages=selected or None,
                            nup=nup,
                            orientation=orient,
                            graph_sheets=g_count,
                        )
                    except Exception as b_err:
                        print(f"[preview] Error building preview bundle: {b_err}")
                        raise HTTPException(500, f"Preview build error: {b_err}")
            _preview_build_locks.pop(target_pdf, None)
            _prune_preview_bundles(u_dir, keep=12)

    # 3. Render the requested physical sheet.
    #    Grayscale JPEGs: exactly what the monochrome laser prints, and small enough to load
    #    instantly over the tunnel on mobile data.
    #    size=thumb -> 56 dpi (carousel cards)   size=full -> 110 dpi (fullscreen, kiosk screen)
    if size == "thumb":
        cached_img_path = os.path.join(prev_dir, f"sheet_{cache_tag}_{sheet_idx}_t.jpg")
        dpi, quality = 56, 70
    else:
        cached_img_path = os.path.join(prev_dir, f"sheet_{cache_tag}_{sheet_idx}_f.jpg")
        dpi, quality = 110, 80
    try:
        out_img = await asyncio.to_thread(
            file_processor.render_sheet_preview, target_pdf, sheet_idx, cached_img_path, dpi, True, quality)
        return FileResponse(out_img, media_type="image/jpeg",
                            headers={"Cache-Control": "private, max-age=300"})
    except Exception as e:
        raise HTTPException(500, f"Preview render error: {e}")


@app.get("/api/kiosk/current-job")
async def get_current_job():
    with get_session() as s:
        # 1. Active jobs currently in progress
        job = s.query(PrintJob).filter(
            PrintJob.status.in_([
                JobStatus.PAID,
                JobStatus.PAID_PRINTING,
                JobStatus.SPOOLING,
                JobStatus.PRINTING,
                JobStatus.PAUSED_ERROR
            ])
        ).order_by(PrintJob.created_at.desc()).first()
        if job:
            return job.public()

        # 2. Recently completed or refunded jobs (within the last 25 seconds)
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=25)
        cutoff_naive = datetime.utcnow() - timedelta(seconds=25)
        recent_done = s.query(PrintJob).filter(
            PrintJob.status.in_([
                JobStatus.COMPLETED,
                JobStatus.REFUNDED,
                JobStatus.ABORTED_REFUNDED,
            ]),
            (PrintJob.updated_at >= cutoff_naive) | (PrintJob.updated_at >= cutoff)
        ).order_by(PrintJob.updated_at.desc()).first()
        if recent_done:
            return recent_done.public()

        return None

@app.get("/api/kiosk/queue")
def kiosk_queue():
    """
    Live queue for the kiosk display.
    """
    active_states = [JobStatus.PAID_PRINTING, JobStatus.SPOOLING, JobStatus.PRINTING, JobStatus.PAUSED_ERROR]
    waiting_states = [JobStatus.PAID]
    all_watch = active_states + waiting_states

    with get_session() as s:
        active_jobs = (
            s.query(PrintJob)
            .filter(PrintJob.status.in_(active_states))
            .order_by(PrintJob.paid_at.asc())
            .all()
        )
        waiting_jobs = (
            s.query(PrintJob)
            .filter(
                PrintJob.status.in_(waiting_states),
                PrintJob.user_name.isnot(None),
                PrintJob.user_name != "",
            )
            .order_by(PrintJob.created_at.desc())
            .all()
        )
        jobs = active_jobs + waiting_jobs

        out = []
        for i, j in enumerate(jobs):
            d = j.public()
            d["queue_position"] = i + 1
            d["is_active"] = j.status in active_states
            d["filename_masked"] = _mask_filename(j.original_filename)
            d["user_name"] = j.user_name or "Student"
            phone = j.user_phone or ""
            if len(phone) >= 10:
                d["user_phone_masked"] = f"+91 {phone[:2]}****{phone[-4:]}"
            elif phone:
                d["user_phone_masked"] = phone
            else:
                d["user_phone_masked"] = ""
            d.pop("filename", None)
            out.append(d)
    return out


def _mask_filename(name: str) -> str:
    """'Semester_Assignment.pdf' -> 'Se…nt.pdf'. Enough for the owner to
    recognise their own job, not enough to expose document titles to the
    whole queue."""
    stem, _, ext = name.rpartition(".")
    stem = stem or name
    if len(stem) <= 4:
        return name
    return f"{stem[:2]}...{stem[-2:]}" + (f".{ext}" if ext else "")


@app.get("/api/kiosk-qr")
def kiosk_qr():
    url = f"{config.PUBLIC_BASE_URL}/?kiosk_id={config.KIOSK_ID}"
    buf = io.BytesIO()
    qrcode.make(url).save(buf, format="PNG")
    return {"url": url,
            "qr_code_base64": "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()}


@app.get("/healthz")
@app.get("/health")
def healthz():
    return JSONResponse({"ok": True, "kiosk_id": config.KIOSK_ID, "simulate": config.SIMULATE})
