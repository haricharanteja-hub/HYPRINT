"""
database.py — SQLite persistence for the print kiosk.

LOCKING / IDEMPOTENCY DESIGN
============================
SQLite has no row-level `SELECT ... FOR UPDATE`; the database file is the
unit of locking. The guarantee we actually need ("a webhook delivered twice
must never charge or print twice") is provided by three layers:

 1. WAL mode — readers (admin dashboard, status polls) never block on the
    writer that's flipping a job's state.

 2. BEGIN IMMEDIATE for write transactions, via SQLAlchemy's documented
    pysqlite recipe (disable the driver's implicit BEGIN, then emit our own
    in the engine "begin" hook). This takes the write lock up front rather
    than optimistically escalating later and failing.

 3. Compare-and-swap UPDATEs (`atomic_transition`):
        UPDATE jobs SET status=:new WHERE id=:id AND status IN (:allowed)
    and check rowcount == 1. Only the first caller's WHERE clause matches;
    every subsequent duplicate is a no-op. This is the correct pattern for a
    job state machine on any database, not a SQLite workaround.

 4. A UNIQUE constraint on payment_ref is an independent backstop: the DB
    itself refuses a second row claiming the same gateway payment id.
"""

import enum
import os
import sqlite3
import sys
import threading
import uuid
from datetime import datetime, timezone

# Ensure platform compatibility warnings
if sys.platform != "win32":
    print("Warning: WMI tracking libraries require a Windows OS environment to sample printer ports.")

try:
    import pythoncom
    try:
        pythoncom.CoInitialize()
    except Exception:
        pass
    import wmi
except Exception:
    wmi = None

from sqlalchemy import (
    create_engine, event, update,
    Column, String, Integer, Float, Boolean, DateTime, Text, Enum as SAEnum,
)
from sqlalchemy.orm import declarative_base, sessionmaker, Session

# On Vercel / serverless, writeable storage is restricted to /tmp
DB_FILE = os.environ.get("KIOSK_DB_PATH") or os.path.join(os.path.dirname(os.path.abspath(__file__)), "print_kiosk.db")
DB_PATH = "/tmp/print_kiosk.db" if os.environ.get("VERCEL") else DB_FILE
engine = create_engine(
    f"sqlite:///{DB_PATH}",
    connect_args={"check_same_thread": False, "timeout": 30},
)

_local = threading.local()


@event.listens_for(engine, "connect")
def _on_connect(dbapi_conn, _):
    # Hand BEGIN control to us (see docstring point 2).
    dbapi_conn.isolation_level = None
    cur = dbapi_conn.cursor()
    cur.execute("PRAGMA journal_mode=WAL;")
    cur.execute("PRAGMA busy_timeout=5000;")
    cur.execute("PRAGMA foreign_keys=ON;")
    cur.close()


@event.listens_for(engine, "begin")
def _on_begin(conn):
    if getattr(_local, "begin_mode", "DEFERRED") == "IMMEDIATE":
        conn.exec_driver_sql("BEGIN IMMEDIATE")
        _local.begin_mode = "DEFERRED"   # don't leak into the next txn
    else:
        conn.exec_driver_sql("BEGIN")


SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
Base = declarative_base()


class JobStatus(str, enum.Enum):
    UPLOADED = "UPLOADED"
    PREFLIGHT_BLOCKED = "PREFLIGHT_BLOCKED"
    PENDING_PAYMENT = "PENDING_PAYMENT"
    ORDER_CREATED = "ORDER_CREATED"
    PAID = "PAID"
    PAID_PRINTING = "PAID_PRINTING"
    # Wait removed for V1.5. Goes straight to spooling.
    SPOOLING = "SPOOLING"
    PRINTING = "PRINTING"
    PAUSED_ERROR = "PAUSED_ERROR"
    COMPLETED = "COMPLETED"
    REFUNDED = "REFUNDED"
    ABORTED_REFUNDED = "ABORTED_REFUNDED"
    FAILED = "FAILED"
    FAILED_REBOOT = "FAILED_REBOOT"   # stranded by a crash/restart, recovered at boot
    CANCELLED = "CANCELLED"
    EXPIRED = "EXPIRED"               # unpaid and swept by the scavenger


TERMINAL_STATES = {
    JobStatus.COMPLETED, JobStatus.REFUNDED, JobStatus.ABORTED_REFUNDED,
    JobStatus.FAILED, JobStatus.FAILED_REBOOT, JobStatus.CANCELLED, JobStatus.EXPIRED,
}

# States that mean "this job was mid-flight when the process died".
STRANDED_STATES = {
    JobStatus.PAID, JobStatus.PAID_PRINTING, JobStatus.SPOOLING, JobStatus.PRINTING, JobStatus.PAUSED_ERROR,
}


class PrintJob(Base):
    __tablename__ = "print_jobs"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    kiosk_id = Column(String(32), nullable=False, index=True)

    # --- source file ---
    original_filename = Column(String(512), nullable=False)
    source_path = Column(String(1024), nullable=False)   # full uploaded PDF in /dev/shm
    print_path = Column(String(1024), nullable=False)    # sliced subset actually printed
    source_page_count = Column(Integer, nullable=False, default=0)

    # --- print options ---
    page_range = Column(String(256), nullable=True)      # raw user input, e.g. "1-5, 8"
    pages_selected = Column(Integer, nullable=False, default=0)   # after slicing
    copies = Column(Integer, nullable=False, default=1)
    duplex = Column(Boolean, nullable=False, default=False)
    paper_size = Column(String(16), nullable=False, default="A4")      # A4 | Letter | Legal
    orientation = Column(String(16), nullable=False, default="portrait")
    pages_per_sheet = Column(Integer, nullable=False, default=1)       # 1 | 2 | 4
    graph_sheets = Column(Integer, nullable=False, default=0)
    doc_sheets = Column(Integer, nullable=False, default=0)
    # This build drives a monochrome-only printer, so colour is not an option
    # the student can pick. Stored explicitly so the column is already here if
    # a colour unit is ever added to the fleet.
    color_mode = Column(String(16), nullable=False, default="monochrome")

    # --- pricing (always server-computed; client input is never trusted) ---
    price_per_page = Column(Float, nullable=False, default=2.0)
    total_price = Column(Float, nullable=False, default=0.0)
    amount_paise = Column(Integer, nullable=True)
    selected_pages = Column(Text, nullable=True)

    # --- state ---
    status = Column(SAEnum(JobStatus), nullable=False, default=JobStatus.UPLOADED, index=True)
    error_reason = Column(Text, nullable=True)
    error_message = Column(Text, nullable=True)

    # --- payment ---
    payment_order_id = Column(String(128), nullable=True)
    payment_ref = Column(String(128), nullable=True, unique=True)  # backstop vs replay
    razorpay_order_id = Column(String(128), nullable=True)
    razorpay_payment_id = Column(String(128), nullable=True)
    razorpay_refund_id = Column(String(128), nullable=True)
    paid_at = Column(DateTime, nullable=True)

    # --- printing ---
    cups_job_id = Column(Integer, nullable=True)
    sheets_printed = Column(Integer, nullable=False, default=0)
    sheets_total = Column(Integer, nullable=False, default=0)

    # --- student identity ---
    user_name = Column(String(128), nullable=True)
    user_phone = Column(String(32), nullable=True)
    release_pin = Column(String(16), nullable=True)

    # --- refund ---
    refund_amount = Column(Float, nullable=True)
    refund_ref = Column(String(128), nullable=True)
    refund_error = Column(Text, nullable=True)   # set if the gateway call failed

    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc))

    def public(self):
        """Safe projection for the student's browser."""
        return {
            "id": self.id,
            "job_id": self.id,
            "kiosk_id": self.kiosk_id,
            "filename": self.original_filename,
            "user_name": self.user_name or "Student",
            "user_phone": self.user_phone,
            "source_page_count": self.source_page_count,
            "pages_selected": self.pages_selected,
            "page_range": self.page_range,
            "selected_pages": self.selected_pages,
            "copies": self.copies,
            "duplex": self.duplex,
            "paper_size": self.paper_size,
            "orientation": self.orientation,
            "pages_per_sheet": self.pages_per_sheet,
            "graph_sheets": self.graph_sheets or 0,
            "doc_sheets": self.doc_sheets or 0,
            "color_mode": self.color_mode,
            "price_per_page": self.price_per_page,
            "total_price": self.total_price,
            "amount_paise": self.amount_paise or int(round((self.total_price or 0.0) * 100)),
            "status": self.status.value if isinstance(self.status, JobStatus) else self.status,
            "error_reason": self.error_reason or self.error_message,
            "error_message": self.error_message or self.error_reason,
            "sheets_printed": self.sheets_printed,
            "sheets_total": self.sheets_total,
            "refund_amount": self.refund_amount,
            "razorpay_order_id": self.razorpay_order_id or self.payment_order_id,
            "razorpay_payment_id": self.razorpay_payment_id or self.payment_ref,
            "razorpay_refund_id": self.razorpay_refund_id or self.refund_ref,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "paid_at": self.paid_at.isoformat() if self.paid_at else None,
        }

    def admin(self):
        d = self.public()
        d.update({
            "payment_ref": self.payment_ref or self.razorpay_payment_id,
            "payment_order_id": self.payment_order_id or self.razorpay_order_id,
            "refund_ref": self.refund_ref or self.razorpay_refund_id,
            "refund_error": self.refund_error,
            "cups_job_id": self.cups_job_id,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        })
        return d


def init_db():
    Base.metadata.create_all(engine)
    import sqlite3
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(print_jobs)")
        existing = [row[1] for row in cur.fetchall()]
        if "user_name" not in existing:
            cur.execute("ALTER TABLE print_jobs ADD COLUMN user_name VARCHAR(128)")
        if "user_phone" not in existing:
            cur.execute("ALTER TABLE print_jobs ADD COLUMN user_phone VARCHAR(32)")
        if "release_pin" not in existing:
            cur.execute("ALTER TABLE print_jobs ADD COLUMN release_pin VARCHAR(16)")
        if "razorpay_order_id" not in existing:
            cur.execute("ALTER TABLE print_jobs ADD COLUMN razorpay_order_id VARCHAR(128)")
        if "razorpay_payment_id" not in existing:
            cur.execute("ALTER TABLE print_jobs ADD COLUMN razorpay_payment_id VARCHAR(128)")
        if "razorpay_refund_id" not in existing:
            cur.execute("ALTER TABLE print_jobs ADD COLUMN razorpay_refund_id VARCHAR(128)")
        if "amount_paise" not in existing:
            cur.execute("ALTER TABLE print_jobs ADD COLUMN amount_paise INTEGER")
        if "selected_pages" not in existing:
            cur.execute("ALTER TABLE print_jobs ADD COLUMN selected_pages TEXT")
        if "error_message" not in existing:
            cur.execute("ALTER TABLE print_jobs ADD COLUMN error_message TEXT")
        # Ensure alias view jobs exists
        cur.execute("CREATE VIEW IF NOT EXISTS jobs AS SELECT * FROM print_jobs")
        conn.commit()
        conn.close()
    except Exception as e:
        print("[init_db] migration note:", e)


def get_session() -> Session:
    """Read session (deferred BEGIN, shared lock only)."""
    return SessionLocal()


def get_write_session() -> Session:
    """Write session — takes SQLite's write lock immediately."""
    _local.begin_mode = "IMMEDIATE"
    return SessionLocal()


def atomic_transition(session: Session, job_id: str,
                      from_statuses: set, to_status: JobStatus, **fields) -> bool:
    """Compare-and-swap the status. True iff THIS call performed the move.
    Caller owns the transaction (commit/rollback)."""
    stmt = (
        update(PrintJob)
        .where(PrintJob.id == job_id)
        .where(PrintJob.status.in_(list(from_statuses)))
        .values(status=to_status, updated_at=datetime.now(timezone.utc), **fields)
    )
    return session.execute(stmt).rowcount == 1


# ===========================================================================
# Hardware Watchdog Telemetry & Virtual Paper Tray Inventory
# ===========================================================================

class PrinterHardwareLog(Base):
    __tablename__ = "printer_hardware_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    timestamp = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    printer_status_code = Column(Integer, nullable=True)
    error_state_code = Column(Integer, nullable=True)
    status_message = Column(Text, nullable=True)
    is_blocking = Column(Boolean, default=False)


class PaperTrayInventory(Base):
    __tablename__ = "paper_tray_inventory"

    id = Column(Integer, primary_key=True)
    sheets_remaining = Column(Integer, default=150)
    last_refill_timestamp = Column(DateTime, default=lambda: datetime.now(timezone.utc))


def init_kiosk_db(db_path=None):
    """Initializes schema to handle printer state telemetry and virtual metrics."""
    target_path = db_path or DB_PATH
    conn = sqlite3.connect(target_path)
    cursor = conn.cursor()
    
    # Track critical hardware errors and blocks
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS printer_hardware_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            printer_status_code INTEGER,
            error_state_code INTEGER,
            status_message TEXT,
            is_blocking BOOLEAN
        )
    ''')
    
    # Inventory proxy for the P1108 plus missing low paper hardware sensor
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS paper_tray_inventory (
            id INTEGER PRIMARY KEY,
            sheets_remaining INTEGER,
            last_refill_timestamp DATETIME
        )
    ''')
    
    # Seed default paper capacity profile (P1108 plus input tray holds up to 150 sheets)
    cursor.execute("INSERT OR IGNORE INTO paper_tray_inventory (id, sheets_remaining, last_refill_timestamp) VALUES (1, 150, CURRENT_TIMESTAMP)")
    
    conn.commit()
    conn.close()


def check_and_log_printer_status(db_path=None):
    """
    Connects to Windows Management Instrumentation to poll hardware telemetry.
    Maps status arrays directly to database constraints to protect kiosk payments.
    """
    target_path = db_path or DB_PATH
    if wmi is None:
        return "ERROR_MISSING_WMI_LIB"

    if pythoncom:
        try:
            pythoncom.CoInitialize()
        except Exception:
            pass

    conn = sqlite3.connect(target_path)
    cursor = conn.cursor()
    
    try:
        c = wmi.WMI()
        # Query target device (P1108 plus or system-registered P1100 plus series)
        printers = c.Win32_Printer(Name="HP LaserJet Pro P1108 plus")
        if not printers:
            printers = c.Win32_Printer(Name="HP LaserJet Pro P1100 plus series")
        if not printers:
            all_printers = c.Win32_Printer()
            printers = [p for p in all_printers if "P110" in (p.Name or "") or "HP LaserJet" in (p.Name or "")]
        
        if not printers:
            # Physical USB connection loss or power breakdown flag
            cursor.execute(
                "INSERT INTO printer_hardware_logs (printer_status_code, error_state_code, status_message, is_blocking) VALUES (?, ?, ?, ?)",
                (1, 0, "CABLE_DISCONNECTED_OR_POWER_LOSS", True)
            )
            conn.commit()
            return "CRITICAL_OFFLINE"
            
        printer = printers[0]
        ext_status = getattr(printer, "ExtendedPrinterStatus", None)
        det_error = getattr(printer, "DetectedErrorState", None)
        work_offline = getattr(printer, "WorkOffline", False)
        printer_status = getattr(printer, "PrinterStatus", None)
        
        status_msg = "UNKNOWN_PRINTER_STATE"
        is_blocking = False
        
        # Explicit hardware flag translation logic
        if work_offline:
            status_msg = "PRINTER_SET_TO_OFFLINE"
            is_blocking = True
        elif ext_status == 1:
            status_msg = "FATAL_ENGINE_ERROR_FUSER_OR_LASER_SCANNER"
            is_blocking = True
        elif ext_status == 4:
            status_msg = "PHYSICAL_PAPER_JAM"
            is_blocking = True
        elif ext_status == 5:
            status_msg = "OUT_OF_PAPER"
            is_blocking = True
        elif det_error == 4:
            status_msg = "CARTRIDGE_MISSING_OR_DOOR_OPEN"
            is_blocking = True
        elif ext_status == 2 or printer_status == 3:
            status_msg = "PRINTER_READY"
            is_blocking = False
            
        cursor.execute(
            "INSERT INTO printer_hardware_logs (printer_status_code, error_state_code, status_message, is_blocking) VALUES (?, ?, ?, ?)",
            (ext_status, det_error, status_msg, is_blocking)
        )
        conn.commit()
        return "BLOCKING_ERROR" if is_blocking else "READY"
        
    except Exception as e:
        cursor.execute(
            "INSERT INTO printer_hardware_logs (printer_status_code, error_state_code, status_message, is_blocking) VALUES (?, ?, ?, ?)",
            (0, 0, f"WMI_QUERY_EXCEPTION: {str(e)}", True)
        )
        conn.commit()
        return "CRITICAL_EXCEPTION"
    finally:
        conn.close()


def deduct_printed_pages(pages_printed: int, db_path=None) -> str:
    """
    Virtual low paper detection model logic.
    Calculates expected remaining stock manually to bypass hardware sensor omission.
    """
    target_path = db_path or DB_PATH
    conn = sqlite3.connect(target_path)
    cursor = conn.cursor()
    
    cursor.execute("SELECT sheets_remaining FROM paper_tray_inventory WHERE id = 1")
    row = cursor.fetchone()
    current_stock = row[0] if row else 150
    
    new_stock = max(0, current_stock - pages_printed)
    
    cursor.execute("UPDATE paper_tray_inventory SET sheets_remaining = ? WHERE id = 1", (new_stock,))
    conn.commit()
    conn.close()
    
    # 15 page safety buffer alert for out-of-service maintenance routines
    if new_stock <= 15:
        return "WARN_LOW_PAPER"
    return "OK"


def reset_paper_tray(sheets: int = 150, db_path=None) -> str:
    """Called by technician UI hook upon restocking paper cassettes."""
    target_path = db_path or DB_PATH
    conn = sqlite3.connect(target_path)
    cursor = conn.cursor()
    cursor.execute("UPDATE paper_tray_inventory SET sheets_remaining = ?, last_refill_timestamp = CURRENT_TIMESTAMP WHERE id = 1", (sheets,))
    conn.commit()
    conn.close()
    return "TRAY_RESET_SUCCESS"


def get_paper_tray_status(db_path=None) -> dict:
    """Returns real-time telemetry for the virtual paper tray inventory."""
    target_path = db_path or DB_PATH
    conn = sqlite3.connect(target_path)
    cursor = conn.cursor()
    cursor.execute("SELECT sheets_remaining, last_refill_timestamp FROM paper_tray_inventory WHERE id = 1")
    row = cursor.fetchone()
    conn.close()
    if row:
        sheets = row[0]
        refill = row[1]
    else:
        sheets = 150
        refill = None
    return {
        "sheets_remaining": sheets,
        "max_capacity": 150,
        "last_refill_timestamp": refill,
        "is_low": sheets <= 15,
        "is_empty": sheets <= 0,
    }


def init_db():
    Base.metadata.create_all(engine)
    init_kiosk_db(DB_PATH)
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(print_jobs)")
        existing = [row[1] for row in cur.fetchall()]
        if "user_name" not in existing:
            cur.execute("ALTER TABLE print_jobs ADD COLUMN user_name VARCHAR(128)")
        if "user_phone" not in existing:
            cur.execute("ALTER TABLE print_jobs ADD COLUMN user_phone VARCHAR(32)")
        conn.commit()
        conn.close()
    except Exception as e:
        print("[init_db] migration note:", e)


if __name__ == "__main__":
    init_kiosk_db()
    print("Database layer compiled cleanly inside Antigravity Sandbox environment.")
