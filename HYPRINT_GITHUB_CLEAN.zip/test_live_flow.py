import os
import sys
import pymupdf
import requests

BASE_LOCAL = "http://127.0.0.1:8000"
CF_TUNNEL = "https://investments-mean-collected-cpu.trycloudflare.com"

print("=========================================================")
print(" HYPRINT E2E MERGE & SLICE AUTOMATED VERIFICATION TEST ")
print("=========================================================\n")

# Step 1: Create sample test PDFs
print("[1/6] Creating test PDFs...")
doc1 = pymupdf.open()
for i in range(2):
    p = doc1.new_page(width=595, height=842)
    p.insert_text((50, 100), f"Document 1 - Page {i+1} of 2", fontsize=24)
doc1.save("test_file1_2pg.pdf")
doc1.close()

doc2 = pymupdf.open()
for i in range(3):
    p = doc2.new_page(width=595, height=842)
    p.insert_text((50, 100), f"Document 2 - Page {i+1} of 3", fontsize=24)
doc2.save("test_file2_3pg.pdf")
doc2.close()
print("   [OK] Created test_file1_2pg.pdf (2 pages)")
print("   [OK] Created test_file2_3pg.pdf (3 pages)")

# Step 2: Upload File 1
print("\n[2/6] Uploading File 1 (2 pages) via POST /api/upload...")
with open("test_file1_2pg.pdf", "rb") as f1:
    r1 = requests.post(
        f"{BASE_LOCAL}/api/upload",
        files=[("files", ("test_file1_2pg.pdf", f1, "application/pdf"))],
        data={"user_name": "TestStudent", "user_phone": "9876543210"}
    )
assert r1.status_code == 200, f"Upload 1 failed: {r1.status_code} - {r1.text}"
data1 = r1.json()
job_id = data1["id"]
pages1 = data1["source_page_count"]
files1 = data1["files"]
print(f"   [OK] Job ID: {job_id}")
print(f"   [OK] Pages returned: {pages1} (expected: 2)")
print(f"   [OK] Files in cart: {[f['name'] for f in files1]}")
assert pages1 == 2, f"Expected 2 pages, got {pages1}"
assert len(files1) == 1, f"Expected 1 file in cart, got {len(files1)}"

# Step 3: Upload File 2 with same job_id (Append & Merge)
print(f"\n[3/6] Uploading File 2 (3 pages) with job_id={job_id} (Testing Append & Merge)...")
with open("test_file2_3pg.pdf", "rb") as f2:
    r2 = requests.post(
        f"{BASE_LOCAL}/api/upload",
        files=[("files", ("test_file2_3pg.pdf", f2, "application/pdf"))],
        data={"job_id": job_id, "user_name": "TestStudent", "user_phone": "9876543210"}
    )
assert r2.status_code == 200, f"Upload 2 failed: {r2.status_code} - {r2.text}"
data2 = r2.json()
assert data2["id"] == job_id, f"Job ID changed! {data2['id']} != {job_id}"
pages2 = data2["source_page_count"]
files2 = data2["files"]
file_names = [f["name"] for f in files2]
print(f"   [OK] Job ID preserved: {data2['id']}")
print(f"   [OK] Merged Total Pages: {pages2} (expected: 5 = 2 + 3)")
print(f"   [OK] Files in cart ({len(files2)}): {file_names}")
assert pages2 == 5, f"Expected 5 merged pages, got {pages2}"
assert len(files2) == 2, f"Expected 2 files retained, got {len(files2)}"
assert "test_file1_2pg.pdf" in file_names, "File 1 was lost!"
assert "test_file2_3pg.pdf" in file_names, "File 2 was missing!"

# Step 4: Slicing Page Range 1-3
print("\n[4/6] Setting page range to '1-3' on 5-page document via POST /api/job/{job_id}/update-options...")
r3 = requests.post(
    f"{BASE_LOCAL}/api/job/{job_id}/update-options",
    data={"page_range": "1-3", "copies": "1", "duplex": "false"}
)
assert r3.status_code == 200, f"Update options failed: {r3.status_code} - {r3.text}"
data3 = r3.json()
pages_sel = data3["pages_selected"]
total_price = data3["total_price"]
print(f"   [OK] Pages Selected: {pages_sel} (of {pages2})")
print(f"   [OK] Total Price: Rs.{total_price} (expected: Rs.6.0 for 3 pages)")
assert pages_sel == 3, f"Expected 3 pages selected, got {pages_sel}"
assert total_price == 6.0, f"Expected Rs.6.0, got {total_price}"

# Step 5: Check Preview Endpoints
print("\n[5/6] Verifying Preview Endpoints for selected pages 1, 2, 3...")
for p in range(1, 4):
    rp = requests.get(f"{BASE_LOCAL}/api/preview/{job_id}/{p}")
    assert rp.status_code == 200, f"Preview page {p} failed: {rp.status_code}"
    assert rp.headers.get("content-type") == "image/jpeg", f"Invalid content type: {rp.headers.get('content-type')}"
    print(f"   [OK] Page {p} Preview: HTTP 200 OK, JPEG ({len(rp.content)} bytes)")

# Step 6: Verify physical sliced PDF contains exactly 3 pages
print("\n[6/6] Verifying sliced PDF on disk...")
# Check print_path in job details
rj = requests.get(f"{BASE_LOCAL}/api/job/{job_id}")
assert rj.status_code == 200
# Sliced file in SHM_DIR:
storage_dir = os.path.join(os.getcwd(), "_tmp_kiosk_storage")
sliced_path = os.path.join(storage_dir, f"{job_id}_print.pdf")
assert os.path.exists(sliced_path), f"Sliced PDF not found at {sliced_path}"
sliced_doc = pymupdf.open(sliced_path)
sliced_page_count = len(sliced_doc)
sliced_doc.close()
print(f"   [OK] Sliced PDF Path: {sliced_path}")
print(f"   [OK] Sliced PDF Page Count: {sliced_page_count} (expected: 3)")
assert sliced_page_count == 3, f"Expected exactly 3 pages in sliced PDF, found {sliced_page_count}"

print("\n=========================================================")
print(" ALL TESTS PASSED! MERGE & SLICE CONFIRMED WORKING 100% ")
print("=========================================================")
