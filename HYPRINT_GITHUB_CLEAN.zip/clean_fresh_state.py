import sqlite3
import glob
import os

conn = sqlite3.connect('print_kiosk.db')
c = conn.cursor()
c.execute("UPDATE print_jobs SET status = 'CANCELLED' WHERE status IN ('PENDING_PAYMENT', 'UPLOADED', 'SPOOLING', 'PRINTING', 'PAUSED_ERROR')")
conn.commit()
print('Updated non-completed jobs to CANCELLED. Rows modified:', c.rowcount)

c.execute("SELECT id, status, release_pin FROM print_jobs WHERE status IN ('PENDING_PAYMENT', 'UPLOADED', 'SPOOLING', 'PRINTING', 'PAUSED_ERROR')")
print('Active remaining jobs:', c.fetchall())
conn.close()

cleared_count = 0
for f in glob.glob('_tmp_kiosk_storage/*'):
    try:
        if os.path.isfile(f):
            os.remove(f)
            cleared_count += 1
    except Exception as e:
        pass
print(f'Cleaned up {cleared_count} temporary storage files.')
