"""
cups_manager.py — all printer I/O lives here, so nothing else touches pycups.

Two backends selected by config.SIMULATE:

  SIMULATE=True  — an in-memory fake printer. Lets you run and demo the whole
                   system (including jams, freezes, refunds) on any machine
                   with no hardware and no CUPS. Fault injection endpoints in
                   main.py drive it.

  SIMULATE=False — real pycups against the local CUPS daemon. Needs
                   `sudo apt install libcups2-dev` before `pip install pycups`,
                   and the printer already added to CUPS.

The rest of the app is identical in both modes.
"""

import itertools
import threading
import time

import config

# printer-state-reasons that must block a student from paying (pre-flight).
BLOCKING_PREFIXES = (
    "media-empty", "media-jam", "media-needed",
    "marker-supply", "cover-open", "door-open",
    "toner-empty", "toner-missing", "toner", "output-area-full",
    "offline-report", "printer-unreachable",
    "user-intervention-needed",
    "printer-out-of-memory", "printer-paused", "other-error",
)

# job-state-reasons that mean the job has stalled mid-print.
JAM_PREFIXES = (
    "media-empty", "media-jam", "media-needed",
    "marker-supply", "cover-open", "door-open",
    "offline-report", "toner-empty", "toner-missing", "toner", "output-area-full",
    "printer-unreachable", "user-intervention-needed",
    "printer-out-of-memory", "printer-paused", "other-error",
)

_job_counter = itertools.count(1000)


def _matches(reason: str, prefixes) -> bool:
    return any(reason.startswith(p) for p in prefixes)


# ---------------------------------------------------------------------------
# Simulator
# ---------------------------------------------------------------------------
class _Simulator:
    def __init__(self):
        self.lock = threading.Lock()
        self.printer_reasons: list[str] = []
        self.jobs: dict[int, dict] = {}

    def set_printer_fault(self, reason):
        with self.lock:
            self.printer_reasons = [reason] if reason else []

    def set_job_fault(self, job_id, reason):
        with self.lock:
            j = self.jobs.get(job_id)
            if j:
                j["reasons"] = [reason] if reason else []

    def start(self, sheets_total) -> int:
        jid = next(_job_counter)
        with self.lock:
            self.jobs[jid] = {"state": "processing", "reasons": [],
                              "sheets_total": sheets_total, "sheets_done": 0,
                              "started": time.time()}
        return jid

    def tick(self, jid):
        with self.lock:
            j = self.jobs.get(jid)
            if not j or j["state"] in ("completed", "canceled"):
                return
            if j["reasons"]:
                return                      # stalled
            if j["sheets_done"] < j["sheets_total"]:
                j["sheets_done"] += 1
            if j["sheets_done"] >= j["sheets_total"]:
                j["state"] = "completed"

    def get(self, jid):
        with self.lock:
            j = self.jobs.get(jid)
            return dict(j) if j else None

    def cancel(self, jid):
        with self.lock:
            if jid in self.jobs:
                self.jobs[jid]["state"] = "canceled"

    def cancel_all(self) -> int:
        with self.lock:
            n = 0
            for j in self.jobs.values():
                if j["state"] == "processing":
                    j["state"] = "canceled"
                    n += 1
            return n


_sim = _Simulator()


def simulator() -> _Simulator:
    return _sim


# ---------------------------------------------------------------------------
# Windows spooler job tracking
# Maps sim_id -> Windows spooler job ID (or None if not tracked)
# ---------------------------------------------------------------------------
_windows_print_jobs: dict[int, int | None] = {}  # sim_id → Win32 job id
_win_job_meta: dict[int, dict] = {}             # sim_id → {sheets_total, start_time, win_job_id}
_wpj_lock = threading.Lock()


def _snapshot_spooler_jobs(printer_name: str) -> set:
    """Return the set of current Windows spooler job IDs for the printer."""
    try:
        import win32print
        h = win32print.OpenPrinter(printer_name)
        try:
            jobs = win32print.EnumJobs(h, 0, -1, 1)
            return {j["JobId"] for j in jobs}
        finally:
            win32print.ClosePrinter(h)
    except Exception:
        return set()


def _find_new_spooler_job(jobs_before: set, printer_name: str, retries: int = 8) -> int | None:
    """
    Poll the spooler up to `retries` times (0.5s apart) to find a job
    that wasn't present before we called SumatraPDF.
    Returns the Windows job ID or None if we couldn’t identify it.
    """
    for _ in range(retries):
        time.sleep(0.5)
        jobs_now = _snapshot_spooler_jobs(printer_name)
        new = jobs_now - jobs_before
        if new:
            return next(iter(new))
    # Job may have already completed (very short doc)
    return None


def _get_win_job_info(win_job_id: int, printer_name: str) -> dict:
    """
    Query a specific Windows spooler job.
    Returns {found, pages_printed, total_pages, status_bits, status_text}.
    """
    try:
        import win32print
        h = win32print.OpenPrinter(printer_name)
        try:
            jobs = win32print.EnumJobs(h, 0, -1, 2)
        finally:
            win32print.ClosePrinter(h)
        for j in jobs:
            if j.get("JobId") == win_job_id:
                return {
                    "found": True,
                    "pages_printed": j.get("PagesPrinted", 0) or 0,
                    "total_pages": j.get("TotalPages", 0) or 0,
                    "status_bits": j.get("Status", 0) or 0,
                    "status_text": (j.get("pStatus") or "").lower(),
                }
        return {"found": False}   # job gone → completed
    except Exception:
        return {"found": False}


def cancel_stuck_windows_jobs(printer_name: str = None) -> int:
    """Cancels and deletes all stuck jobs from the Windows print spooler queue."""
    if os.name != 'nt':
        return 0
    if not printer_name:
        printer_name = get_active_printer_name()
    h = None
    count = 0
    try:
        import win32print
        h = win32print.OpenPrinter(printer_name)
        jobs = win32print.EnumJobs(h, 0, -1, 1) or []
        for j in jobs:
            try:
                win32print.SetJob(h, j["JobId"], 0, None, win32print.JOB_CONTROL_DELETE)
                count += 1
            except Exception:
                pass
    except Exception:
        pass
    finally:
        if h:
            try:
                win32print.ClosePrinter(h)
            except Exception:
                pass
    return count


def nuclear_spooler_reset(printer_name: str = None) -> int:
    """
    Module 4 Nuclear Spooler Reset:
    1. Immediately kill renderer: taskkill /F /IM SumatraPDF.exe
    2. Send JOB_CONTROL_PAUSE to all jobs in win32print.EnumJobs to block data flushing over USB.
    3. Send PRINTER_CONTROL_PURGE.
    4. Execute elevated spooler reset: net stop spooler /y && del /Q /F /S "%systemroot%\\System32\\Spool\\Printers\\*.*" && net start spooler
       with Win32 fallback if permissions denied.
    """
    if os.name != 'nt':
        return 0
    import subprocess
    if not printer_name:
        printer_name = get_active_printer_name()
    count = 0

    # 1. Kill active renderer
    try:
        subprocess.run(["taskkill", "/F", "/IM", "SumatraPDF.exe"], capture_output=True, timeout=5)
    except Exception:
        pass

    # 2 & 3. Pause all spooler jobs and purge
    h = None
    try:
        import win32print
        h = win32print.OpenPrinter(printer_name, {"DesiredAccess": win32print.PRINTER_ALL_ACCESS})
    except Exception:
        try:
            import win32print
            h = win32print.OpenPrinter(printer_name)
        except Exception:
            h = None

    if h:
        try:
            import win32print
            jobs = win32print.EnumJobs(h, 0, -1, 1) or []
            for j in jobs:
                try:
                    win32print.SetJob(h, j["JobId"], 0, None, win32print.JOB_CONTROL_PAUSE)
                    win32print.SetJob(h, j["JobId"], 0, None, win32print.JOB_CONTROL_DELETE)
                    count += 1
                except Exception:
                    pass
            try:
                win32print.SetPrinter(h, 0, None, win32print.PRINTER_CONTROL_PURGE)
            except Exception:
                pass
        except Exception:
            pass
        finally:
            try:
                import win32print
                win32print.ClosePrinter(h)
            except Exception:
                pass

    # 4. Elevated spooler restart to wipe physical spool cache
    try:
        cmd = 'net stop spooler /y && del /Q /F /S "%systemroot%\\System32\\Spool\\Printers\\*.*" && net start spooler'
        subprocess.run(cmd, shell=True, capture_output=True, timeout=10)
    except Exception as e:
        print(f"[nuclear_spooler_reset] service restart notice: {e}")

    return count


# ---------------------------------------------------------------------------
# Real CUPS
# ---------------------------------------------------------------------------
_conn = None
_conn_lock = threading.Lock()


def _cups():
    global _conn
    with _conn_lock:
        if _conn is None:
            import cups                       # imported lazily so dev boxes work
            _conn = cups.Connection()
        return _conn


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
import os

class _FastEngineUnavailable(Exception):
    """The fast engine could not start (nothing was sent), so another engine may be tried."""


def _darkening_lut() -> list:
    # One pass that does what the old GDI path did in two (contrast 2.2 + gamma 2.6):
    # light anti-aliased grey edges are pulled towards solid toner black before dithering.
    lut = []
    for i in range(256):
        v = (i / 255.0 - 0.5) * 2.2 + 0.5
        v = min(1.0, max(0.0, v)) ** 2.6
        lut.append(int(round(v * 255)))
    return lut


def _print_windows_native(file_path: str, printer_name: str, title: str, opts: dict):
    """Engine dispatcher. KIOSK_PRINT_ENGINE=fast (default) or sumatra."""
    engine = (getattr(config, "PRINT_ENGINE", "fast") or "fast").lower()
    if engine in ("fast", "gdi"):
        try:
            return _print_windows_fast(file_path, printer_name, title, opts)
        except _FastEngineUnavailable as e:
            print(f"[print] fast engine unavailable ({e}); falling back to SumatraPDF")
    return _print_windows_sumatra(file_path, printer_name, title, opts)


def _print_windows_fast(file_path: str, printer_name: str, title: str, opts: dict) -> bool:
    """
    Seamless printing for the HP LaserJet Pro P1108 (host-based, ~2 pages of printer RAM).

    Why the old path paused every 2 pages: SumatraPDF hands the driver a full-colour
    bitmap per page (~100 MB at 600 dpi). The host-based driver could not convert and
    stream those as fast as the 18 ppm engine consumes them, so the printer emptied its
    2-page buffer and waited.

    This engine sends the printer exactly what a laser can print: a 1-bit, 600 dpi,
    already-dithered page (~4 MB), drawn 1:1 in device pixels (no stretching). A
    background thread renders page N+1 (and N+2) while page N is being spooled, so the
    data stream always stays ahead of the paper.
    """
    import queue as _queue

    abs_path = os.path.abspath(file_path)
    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Print file not found: {abs_path}")

    try:
        import pymupdf
        import win32ui
        import win32gui
        import win32print
        import win32con
        from PIL import Image, ImageWin
    except Exception as e:
        raise _FastEngineUnavailable(f"missing module: {e}")

    opts = opts or {}
    copies = max(1, int(opts.get("copies", 1) or 1))
    user_orient = opts.get("orientation", "auto")

    # --- device context: A4, simplex, portrait paper path, 1 copy per DEVMODE ---
    hdc = None
    try:
        try:
            hprinter = win32print.OpenPrinter(printer_name)
        except Exception:
            printer_name = win32print.GetDefaultPrinter()
            hprinter = win32print.OpenPrinter(printer_name)
        try:
            devmode = win32print.GetPrinter(hprinter, 2).get("pDevMode")
        finally:
            win32print.ClosePrinter(hprinter)
        if devmode:
            devmode.PaperSize = win32con.DMPAPER_A4
            devmode.Orientation = win32con.DMORIENT_PORTRAIT
            devmode.Duplex = win32con.DMDUP_SIMPLEX
            devmode.Copies = 1
            try:
                devmode.Color = win32con.DMCOLOR_MONOCHROME
            except Exception:
                pass
            hdc = win32ui.CreateDCFromHandle(win32gui.CreateDC("WINSPOOL", printer_name, devmode))
        else:
            hdc = win32ui.CreateDC()
            hdc.CreatePrinterDC(printer_name)
        pw = hdc.GetDeviceCaps(win32con.HORZRES)
        ph = hdc.GetDeviceCaps(win32con.VERTRES)
        doc = pymupdf.open(abs_path)
    except Exception as e:
        if hdc is not None:
            try:
                hdc.DeleteDC()
            except Exception:
                pass
        raise _FastEngineUnavailable(f"could not open printer DC: {e}")

    lut = _darkening_lut()
    order = [pno for _ in range(copies) for pno in range(len(doc))]
    pages_q: "_queue.Queue" = _queue.Queue(maxsize=3)
    stop = threading.Event()
    failures: list = []

    def _render_pages():
        try:
            for pno in order:
                if stop.is_set():
                    return
                page = doc[pno]
                r = page.rect
                rotate = (user_orient == "landscape" or (user_orient != "portrait" and r.width > r.height)) and pw < ph
                w_pt, h_pt = (r.height, r.width) if rotate else (r.width, r.height)
                zoom = min(pw / w_pt, ph / h_pt)        # fit the printable area, in device pixels
                mat = pymupdf.Matrix(zoom, zoom)
                if rotate:
                    mat = mat.prerotate(90)
                pix = page.get_pixmap(matrix=mat, colorspace=pymupdf.csGRAY, alpha=False)
                img = Image.frombytes("L", (pix.width, pix.height), pix.samples)
                pix = None
                img = img.point(lut).convert("1")       # Floyd–Steinberg dither -> laser-native 1-bit
                while not stop.is_set():
                    try:
                        pages_q.put(img, timeout=0.5)
                        break
                    except _queue.Full:
                        continue
        except Exception as e:
            failures.append(e)
        finally:
            while True:
                try:
                    pages_q.put(None, timeout=0.5)
                    break
                except _queue.Full:
                    if stop.is_set():
                        break

    renderer = threading.Thread(target=_render_pages, name="hyprint-page-renderer", daemon=True)
    renderer.start()
    sent = 0
    try:
        hdc.StartDoc(title)
        try:
            while True:
                img = pages_q.get()
                if img is None:
                    break
                hdc.StartPage()
                x = max(0, (pw - img.width) // 2)
                y = max(0, (ph - img.height) // 2)
                ImageWin.Dib(img).draw(hdc.GetHandleOutput(), (x, y, x + img.width, y + img.height))
                hdc.EndPage()
                sent += 1
            if failures:
                raise RuntimeError(f"page rendering failed: {failures[0]}")
            if sent != len(order):
                raise RuntimeError(f"only {sent} of {len(order)} pages were rendered")
        except Exception:
            stop.set()
            try:
                hdc.AbortDoc()
            except Exception:
                pass
            raise
        hdc.EndDoc()
    finally:
        stop.set()
        renderer.join(timeout=5)
        doc.close()
        try:
            hdc.DeleteDC()
        except Exception:
            pass
    print(f"[print] fast engine spooled {sent} page(s) ({copies} cop{'y' if copies == 1 else 'ies'}) to '{printer_name}'")
    return True


def _print_windows_sumatra(file_path: str, printer_name: str, title: str, opts: dict):
    """
    Spools PDF directly to the physical Windows printer (Brother DCP-L2520D series).
    Uses the embedded silent SumatraPDF engine with support for duplex, copies,
    paper size, and orientation.

    CREATE_NO_WINDOW is critical — without it, SumatraPDF may open a hidden
    dialog box waiting for input (e.g. "printer not ready") when run from a
    background service/thread, blocking indefinitely.
    """
    import subprocess

    abs_path = os.path.abspath(file_path)
    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Print file not found: {abs_path}")

    # Verify printer is reachable; fall back to default if the configured
    # name is not found (e.g. driver was renamed).
    try:
        import win32print
        hprinter = win32print.OpenPrinter(printer_name)
        win32print.ClosePrinter(hprinter)
        print(f"[print] Printer '{printer_name}' opened OK")
    except Exception as e:
        print(f"[print] Warning: could not open '{printer_name}': {e}")
        try:
            import win32print
            printer_name = win32print.GetDefaultPrinter()
            print(f"[print] Falling back to default printer: '{printer_name}'")
        except Exception:
            pass

    # --- Build SumatraPDF -print-settings string ---
    # Brother DCP-L2520D is a monochrome GDI laser printer with 32MB RAM.
    # 1. "monochrome" is MANDATORY so SumatraPDF does NOT generate 25MB+ 24-bit RGB raster data.
    # 2. "fit" scales the document cleanly to printable margins.
    # 3. DO NOT include "portrait" (SumatraPDF's "portrait" flag forces a 90° content rotation).
    # 4. DO NOT include "paper=A4" (printer driver default is already A4; overriding creates geometry conflict).
    settings_parts = ["fit", "monochrome"]

    copies = int(opts.get("copies", 1) or 1)
    if copies > 1:
        settings_parts.append(f"{copies}x")

    is_duplex = bool(opts.get("duplex", False))
    # HP LaserJet Pro P1100 series printers (P1102/P1106/P1108) lack an internal auto-duplexer.
    # Passing "duplex" to SumatraPDF triggers the HP driver's modal manual-duplex prompt on Windows,
    # which stalls the spooler and triggers false watchdog refunds.
    if is_duplex:
        is_hp_p1100 = "p110" in printer_name.lower() or "p1100" in printer_name.lower() or "laserjet 1020" in printer_name.lower()
        if is_hp_p1100:
            print(f"[print] Warning: '{printer_name}' lacks hardware duplexer. Enforcing simplex to prevent driver hang.")
            settings_parts.append("simplex")
        else:
            settings_parts.append("duplex")
    else:
        settings_parts.append("simplex")

    # HYPRINT bundles already carry the final sheet geometry (landscape sheets are
    # 841.89 x 595.28 pt pages). With no orientation flag SumatraPDF auto-rotates each
    # page onto the A4 paper path, which is exactly right for mixed bundles (e.g. landscape
    # 2-up sheets followed by portrait graph paper). Forcing "landscape" would rotate the
    # portrait graph sheets too, so it is only honoured when explicitly requested.
    if opts.get("orientation") == "landscape":
        settings_parts.append("landscape")

    print_settings = ",".join(settings_parts)

    # We now route ALL prints through SumatraPDF natively to preserve vector data
    # (infinite resolution, 100% pure black text) instead of rasterizing via GDI.
    # GDI is strictly kept as a fallback mechanism if SumatraPDF hangs.
    # We removed the simplex/GDI override.

    # Primary Engine: SumatraPDF natively routes vector data directly to the printer
    # (infinite crispness, zero rasterization loss, fast native spooling).
    sumatra_exe_global = r"C:\Program Files\SumatraPDF\SumatraPDF.exe"
    # Resolve next to this file, not the process CWD (uvicorn may be launched from anywhere).
    sumatra_exe_local = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bin", "SumatraPDF.exe")
    sumatra_exe = sumatra_exe_global if os.path.exists(sumatra_exe_global) else sumatra_exe_local

    if os.path.exists(sumatra_exe):
        cmd = [
            sumatra_exe,
            "-silent",
            "-print-to", printer_name,
            "-print-settings", print_settings,
            "-exit-on-print",
            abs_path,
        ]
        print(f"[print] Executing SumatraPDF: {' '.join(cmd)}")

        creation_flags = 0
        if os.name == 'nt':
            creation_flags = subprocess.CREATE_NO_WINDOW

        sumatra_timeout = max(310, int(opts.get("sheets_total", 1) or 1) * 10 + 130)
        try:
            res = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=sumatra_timeout,
                creationflags=creation_flags,
            )
            if res.stdout:
                for line in res.stdout.strip().splitlines():
                    print(f"[sumatra] {line}")
            if res.stderr:
                for line in res.stderr.strip().splitlines():
                    print(f"[sumatra:err] {line}")

            if res.returncode == 0:
                print(f"[print] SumatraPDF finished OK (code 0) — job spooled to '{printer_name}'")
                return True
            else:
                print(f"[print] SumatraPDF returned {res.returncode}, falling back to native GDI")
        except subprocess.TimeoutExpired as e:
            print(f"[print] SumatraPDF execution frozen! TimeoutExpired ({e})")
            raise TimeoutError(f"Spooling timed out after {sumatra_timeout}s (rasterization hang).")
        except Exception as e:
            print(f"[print] SumatraPDF execution failed ({e}), falling back to native GDI")

    # Native GDI fallback (handles any PDF directly using Windows GDI print processor)
    print(f"[print] Falling back to Windows GDI engine for '{printer_name}'")
    return _print_windows_gdi(abs_path, printer_name, title, opts=opts)


def _print_windows_gdi(abs_path: str, printer_name: str, title: str, opts: dict = None) -> bool:
    """
    Renders PDF pages directly to the Windows printer DC via PyMuPDF + GDI.
    Uses 300 DPI grayscale (csGRAY / mode L) to stay well under the Brother
    laser printer's 32MB buffer limit. Supports copies, duplex DEVMODE, and landscape/portrait orientation.
    """
    print(f"[print] Rendering via native Windows GDI to '{printer_name}'")
    opts = opts or {}
    copies = max(1, int(opts.get("copies", 1) or 1))
    user_orient = opts.get("orientation", "portrait")
    is_duplex = bool(opts.get("duplex", False))

    import pymupdf
    import win32ui
    import win32gui
    import win32print
    import win32con
    from PIL import Image, ImageWin, ImageEnhance

    hprinter = None
    hdc = None
    try:
        try:
            hprinter = win32print.OpenPrinter(printer_name)
            devmode = win32print.GetPrinter(hprinter, 2).get('pDevMode')
            if devmode:
                devmode.Duplex = win32con.DMDUP_VERTICAL if is_duplex else win32con.DMDUP_SIMPLEX
                devmode.Orientation = win32con.DMORIENT_LANDSCAPE if user_orient == "landscape" else win32con.DMORIENT_PORTRAIT
                devmode.PaperSize = win32con.DMPAPER_A4
                hdc_handle = win32gui.CreateDC("WINSPOOL", printer_name, devmode)
                hdc = win32ui.CreateDCFromHandle(hdc_handle)
        except Exception as dm_err:
            print(f"[print] DevMode initialization failed ({dm_err}), using default DC")
            hdc = None
        finally:
            if hprinter:
                try:
                    win32print.ClosePrinter(hprinter)
                except Exception:
                    pass

        if not hdc:
            hdc = win32ui.CreateDC()
            hdc.CreatePrinterDC(printer_name)

        pw = hdc.GetDeviceCaps(win32con.HORZRES)
        ph = hdc.GetDeviceCaps(win32con.VERTRES)
        doc = pymupdf.open(abs_path)
        contrast_enhancer = 2.2
        # Use a stronger gamma (2.6) to pull light grays heavily towards pure solid black
        dark_table = [min(255, int((i / 255.0) ** 2.6 * 255)) for i in range(256)]

        hdc.StartDoc(title)
        try:
            for copy_idx in range(copies):
                for page in doc:
                    hdc.StartPage()
                    # 600 DPI for extremely high resolution native printing
                    pix = page.get_pixmap(dpi=600, colorspace=pymupdf.csGRAY)
                    img = Image.frombytes("L", [pix.width, pix.height], pix.samples)

                    # --- Aggressive Darkness & Contrast Boost for laser toner ---
                    img = ImageEnhance.Contrast(img).enhance(contrast_enhancer)
                    img = img.point(dark_table)

                    # --- Auto-Orientation (Landscape vs Portrait) Handling ---
                    img_w, img_h = img.size
                    # "auto" (HYPRINT bundles): rotate only sheets that are wider than tall.
                    if user_orient == "landscape" or (user_orient != "portrait" and img_w > img_h):
                        # Brother feeds A4 short-edge first (pw < ph).
                        # Rotating 90° maps wide landscape content along the 297mm height of the A4 paper.
                        if pw < ph:
                            img = img.transpose(Image.Transpose.ROTATE_90)
                            img_w, img_h = img.size
                    elif user_orient == "portrait":
                        # User specifically requested portrait.
                        # If page is portrait, it stays portrait. If page is landscape, it fits horizontally.
                        pass

                    dib = ImageWin.Dib(img)
                    scale = min(pw / img_w, ph / img_h)
                    dest_w = int(img_w * scale)
                    dest_h = int(img_h * scale)
                    offset_x = (pw - dest_w) // 2
                    offset_y = (ph - dest_h) // 2
                    dib.draw(hdc.GetHandleOutput(),
                             (offset_x, offset_y, offset_x + dest_w, offset_y + dest_h))
                    hdc.EndPage()
        finally:
            hdc.EndDoc()
    finally:
        if hdc:
            del hdc
    print(f"[print] Native GDI render complete for '{printer_name}' ({copies} copies, orient={user_orient})")
    return True


def get_active_printer_name() -> str:
    """
    Dynamically finds the installed HP printer (e.g. HP LaserJet Pro P1108 Plus / P1100 plus series)
    via win32print.EnumPrinters, avoiding hardcoded or incorrect defaults.
    """
    if os.name == 'nt':
        try:
            import win32print
            flags = win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS
            printers = [p[2] for p in win32print.EnumPrinters(flags)]
            # Priority 1: Match HP LaserJet Pro P1100 / P1108
            hp_candidates = [p for p in printers if any(k in p.lower() for k in ["p1108", "p1100", "laserjet"])]
            if hp_candidates:
                clean_hp = [p for p in hp_candidates if "(copy" not in p.lower()]
                return clean_hp[0] if clean_hp else hp_candidates[0]
            # Priority 2: Configured PRINTER_NAME if present
            if config.PRINTER_NAME and config.PRINTER_NAME in printers:
                return config.PRINTER_NAME
            # Priority 3: Default printer
            def_p = win32print.GetDefaultPrinter()
            if def_p:
                return def_p
            # Priority 4: Any non-virtual printer
            physical = [p for p in printers if not any(v in p.lower() for v in ["pdf", "xps", "onenote", "fax"])]
            if physical:
                return physical[0]
            if printers:
                return printers[0]
        except Exception as e:
            print(f"[get_active_printer_name] detection error: {e}")
        return "HP LaserJet Pro P1100 plus series"

    # Linux / macOS CUPS
    try:
        conn = _cups()
        printers = conn.getPrinters()
        if config.PRINTER_NAME in printers:
            return config.PRINTER_NAME
        default_dest = conn.getDefault()
        if default_dest:
            return default_dest
        if printers:
            return next(iter(printers.keys()))
    except Exception:
        pass
    return config.PRINTER_NAME or "default"


def printer_state_reasons() -> list[str]:
    if config.SIMULATE:
        return list(_sim.printer_reasons)
    if os.name == 'nt':
        reasons = []
        try:
            import hardware_monitor
            hw_info = hardware_monitor._fetch_raw_printer_status()
            hw_status = hw_info.get("status")
            err_code = hw_info.get("error_code")
            sensors = hw_info.get("sensors", {})
            if hw_status == "CARTRIDGE_MISSING" or err_code == "CARTRIDGE_MISSING" or sensors.get("cartridge_missing"):
                reasons.extend(["marker-supply-missing", "toner-missing", "marker-supply-empty"])
            elif hw_status == "DOOR_OPEN" or err_code == "DOOR_OPEN" or sensors.get("door_open"):
                reasons.append("door-open")
            elif hw_status == "PAPER_JAM" or err_code == "PAPER_JAM" or sensors.get("paper_jam"):
                reasons.append("media-jam")
            elif hw_status == "OUT_OF_PAPER" or err_code == "OUT_OF_PAPER" or sensors.get("paper_tray_empty"):
                reasons.extend(["media-needed", "media-empty"])
            elif hw_status == "TONER_EMPTY" or err_code == "TONER_EMPTY" or sensors.get("toner_empty"):
                reasons.extend(["toner-empty", "marker-supply-empty"])
            elif hw_status in ("MAINTENANCE", "ERROR", "OFFLINE") or err_code in ("DISCONNECTED", "ERROR") or sensors.get("hardware_error"):
                reasons.append("user-intervention-needed")
        except Exception:
            pass

        hprinter = None
        target_printer = get_active_printer_name()
        try:
            import win32print
            # 1. Attempt to connect to the printer handle
            try:
                hprinter = win32print.OpenPrinter(target_printer)
            except Exception:
                # Fallback to default printer if configured name is not found
                try:
                    target_printer = win32print.GetDefaultPrinter()
                    hprinter = win32print.OpenPrinter(target_printer)
                except Exception:
                    return ["printer-unreachable", "offline-report"]

            info = win32print.GetPrinter(hprinter, 2)
            attributes = info.get("Attributes", 0)
            status = info.get("Status", 0)

            # Check if printer is set to Work Offline (0x400 = PRINTER_ATTRIBUTE_WORK_OFFLINE)
            if attributes & 0x00000400:
                reasons.append("offline-report")

            # Check printer status flags
            if status & 0x00000008:  # PRINTER_STATUS_PAPER_JAM
                reasons.append("media-jam")
            if status & 0x00000010:  # PRINTER_STATUS_PAPER_OUT
                reasons.append("media-empty")
            if status & 0x00000040:  # PRINTER_STATUS_PAPER_PROBLEM
                reasons.append("media-needed")
            if status & 0x00400000:  # PRINTER_STATUS_DOOR_OPEN
                reasons.append("door-open")
            if status & 0x00040000:  # PRINTER_STATUS_NO_TONER
                reasons.append("toner-empty")
            if status & 0x00020000:  # PRINTER_STATUS_TONER_LOW
                reasons.append("marker-supply-low")
            if status & 0x00000800:  # PRINTER_STATUS_OUTPUT_BIN_FULL
                reasons.append("output-area-full")
            if status & 0x00000080:  # PRINTER_STATUS_OFFLINE
                reasons.append("offline-report")
            if status & 0x00001000:  # PRINTER_STATUS_NOT_AVAILABLE
                reasons.append("offline-report")
            if status & 0x00000002:  # PRINTER_STATUS_ERROR
                reasons.append("offline-report")
            if status & 0x00000001:  # PRINTER_STATUS_PAUSED
                reasons.append("printer-paused")
            if status & 0x00100000:  # PRINTER_STATUS_USER_INTERVENTION
                reasons.append("user-intervention-needed")
            if status & 0x00200000:  # PRINTER_STATUS_OUT_OF_MEMORY
                reasons.append("printer-out-of-memory")

            # 2. Check active print jobs in Windows spooler for hardware-level stalls
            try:
                jobs = win32print.EnumJobs(hprinter, 0, -1, 2)
                for job in jobs:
                    j_status = job.get("Status", 0)
                    if j_status & 0x00000040:  # JOB_STATUS_PAPEROUT
                        reasons.append("media-empty")
                    if j_status & 0x00000002:  # JOB_STATUS_ERROR
                        reasons.append("offline-report")
                    if j_status & 0x00000020:  # JOB_STATUS_OFFLINE
                        reasons.append("offline-report")
                    if j_status & 0x00000001:  # JOB_STATUS_PAUSED
                        reasons.append("printer-paused")
                    if j_status & 0x00000400:  # JOB_STATUS_USER_INTERVENTION
                        reasons.append("user-intervention-needed")
                    if j_status & 0x00000200:  # JOB_STATUS_BLOCKED_DEVQ
                        reasons.append("media-jam")

                    # Check textual status string provided by printer driver
                    p_status = (job.get("pStatus") or "").lower()
                    if "jam" in p_status:
                        reasons.append("media-jam")
                    elif "paper" in p_status and ("out" in p_status or "empty" in p_status or "load" in p_status):
                        reasons.append("media-empty")
                    elif "door" in p_status or "cover" in p_status:
                        reasons.append("door-open")
                    elif "toner" in p_status:
                        reasons.append("toner-empty")
                    elif "offline" in p_status:
                        reasons.append("offline-report")
                    elif "error" in p_status:
                        reasons.append("offline-report")
            except Exception:
                pass

        except Exception:
            return ["printer-unreachable", "offline-report"]
        finally:
            if hprinter:
                try:
                    win32print.ClosePrinter(hprinter)
                except Exception:
                    pass

        # 3. WMI check for deep bidirectional USB driver state
        if not reasons:
            try:
                import win32com.client
                wmi = win32com.client.GetObject("winmgmts:")
                wmi_printers = wmi.ExecQuery(f"Select * from Win32_Printer Where Name = '{target_printer}'")
                for wp in wmi_printers:
                    if getattr(wp, "WorkOffline", False):
                        reasons.append("offline-report")
                    err_state = getattr(wp, "DetectedErrorState", 0) or 0
                    if err_state in (3, 4):
                        reasons.append("media-empty")
                    elif err_state == 8:
                        reasons.append("media-jam")
                    elif err_state == 7:
                        reasons.append("door-open")
                    elif err_state in (5, 6):
                        reasons.append("toner-empty")
                    elif err_state in (9, 10):
                        reasons.append("offline-report")
                    elif err_state == 11:
                        reasons.append("output-area-full")

                    ext_status = getattr(wp, "ExtendedPrinterStatus", 0) or 0
                    if ext_status in (7, 8, 9, 11):
                        reasons.append("offline-report")
            except Exception:
                pass

        # Deduplicate while preserving order
        seen = set()
        deduped = []
        for r in reasons:
            if r not in seen:
                seen.add(r)
                deduped.append(r)

        return deduped or list(_sim.printer_reasons)

    try:
        attrs = _cups().getPrinterAttributes(get_active_printer_name())
        reasons = attrs.get("printer-state-reasons", [])
        if isinstance(reasons, str):
            reasons = [reasons]
        return [r for r in reasons if r != "none"]
    except Exception:
        return []


def blocking_fault(reasons: list[str]) -> str | None:
    """Returns the first reason that should block payment, else None."""
    for r in reasons:
        if _matches(r, BLOCKING_PREFIXES):
            return r
    return None


def submit(file_path: str, title: str, opts: dict, sheets_total: int) -> int:
    """
    Hand the sliced PDF to CUPS or Windows Spooler. `opts` carries the student's choices.
    Returns a job id used by job_status() and cancel().
    """
    if config.SIMULATE:
        return _sim.start(sheets_total)

    printer_name = get_active_printer_name()

    if os.name == 'nt':
        # Snapshot spooler BEFORE sending so we can identify our new job.
        jobs_before = _snapshot_spooler_jobs(printer_name)

        opts["sheets_total"] = sheets_total
        # Send to physical printer via SumatraPDF with native GDI fallback.
        _print_windows_native(file_path, printer_name, title, opts)

        # Use simulator id as unique handle
        sim_id = _sim.start(sheets_total)

        win_job_id = _find_new_spooler_job(jobs_before, printer_name)
        with _wpj_lock:
            _windows_print_jobs[sim_id] = win_job_id
            _win_job_meta[sim_id] = {
                "sheets_total": sheets_total,
                "start_time": time.time(),
                "win_job_id": win_job_id,
            }

        if win_job_id:
            print(f"[print] Tracking Windows spooler job #{win_job_id} (sim={sim_id}, sheets={sheets_total})")
        else:
            print(f"[print] Spooler job transferred to printer RAM (sim={sim_id}, sheets={sheets_total})")

        return sim_id

    cups_opts = {
        "copies": str(opts.get("copies", 1)),
        "media": opts.get("paper_size", "A4"),
        "print-color-mode": "monochrome",
        "ColorModel": "Gray",
        "sides": "two-sided-long-edge" if opts.get("duplex") else "one-sided",
        "orientation-requested": "4" if opts.get("orientation") == "landscape" else "3",
    }

    nup = int(opts.get("pages_per_sheet", 1) or 1)
    if nup > 1:
        cups_opts["number-up"] = str(nup)

    return _cups().printFile(printer_name, file_path, title, cups_opts)


def job_status(cups_job_id: int) -> dict:
    """Normalized: {state, reasons, sheets_done, sheets_total}."""

    if config.SIMULATE:
        _sim.tick(cups_job_id)
        j = _sim.get(cups_job_id)
        if not j:
            return {"state": "completed", "reasons": [], "sheets_done": 0, "sheets_total": 0}
        return {"state": j["state"], "reasons": [],
                "sheets_done": j["sheets_done"], "sheets_total": j["sheets_total"]}

    if os.name == 'nt':
        with _wpj_lock:
            win_job_id = _windows_print_jobs.get(cups_job_id)
            meta = _win_job_meta.get(cups_job_id)

        reasons = []

        # Check Windows spooler for hardware fault bits while job is visible
        if win_job_id and win_job_id != -1:
            info = _get_win_job_info(win_job_id, get_active_printer_name())
            if not info["found"]:
                with _wpj_lock:
                    _windows_print_jobs[cups_job_id] = -1  # Spooled to printer RAM
            else:
                status = info["status_bits"]
                p_status = info["status_text"]
                if status & 0x00000008 or "jam" in p_status:
                    reasons.append("media-jam")
                if status & 0x00000040 or status & 0x00000010 or ("paper" in p_status and ("out" in p_status or "empty" in p_status or "load" in p_status)):
                    reasons.append("media-empty")
                if status & 0x00400000 or "door" in p_status or "cover" in p_status:
                    reasons.append("door-open")
                if status & 0x00040000 or "cartridge" in p_status or "toner" in p_status:
                    reasons.append("toner-missing")
                if status & 0x00000080 or "offline" in p_status:
                    reasons.append("offline-report")
                if status & 0x00000400 or status & 0x00000002 or "error" in p_status or "attention" in p_status:
                    if not any(r in reasons for r in ["toner-missing", "door-open", "media-jam", "media-empty"]):
                        reasons.append("user-intervention-needed")

        # Collect real-time hardware telemetry
        try:
            hw_reasons = printer_state_reasons()
            for hr in hw_reasons:
                if hr not in reasons:
                    reasons.append(hr)
        except Exception:
            pass

        # Physical feed progress model:
        if meta:
            real_total = meta["sheets_total"]
            now = time.time()
            last_tick = meta.get("last_tick_time", now)
            meta["last_tick_time"] = now

            if reasons:
                # Pause progress: shift start_time forward so paused error duration is not counted as printing
                meta["start_time"] += max(0.0, now - last_tick)
                state = "stopped"
                sheets_done = 0
            else:
                elapsed = now - meta["start_time"]
                WARMUP_S = 8.5
                PER_PAGE_S = 2.5
                total_physical_time = WARMUP_S + max(0, real_total - 1) * PER_PAGE_S + 3.0

                if elapsed < WARMUP_S:
                    sheets_done = 0
                    state = "processing"
                elif elapsed >= total_physical_time:
                    sheets_done = real_total
                    state = "completed"
                else:
                    sheets_done = min(real_total, 1 + int((elapsed - WARMUP_S) / PER_PAGE_S))
                    state = "processing"

            return {
                "state": state,
                "reasons": list(set(reasons)),
                "sheets_done": sheets_done,
                "sheets_total": real_total,
            }

        return {"state": "stopped" if reasons else "completed", "reasons": list(set(reasons)), "sheets_done": 0, "sheets_total": 0}


    # --- Linux/macOS — real CUPS ---
    attrs = _cups().getJobAttributes(cups_job_id)
    state_map = {3: "processing", 4: "processing", 5: "processing",
                 6: "stopped", 7: "canceled", 8: "canceled", 9: "completed"}
    reasons = attrs.get("job-state-reasons", [])
    if isinstance(reasons, str):
        reasons = [reasons]
    return {
        "state": state_map.get(attrs.get("job-state", 9), "processing"),
        "reasons": [r for r in reasons if r != "none"],
        "sheets_done": attrs.get("job-media-sheets-completed", 0) or 0,
        "sheets_total": attrs.get("job-media-sheets", 0) or 0,
    }


def is_jam(reasons: list[str]) -> str | None:
    for r in reasons:
        if _matches(r, JAM_PREFIXES):
            return r
    return None


def cancel(cups_job_id: int):
    if config.SIMULATE:
        _sim.cancel(cups_job_id)
        return
    if os.name == 'nt':
        with _wpj_lock:
            win_job_id = _windows_print_jobs.get(cups_job_id)
        if win_job_id and win_job_id != -1:
            try:
                import win32print
                h = win32print.OpenPrinter(get_active_printer_name())
                try:
                    win32print.SetJob(h, win_job_id, 0, None, win32print.JOB_CONTROL_DELETE)
                finally:
                    win32print.ClosePrinter(h)
            except Exception:
                pass
        return
    _cups().cancelJob(cups_job_id)


def purge_queue() -> int:
    """Admin override: clear every job off the printer. Returns count."""
    if config.SIMULATE:
        return _sim.cancel_all()
    if os.name == 'nt':
        cleared = 0
        try:
            import win32print
            h = win32print.OpenPrinter(get_active_printer_name())
            try:
                jobs = win32print.EnumJobs(h, 0, -1, 1)
                for j in jobs:
                    try:
                        win32print.SetJob(h, j["JobId"], 0, None, win32print.JOB_CONTROL_DELETE)
                        cleared += 1
                    except Exception:
                        pass
            finally:
                win32print.ClosePrinter(h)
        except Exception:
            pass
        return cleared
    conn = _cups()
    jobs = conn.getJobs()
    for jid in jobs:
        try:
            conn.cancelJob(jid)
        except Exception:
            pass
    return len(jobs)


_active_printing_lock = False


def is_busy() -> bool:
    """True while a HYPRINT job is being spooled/printed (hardware_monitor checks this)."""
    return _active_printing_lock


def print_file_with_watchdog(file_path: str, opts: dict = None, job_id: str = None) -> tuple[bool, str | None]:
    """Prints with the hardware watchdog while the hardware monitor is in quiet mode
    (no USB status queries interrupting the host-based printer's data stream)."""
    global _active_printing_lock
    _active_printing_lock = True
    try:
        import hardware_monitor
        hardware_monitor.set_print_active(True)
    except Exception:
        pass
    try:
        return _print_file_with_watchdog_impl(file_path, opts, job_id)
    finally:
        _active_printing_lock = False
        try:
            import hardware_monitor
            hardware_monitor.set_print_active(False)
        except Exception:
            pass


def _print_file_with_watchdog_impl(file_path: str, opts: dict = None, job_id: str = None) -> tuple[bool, str | None]:
    """
    Module 4 Dynamic Physics Print Watchdog:
    1. Expected motor duration: 6.0s warmup + (sheets_total * 3.5s per sheet).
    2. Max timeout: expected_motor_time + 18.0s.
    3. Check A (Silent Feed Failure): Spooler drops to 0 in <3s on multi-page job without motor engagement.
    4. Check B (Mid-Print Faults): Detects door_open, cartridge_missing, paper_jam during physical feed.
    5. Check C (Dynamic Timeout): Aborts if elapsed > max_timeout.
    6. Nuclear spooler reset executed immediately on any failure.
    Returns: (True, "PRINT_VERIFIED") or (False, error_reason).
    """
    opts = opts or {}
    sheets_total = max(1, int(opts.get("sheets_total", 1) or 1))
    copies = max(1, int(opts.get("copies", 1) or 1))
    title = f"hyprint_{job_id[:12]}" if job_id else "hyprint_job"

    # Pre-check hardware before spooling
    if os.name == 'nt' and not config.SIMULATE:
        try:
            import hardware_monitor
            hw = hardware_monitor.get_printer_status()
            if not hw.get("is_ready", False) and hw.get("status") != "BOOTING":
                reason = hw.get("message") or "Printer Hardware Not Ready"
                nuclear_spooler_reset()
                return False, f"Hardware Not Ready: {reason}"
        except Exception as e:
            print(f"[watchdog] pre-check error: {e}")

    printer_name = get_active_printer_name()

    if config.SIMULATE:
        sim_jid = _sim.start(sheets_total)
        start_time = time.time()
        while True:
            time.sleep(0.5)
            _sim.tick(sim_jid)
            st = _sim.get(sim_jid)
            if not st:
                return True, "PRINT_VERIFIED"
            if st.get("reasons"):
                _sim.cancel(sim_jid)
                return False, f"Simulated printer fault: {st['reasons'][0]}"
            if st.get("state") == "completed":
                return True, "PRINT_VERIFIED"
            if st.get("state") == "canceled":
                return False, "Print job canceled"
            if time.time() - start_time > max(25.0, sheets_total * 3.5 + 10.0):
                _sim.cancel(sim_jid)
                return False, "Print Stalled / Timeout"

    if os.name == 'nt':
        jobs_before = _snapshot_spooler_jobs(printer_name)
        # The printer starts feeding while we are still spooling later pages, so the
        # physical-print clock starts now, not when spooling finishes.
        spool_started = time.time()

        # Spool via the fast 1-bit engine (SumatraPDF as fallback / KIOSK_PRINT_ENGINE=sumatra)
        try:
            _print_windows_native(file_path, printer_name, title, opts)
        except Exception as e:
            nuclear_spooler_reset(printer_name)
            return False, f"Failed to send to printer spooler: {e}"

        # Find OUR new Windows spooler job (never judge success by unrelated queue entries)
        win_job_id = _find_new_spooler_job(jobs_before, printer_name, retries=8)

        start_time = spool_started
        last_progress_time = time.time()
        # HP LaserJet Pro P1108 (18 ppm A4, host-based GDI printer): ~8 s to first page,
        # ~3.4 s per further sheet. Host-based printers keep the job in the Windows queue
        # while the PC streams each rendered page, so be generous before calling it a stall.
        expected_motor_time = 8.0 + max(0, sheets_total - 1) * 3.4
        max_timeout = expected_motor_time * 1.5 + 90.0
        STALL_SECONDS = 90.0

        def _our_job_present() -> bool:
            if win_job_id is not None and win_job_id != -1:
                return _get_win_job_info(win_job_id, printer_name).get("found", False)
            # Could not identify the job id: fall back to "any job that wasn't there before".
            return bool(_snapshot_spooler_jobs(printer_name) - jobs_before)

        # Monitor loop every 1s (local spooler reads only — never USB queries)
        while True:
            time.sleep(1.0)
            now = time.time()
            elapsed = now - start_time

            # Check B: Real-time hardware telemetry (door open, cartridge missing, paper jam, offline)
            try:
                import hardware_monitor
                hw = hardware_monitor.get_printer_status()
                sensors = hw.get("sensors", {})
                if sensors.get("door_open"):
                    nuclear_spooler_reset(printer_name)
                    return False, "Printer Lid/Top Cover Open"
                if sensors.get("cartridge_missing") or sensors.get("toner_empty"):
                    nuclear_spooler_reset(printer_name)
                    return False, "Toner Cartridge Missing or Empty"
                if sensors.get("paper_jam"):
                    nuclear_spooler_reset(printer_name)
                    return False, "Paper Jam Detected"
                if sensors.get("paper_tray_empty"):
                    nuclear_spooler_reset(printer_name)
                    return False, "Out of Paper — Load Tray"
                if sensors.get("offline"):
                    nuclear_spooler_reset(printer_name)
                    return False, "Printer Disconnected / Offline"
            except Exception as e:
                print(f"[watchdog] telemetry poll error: {e}")

            # Check spooler status of our job
            if win_job_id and win_job_id != -1:
                info = _get_win_job_info(win_job_id, printer_name)
                if not info["found"]:
                    # Job left the Windows spooler: fully transferred to the printer.
                    win_job_id = -1
                    last_progress_time = now
                else:
                    s_bits = info.get("status_bits", 0)
                    s_text = info.get("status_text", "").lower()
                    pages_printed = info.get("pages_printed", 0)

                    if (s_bits & (0x00000008 | 0x00000010 | 0x00000080) or "print" in s_text
                            or "spool" in s_text or pages_printed):
                        last_progress_time = now

                    # Mid-print hardware queue faults:
                    if s_bits & 0x00000200 or "jam" in s_text:
                        nuclear_spooler_reset(printer_name)
                        return False, "Paper Jam in Spooler Queue"

                    if s_bits & 0x00000040 or any(p in s_text for p in ["paper out", "out of paper", "load paper", "no paper"]):
                        nuclear_spooler_reset(printer_name)
                        return False, "Out of Paper in Spooler Queue"

                    if s_bits & 0x00400000 or any(d in s_text for d in ["door open", "cover open", "top cover"]):
                        nuclear_spooler_reset(printer_name)
                        return False, "Printer Door / Cover Open"

                    if s_bits & 0x00040000 or any(c in s_text for c in ["no cartridge", "cartridge missing", "toner empty"]):
                        nuclear_spooler_reset(printer_name)
                        return False, "Toner Cartridge Issue"

            # Physical motor feed duration keeper
            if elapsed < expected_motor_time:
                last_progress_time = now

            # Success: OUR job has left the queue AND the physical feed time has elapsed
            if elapsed >= expected_motor_time and not _our_job_present():
                print(f"[watchdog] Print verified successfully on '{printer_name}' in {elapsed:.1f}s ({sheets_total} sheets).")
                return True, "PRINT_VERIFIED"

            # Check C: Dynamic timeout / freeze
            if elapsed > max_timeout or (now - last_progress_time > STALL_SECONDS):
                print(f"[watchdog] Print timeout/freeze flagged after {elapsed:.1f}s. Executing nuclear spooler reset.")
                nuclear_spooler_reset(printer_name)
                return False, f"HARDWARE_TIMEOUT_FAILURE: Print stalled after {int(elapsed)}s"

    # --- Linux / macOS: real CUPS ---
    try:
        cups_job = submit(file_path, title, dict(opts), sheets_total)
    except Exception as e:
        return False, f"Failed to send to CUPS: {e}"
    start_time = time.time()
    max_timeout = (8.0 + sheets_total * 3.4) * 1.5 + 90.0
    while True:
        time.sleep(1.0)
        try:
            st = job_status(cups_job)
        except Exception as e:
            return False, f"Lost contact with CUPS: {e}"
        fault = is_jam(st.get("reasons") or [])
        if fault:
            try:
                cancel(cups_job)
            except Exception:
                pass
            return False, f"Printer fault: {fault}"
        if st.get("state") == "completed":
            return True, "PRINT_VERIFIED"
        if st.get("state") == "canceled":
            return False, "Print job canceled"
        if time.time() - start_time > max_timeout:
            try:
                cancel(cups_job)
            except Exception:
                pass
            return False, "Print Stalled / Timeout"

